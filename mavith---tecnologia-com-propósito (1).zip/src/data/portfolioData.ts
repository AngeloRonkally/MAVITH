import { PortfolioProject } from '../types/portfolio';

export const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    id: 'case-01',
    slug: 'portal-b2b-distribuicao',
    title: 'Portal de Pedidos B2B com Sincronização Fiscal',
    subtitle: 'Autonomia para revendedores e digitalização ponta a ponta da entrada de pedidos',
    category: 'Sistemas',
    segment: 'Distribuição & Logística Atacadista',
    description:
      'Sistema sob medida para substituir a anotação manual de pedidos recebidos por mensagem de texto e áudio, unificando a esteira de pedidos diretamente na retaguarda de expedição.',
    isDemo: true,
    featured: true,
    primaryDevice: 'desktop',

    problem:
      'A distribuidora recebia mais de 100 pedidos diários via áudios e listas soltas no WhatsApp. Três assistentes operacionais passavam o dia redigitando itens em planilhas locais, gerando erros constantes na expedição, faturamento de itens sem estoque e insatisfação dos clientes de atacado.',

    analysis:
      'A raiz do problema não era a equipe, mas a ausência de um canal estruturado com verificação de estoque em tempo real e tabela de preços por perfil de cliente. A empresa necessitava de um canal direto e autônomo para o comprador corporativo.',

    objective:
      'Eliminar a digitação manual de pedidos, mitigar as divergências de expedição e liberar a equipe interna para atuação em vendas ativas.',

    strategy:
      'Construir um portal web leve e seguro, com login privativo para clientes credenciados, regras tributárias automáticas e integração com a esteira de emissão de NF-e.',

    solution:
      'Desenvolvemos um portal web responsivo onde o comprador B2B visualiza o catálogo com suas condições comerciais específicas, simula prazos de frete e fecha o pedido. A ordem cai instantaneamente no painel operacional com separação pronta.',

    features: [
      {
        title: 'Tabelas de Preço Personalizadas',
        description: 'Regras automáticas por volume de compra e classificação de cada revendedor credenciado.',
      },
      {
        title: 'Controle de Saldo e Ruptura de Estoque',
        description: 'Impossibilita a venda de itens indisponíveis na retaguarda com atualização contínua.',
      },
      {
        title: 'Emissão e Aprovação de Pedidos em 1 Clique',
        description: 'Validação de crédito e encaminhamento direto para separação no depósito.',
      },
      {
        title: 'Histórico e Recompra Rápida',
        description: 'Compradores repetem pedidos frequentes em menos de 30 segundos pelo celular ou computador.',
      },
    ],

    technologies: ['TypeScript', 'React', 'Node.js', 'PostgreSQL', 'Tailwind CSS', 'Docker'],

    results: [
      {
        metric: 'Tempo de Digitação',
        label: 'Eliminação da redigitação',
        detail: 'Redução drástica do retrabalho manual diário das assistentes operacionais.',
      },
      {
        metric: 'Zero Conflitos',
        label: 'Acurácia de estoque',
        detail: 'Fim dos cancelamentos decorrentes de faturamento de produtos indisponíveis.',
      },
      {
        metric: 'Atendimento 24/7',
        label: 'Disponibilidade de compra',
        detail: 'Revendedores passaram a emitir pedidos à noite e finais de semana sem fila.',
      },
    ],

    mockupData: {
      device: 'desktop',
      screenType: 'b2b_portal',
      caption: 'Visão do painel de pedidos do cliente B2B e fila de expedição em tempo real',
      highlights: ['Catálogo exclusivo', 'Validação de saldo', 'Exportação fiscal'],
    },

    gallery: [
      {
        title: 'Catálogo de Compras B2B',
        description: 'Grade de produtos com preços e alíquotas calculadas dinamicamente.',
        device: 'notebook',
        tag: 'Interface do Comprador',
      },
      {
        title: 'Fila de Separação no Depósito',
        description: 'Visualização da esteira de expedição otimizada para tablets industriais.',
        device: 'tablet',
        tag: 'Painel Operacional',
      },
      {
        title: 'Acompanhamento do Pedido no Mobile',
        description: 'Status em tempo real de transporte e link do rastreio para o motorista.',
        device: 'mobile',
        tag: 'Visão Mobile',
      },
    ],
  },

  {
    id: 'case-02',
    slug: 'agente-ia-triagem-contabil',
    title: 'Agente de Inteligência Artificial para Triagem Contábil',
    subtitle: 'Qualificação prévia de leads e validação documental com linguagem natural',
    category: 'IA',
    segment: 'Serviços Corporativos & BPO Financeiro',
    description:
      'Assistente inteligente integrado ao WhatsApp e web para recepcionar clientes, classificar o regime tributário e validar certidões sem consumir a jornada dos especialistas seniores.',
    isDemo: true,
    featured: true,
    primaryDevice: 'mobile',

    problem:
      'Especialistas contábeis seniores dedicavam até 35% de seu tempo de trabalho respondendo questionamentos básicos e cobrando o envio de documentos cadastrais de empresas sem perfil de atendimento.',

    analysis:
      'A triagem inicial seguia um fluxo lógico bem delimitado (faturamento, regime, número de sócios, ramo de atuação). Esse processo podia ser completamente absorvido por um agente de IA treinado na base de conhecimento interna do escritório.',

    objective:
      'Qualificar 100% dos novos contatos antes de direcioná-los ao consultor e reduzir o tempo médio de resposta no primeiro atendimento.',

    strategy:
      'Treinar um modelo de linguagem com as regras de negócio do escritório contábil e estruturar uma conversa humanizada, assertiva e livre de jargões técnicos complexos.',

    solution:
      'Implementação de um Agente de IA capaz de dialogar naturalmente, solicitar documentos em PDF/imagem, validar a completude cadastral e criar a oportunidade qualificada no CRM com o resumo já redigido.',

    features: [
      {
        title: 'Compreensão de Linguagem Natural',
        description: 'Capacidade de entender dúvidas tributárias sem necessidade de menus numéricos engessados.',
      },
      {
        title: 'Verificação Inteligente de Anexos',
        description: 'Confirma se o arquivo enviado é realmente um Contrato Social ou extrato bancário legível.',
      },
      {
        title: 'Agendamento Direto na Agenda do Especialista',
        description: 'Se o cliente for qualificado, a IA oferece os horários disponíveis em tempo real.',
      },
      {
        title: 'Transbordo Humano Contextualizado',
        description: 'Ao passar para o atendente, entrega o dossiê completo já classificado.',
      },
    ],

    technologies: ['Gemini API', 'TypeScript', 'Node.js', 'Webhooks API', 'Tailwind CSS'],

    results: [
      {
        metric: '< 1 minuto',
        label: 'Tempo de primeira resposta',
        detail: 'Atendimento instantâneo a qualquer hora do dia ou final de semana.',
      },
      {
        metric: 'Foco no Alto Valor',
        label: 'Horas liberadas',
        detail: 'Consultores deixaram o trabalho braçal de triagem e focaram no fechamento.',
      },
      {
        metric: 'Leads Filtrados',
        label: 'Qualificação prévia',
        detail: 'Reuniões agendadas apenas com empresas dentro do perfil ideal de atendimento.',
      },
    ],

    mockupData: {
      device: 'mobile',
      screenType: 'chat_ai',
      caption: 'Fluxo conversacional do Agente de IA com validação de documentos e agendamento',
      highlights: ['Triagem humanizada', 'Validação OCR', 'Sincronização com CRM'],
    },

    gallery: [
      {
        title: 'Conversa no WhatsApp',
        description: 'Interação fluida com o cliente sem parecer um robô mecânico engessado.',
        device: 'mobile',
        tag: 'Experiência do Usuário',
      },
      {
        title: 'Painel de Supervisão dos Agendamentos',
        description: 'Visão central dos atendimentos concluídos com a síntese de cada caso.',
        device: 'desktop',
        tag: 'Área da Gestão',
      },
    ],
  },

  {
    id: 'case-03',
    slug: 'dashboard-bi-financeiro-clinica',
    title: 'Painel Executivo de Faturamento e Repasse Médico',
    subtitle: 'Consolidação de prontuários, faturamento por especialidade e margem líquida real',
    category: 'Dashboards',
    segment: 'Saúde & Clínicas Especializadas',
    description:
      'Painel analítico centralizado que cruza dados de prontuários eletrônicos, operadoras de saúde e contas a pagar, substituindo o fechamento mensal feito em múltiplas planilhas desconexas.',
    isDemo: true,
    featured: true,
    primaryDevice: 'desktop',

    problem:
      'A gestão da clínica gastava cerca de 10 dias úteis no início de cada mês para cruzar planilhas de agendamentos com os extratos bancários, tentando calcular manualmente o repasse de 18 profissionais e a margem de cada especialidade.',

    analysis:
      'Os dados existiam, porém estavam fragmentados no software de prontuários, no banco e em cadernos de procedimentos. Faltava um data warehouse unificado com rotina de conciliação automática.',

    objective:
      'Reduzir o ciclo de apuração financeira para menos de 2 horas e fornecer visão diária da rentabilidade líquida por sala e profissional.',

    strategy:
      'Projetar uma pipeline de ETL (extração e tratamento de dados) com visualização gráfica clara e regras contratuais de repasse parametrizadas.',

    solution:
      'Construção de um dashboard web intuitivo, com permissões de acesso por nível hierárquico, que exibe em tempo real o faturamento bruto, glosas das operadoras, custos de insumos e o valor líquido exato de repasse.',

    features: [
      {
        title: 'Extrato Automatizado de Repasse',
        description: 'Relatório individual enviado automaticamente ao profissional com os atendimentos auditados.',
      },
      {
        title: 'Monitoramento de Glosas de Convênios',
        description: 'Identificação imediata de procedimentos recusados pelas operadoras para recurso tempestivo.',
      },
      {
        title: 'Lucratividade por Especialidade',
        description: 'Comparativo visual de receita, custo de sala e margem de contribuição efetiva.',
      },
      {
        title: 'Visão Executiva no Celular',
        description: 'Cards sintéticos de faturamento e ocupação de salas acessíveis pelo gestor.',
      },
    ],

    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Recharts / D3', 'Node.js', 'PostgreSQL'],

    results: [
      {
        metric: 'De 10 dias p/ 1h',
        label: 'Fechamento financeiro',
        detail: 'Apuração do fechamento mensal automatizada sem necessidade de hora extra.',
      },
      {
        metric: '100% Transparência',
        label: 'Relação com médicos',
        detail: 'Fim dos questionamentos sobre conferência de consultas e valores a receber.',
      },
      {
        metric: 'Visão de Margem',
        label: 'Decisão estratégica',
        detail: 'Clareza de quais especialidades geram real retorno após custos operacionais.',
      },
    ],

    mockupData: {
      device: 'desktop',
      screenType: 'dashboard',
      caption: 'Dashboard analítico com taxa de ocupação, repasses e margem líquida em tempo real',
      highlights: ['Métricas consolidadas', 'Auditoria de glosas', 'Extrato automático'],
    },

    gallery: [
      {
        title: 'Visão Geral do Faturamento',
        description: 'Gráficos comparativos de faturamento bruto versus custo operacional por mês.',
        device: 'notebook',
        tag: 'Diretoria Executiva',
      },
      {
        title: 'Extrato Individual de Repasse',
        description: 'Tela simplificada com detalhes de consultas e percentual de comissão.',
        device: 'tablet',
        tag: 'Visão do Especialista',
      },
    ],
  },

  {
    id: 'case-04',
    slug: 'automacao-cobranca-conciliacao-pix',
    title: 'Automação de Régua de Cobrança e Baixa Automática',
    subtitle: 'Sincronização entre banco digital, mensagens ativas e atualização de inadimplência',
    category: 'Automação',
    segment: 'Serviços Recorrentes & Mensalidades',
    description:
      'Esteira automática de notificações amigáveis via WhatsApp e e-mail com geração instantânea de link Pix e conciliação bancária sem intervenção humana.',
    isDemo: true,
    featured: false,
    primaryDevice: 'tablet',

    problem:
      'Uma empresa de contratos mensais com mais de 300 clientes sofria com 18% de inadimplência por mero esquecimento dos contratantes. Uma funcionária gastava manhãs inteiras enviando mensagens individuais e conferindo extratos bancários manualmente.',

    analysis:
      'Mais de 70% dos atrasos eram resolvidos assim que o cliente recebia uma chave Pix copia-e-cola com lembrete no dia do vencimento. O gargalo era a dependência de digitação e envio manual.',

    objective:
      'Automatizar a régua preventiva e de cobrança, reduzindo a taxa de inadimplência e eliminando a conferência manual de comprovantes.',

    strategy:
      'Integrar a API bancária para detecção de pagamentos via webhook e disparar notificações escalonadas de acordo com o status de cada fatura.',

    solution:
      'Fluxo de automação completo que monitora as datas de vencimento, envia lembrete educado 3 dias antes, disponibiliza o Pix dinâmico e dá baixa instantânea no sistema contábil quando o dinheiro cai na conta.',

    features: [
      {
        title: 'Régua Inteligente e Gradual',
        description: 'Mensagens prévias, na data e pós-vencimento com tom respeitoso e personalizado.',
      },
      {
        title: 'Pix Dinâmico com Baixa em Segundos',
        description: 'Identificação imediata de quem pagou sem precisar de envio de comprovante em PDF.',
      },
      {
        title: 'Bloqueio e Desbloqueio Automático',
        description: 'Sistemas ou acessos liberados imediatamente assim que o webhook confirma o valor.',
      },
      {
        title: 'Painel de Conciliação em Tempo Real',
        description: 'Visão consolidada do fluxo recebido, a receber e atrasado com 1 clique.',
      },
    ],

    technologies: ['Node.js', 'Webhooks Bancários', 'APIs de Mensageria', 'PostgreSQL', 'Tailwind CSS'],

    results: [
      {
        metric: 'Queda Expressiva',
        label: 'Inadimplência involuntária',
        detail: 'A maioria dos clientes passou a pagar no primeiro lembrete com chave Pix pronta.',
      },
      {
        metric: '100% Automático',
        label: 'Baixa de faturas',
        detail: 'Eliminação da conferência manual de comprovantes enviados por foto no WhatsApp.',
      },
      {
        metric: 'Zero Constrangimento',
        label: 'Relação comercial',
        detail: 'Comunicação padronizada e profissional que mantém a cordialidade com os clientes.',
      },
    ],

    mockupData: {
      device: 'tablet',
      screenType: 'automation_flow',
      caption: 'Fluxograma interativo da esteira de automação e painel de conciliação bancária',
      highlights: ['Webhooks ativos', 'Notificações escalonadas', 'Baixa instantânea'],
    },

    gallery: [
      {
        title: 'Fluxo da Régua de Mensagens',
        description: 'Painel visual de configuração de prazos e templates das mensagens.',
        device: 'desktop',
        tag: 'Configuração do Fluxo',
      },
      {
        title: 'Notificação Recebida pelo Cliente',
        description: 'Layout da mensagem clara com botão de pagamento e código Pix copiado.',
        device: 'mobile',
        tag: 'Visão do Destinatário',
      },
    ],
  },

  {
    id: 'case-05',
    slug: 'portal-institucional-autoridade-engenharia',
    title: 'Site Institucional de Alta Performance para Engenharia',
    subtitle: 'Posicionamento comercial sólido, catálogo técnico e captação de orçamentos',
    category: 'Sites',
    segment: 'Engenharia, Construção & Infraestrutura',
    description:
      'Desenvolvimento de website institucional veloz, acessível e otimizado para SEO, estruturado para transmitir solidez corporativa e converter visitas em propostas de contratos comerciais.',
    isDemo: true,
    featured: false,
    primaryDevice: 'notebook',

    problem:
      'Uma empresa de engenharia com 12 anos de atuação de destaque físico possuía um site desatualizado, lento e sem versão para celular. Clientes corporativos e licitantes não encontravam o acervo técnico e a empresa perdia credibilidade diante de novos investidores.',

    analysis:
      'No mercado B2B de engenharia, o site não é um panfleto genérico, mas o primeiro filtro de validação de capacidade técnica e conformidade das grandes construtoras.',

    objective:
      'Construir uma presença digital de prestígio, com carregamento ultrarrápido, acervo de obras filtrável e formulário estruturado para cotações técnicas.',

    strategy:
      'Adotar arquitetura estática moderna focada em performance (Core Web Vitals máximos), design limpo e corporativo, e hierarquia tipográfica de alta legibilidade.',

    solution:
      'Novo portal institucional desenvolvido sob os preceitos de autoridade, com portfólio de obras por categoria técnica, certificações em destaque e canal direto com o setor de orçamentos.',

    features: [
      {
        title: 'Acervo Técnico Filtrável',
        description: 'Apresentação detalhada de obras executadas com fichas técnicas e escopo contratual.',
      },
      {
        title: 'Carregamento Abaixo de 1 Segundo',
        description: 'Pontuação exemplar no Google PageSpeed para garantir máxima retenção e rankeamento.',
      },
      {
        title: 'Formulário de Pré-Dimensionamento',
        description: 'Coleta precisa de metragem, tipo de obra e localização para orçamentos assertivos.',
      },
      {
        title: 'Design Totalmente Adaptativo',
        description: 'Navegação impecável em notebooks, tablets e smartphones de diretores e decisores.',
      },
    ],

    technologies: ['Vite', 'React', 'TypeScript', 'Tailwind CSS', 'SEO Estruturado', 'Cloud Hosting'],

    results: [
      {
        metric: '98/100',
        label: 'Google PageSpeed',
        detail: 'Performance superior que melhora o posicionamento orgânico nas buscas regionais.',
      },
      {
        metric: 'Mais Contatos Qualificados',
        label: 'Volume de propostas',
        detail: 'Aumento na entrada de solicitações de propostas comerciais de alto valor.',
      },
      {
        metric: 'Autoridade Renovada',
        label: 'Percepção de mercado',
        detail: 'Clientes corporativos validam a solidez da engenharia já no primeiro acesso.',
      },
    ],

    mockupData: {
      device: 'notebook',
      screenType: 'institutional_site',
      caption: 'Layout corporativo com vitrine de projetos técnicos e funil de captação de clientes',
      highlights: ['Performance 98+', 'Acervo interativo', 'Mobile First'],
    },

    gallery: [
      {
        title: 'Página Inicial Institucional',
        description: 'Hero impactante com proposta de valor clara e credenciais do corpo técnico.',
        device: 'desktop',
        tag: 'Capa Corporativa',
      },
      {
        title: 'Catálogo de Obras Executadas',
        description: 'Grade com filtros por segmento (industrial, comercial, residencial).',
        device: 'notebook',
        tag: 'Acervo Técnico',
      },
      {
        title: 'Formulário de Contato no Mobile',
        description: 'Formulário com preenchimento assistido para orçamentos pelo celular.',
        device: 'mobile',
        tag: 'Experiência Mobile',
      },
    ],
  },

  {
    id: 'case-06',
    slug: 'sistema-gestao-ordens-servico',
    title: 'Plataforma Web de Ordens de Serviço e Manutenção',
    subtitle: 'Controle de chamados em campo, fotos de vistoria e assinatura digital',
    category: 'Sistemas',
    segment: 'Serviços Técnicos & Manutenção Industrial',
    description:
      'Sistema centralizado para substituição das ordens de serviço em blocos de papel carbonado, conectando técnicos em campo à equipe de faturamento em tempo real.',
    isDemo: true,
    featured: false,
    primaryDevice: 'tablet',

    problem:
      'Os técnicos realizavam manutenções e preenchiam laudos em papel carbonado. As vias chegavam amassadas dias depois ao escritório, notas fiscais demoravam semanas para ser emitidas e fotos de antes/depois ficavam perdidas nos celulares particulares.',

    analysis:
      'A falta de integração entre campo e financeiro causava morosidade de caixa, extravio de laudos de garantia e incapacidade de mensurar a produtividade de cada equipe técnica.',

    objective:
      'Digitalizar o fluxo completo da ordem de serviço: da abertura do chamado ao laudo assinado pelo cliente na tela do tablet ou smartphone.',

    strategy:
      'Criar uma interface simples que funciona perfeitamente em telas sensíveis ao toque, com upload direto de fotos e coleta de assinatura na tela.',

    solution:
      'Plataforma web onde a coordenação agenda o chamado, o técnico recebe o roteiro, realiza o checklist de manutenção com fotos, coleta a assinatura do cliente e a ordem é fechada instantaneamente no financeiro.',

    features: [
      {
        title: 'Assinatura na Tela (Touch Signature)',
        description: 'O cliente valida o serviço executado desenhando o visto direto no aparelho.',
      },
      {
        title: 'Registro Fotográfico Obrigatório',
        description: 'Comprovação visual de antes e depois vinculada ao histórico daquela máquina.',
      },
      {
        title: 'Envio Automático de Relatório em PDF',
        description: 'O cliente recebe por e-mail e WhatsApp o laudo timbrado com selo de conclusão.',
      },
      {
        title: 'Painel de Produtividade Técnica',
        description: 'Métricas de tempo médio de atendimento e custo de peças utilizadas por chamado.',
      },
    ],

    technologies: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Tailwind CSS', 'PWA Support'],

    results: [
      {
        metric: 'Fim do Papel',
        label: 'Eliminação do carbonado',
        detail: 'Economia de blocos físicos e fim do extravio de ordens de serviço no trânsito.',
      },
      {
        metric: 'Faturamento Imediato',
        label: 'Ciclo de recebimento',
        detail: 'Notas fiscais emitidas no mesmo dia da execução da visita técnica.',
      },
      {
        metric: 'Segurança Jurídica',
        label: 'Histórico auditável',
        detail: 'Fotos geolocalizadas e visto digital garantem respaldo em qualquer contestação.',
      },
    ],

    mockupData: {
      device: 'tablet',
      screenType: 'crm',
      caption: 'Interface do técnico com checklist dinâmico e tela de validação por assinatura',
      highlights: ['Assinatura digital', 'Checklist guiado', 'Geração de laudo PDF'],
    },

    gallery: [
      {
        title: 'Agenda e Distribuição de Técnicos',
        description: 'Painel da gerência operacional para alocação rápida de rotas do dia.',
        device: 'desktop',
        tag: 'Coordenação Central',
      },
      {
        title: 'Tela de Checklist do Técnico',
        description: 'Passo a passo simples com botões largos para operação com luvas ou em campo.',
        device: 'tablet',
        tag: 'Operação de Campo',
      },
    ],
  },
];

export function getProjectBySlug(slug: string): PortfolioProject | undefined {
  return PORTFOLIO_PROJECTS.find((p) => p.slug === slug);
}
