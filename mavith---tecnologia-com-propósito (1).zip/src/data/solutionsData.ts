import { SolutionData, SolutionSlug } from '../types/solutions';

export const SOLUTIONS_DATA: Record<SolutionSlug, SolutionData> = {
  sites: {
    id: 'solucao-sites',
    slug: 'sites',
    pillarNumber: '01',
    title: 'Sites & Plataformas Digitais',
    badge: 'Presença & Posicionamento',
    accent: 'blue',
    headline: 'Uma presença digital que representa o valor da sua empresa.',
    tagline: 'Não vendemos apenas páginas na web. Construímos pontos de contato que transmitem credibilidade imediata, qualificam visitantes e transformam interesse em oportunidades reais de negócio.',
    
    // 1. Problema
    problemHeadline: 'O site da sua empresa transmite o mesmo nível de excelência que você entrega presencialmente?',
    problemDescription: 'Muitas empresas consolidadas e com serviços de alta qualidade sofrem com um site genérico, lento ou desatualizado. Quando um potencial cliente pesquisa sua marca, a primeira impressão muitas vezes é de amadorismo, gerando desconfiança e afastando contratos de alto valor.',
    symptoms: [
      {
        title: 'Sensação de negócio pequeno ou amador',
        description: 'Sua empresa entrega excelência no mundo real, mas o endereço virtual parece ter sido feito há anos atrás sem cuidado estratégico.',
      },
      {
        title: 'Visitantes chegam, mas não entram em contato',
        description: 'O site tem tráfego, mas não conduz o usuário a uma ação clara. As pessoas saem sem entender o que sua empresa resolve.',
      },
      {
        title: 'Mensagem e proposta de valor confusas',
        description: 'Textos longos, jargões vagos ou excesso de opções que deixam o decisor perdido antes mesmo de solicitar uma proposta.',
      },
      {
        title: 'Incompatibilidade com celulares e lentidão',
        description: 'Páginas pesadas que demoram para carregar no celular do cliente, causando desistência imediata em poucos segundos.',
      },
    ],

    // 2. Como podemos ajudar & Para quem serve
    targetAudience: [
      {
        segment: 'Empresas B2B & Consultorias',
        description: 'Organizações que precisam transmitir solidez corporativa para fechar negócios de ticket médio e alto.',
      },
      {
        segment: 'Clínicas, Escritórios & Serviços Especializados',
        description: 'Profissionais que dependem de autoridade imediata, clareza nos serviços e facilidade de agendamento.',
      },
      {
        segment: 'Indústrias, Distribuidoras & Operações Comerciais',
        description: 'Empresas que necessitam de portais para catálogo de produtos, credenciamento de parceiros e atendimento corporativo.',
      },
      {
        segment: 'Empresas em Fase de Expansão ou Rebranding',
        description: 'Negócios que mudaram de patamar e precisam alinhar sua marca digital ao seu novo tamanho de mercado.',
      },
    ],
    approachPhilosophy: 'Antes de desenhar telas, entendemos quem é o seu comprador ideal, quais objeções ele tem na mente e como estruturar a narrativa para que sua empresa seja a escolha óbvia.',

    // 3. O que pode ser construído
    offerings: [
      {
        title: 'Sites Institucionais Estratégicos',
        description: 'Desenho exclusivo focado na identidade, posicionamento de mercado e apresentação clara das linhas de serviço da sua empresa.',
        deliverables: ['Arquitetura de conteúdo persuasiva', 'Design responsivo para desktop e mobile', 'Velocidade máxima de carregamento', 'SEO institucional estruturado'],
        idealFor: 'Empresas que buscam autoridade institucional e validação comercial perante clientes exigentes.',
      },
      {
        title: 'Landing Pages de Alta Conversão',
        description: 'Páginas direcionadas para uma oferta ou campanha específica, sem distrações, guiando o lead direto para o fechamento.',
        deliverables: ['Chamadas para ação de alto contraste', 'Formulários integrados ao WhatsApp/CRM', 'Copywriting orientado à dor do cliente', 'Métricas de conversão em tempo real'],
        idealFor: 'Lançamento de novos serviços, campanhas de anúncios e captação de leads qualificados.',
      },
      {
        title: 'Portais Corporativos & Catálogos',
        description: 'Ambientes organizados para exibição de linhas de produtos, manuais técnicos, fichas e canais dedicados para parceiros comerciais.',
        deliverables: ['Filtros rápidos por categoria e aplicação', 'Solicitação direta de orçamento por item', 'Área de downloads institucionais', 'Painel administrativo intuitivo'],
        idealFor: 'Distribuidoras, indústrias e representantes com múltiplos produtos e clientes recorrentes.',
      },
      {
        title: 'Plataformas Web Especializadas',
        description: 'Ambientes online com áreas logadas, portais do cliente, centrais de agendamento ou consulta de status em tempo real.',
        deliverables: ['Autenticação segura de usuários', 'Painel de autoatendimento para o cliente', 'Integração direta com o banco da empresa', 'Notificações por e-mail e mensageria'],
        idealFor: 'Empresas que desejam oferecer conveniência digital aos seus clientes ativos e desafogar o suporte.',
      },
    ],

    // 4. Exemplos práticos
    examples: [
      {
        scenario: 'Escritório de Consultoria Tributária e Societária',
        before: 'Site padrão com fotos de banco genéricas e textos jurídicos indecifráveis. Quase nenhum contato espontâneo recebido.',
        after: 'Estrutura focada nos problemas dos empresários (redução de passivo, reestruturação societária) com calculadoras e canais diretos.',
        impact: 'Aumento de 240% em contatos qualificados de diretores financeiros no primeiro trimestre.',
      },
      {
        scenario: 'Distribuidora de Equipamentos Hospitalares',
        before: 'Catálogo impresso enviado por PDF pesado em e-mails que caíam no spam. Clientes demoravam para encontrar especificações.',
        after: 'Portal digital com busca por modelo, compatibilidade técnica e botão direto para cotação com a equipe de vendas.',
        impact: 'Redução de 60% nas dúvidas básicas de suporte e agilidade de 3x no fechamento de orçamentos.',
      },
    ],

    // 5. Benefícios
    benefits: [
      {
        title: 'Credibilidade Imediata',
        description: 'Sua empresa transmite solidez e profissionalismo desde os primeiros três segundos de navegação.',
        metricHighlight: '1ª Impressão',
      },
      {
        title: 'Qualificação de Oportunidades',
        description: 'O cliente chega ao WhatsApp ou formulário já sabendo o que você faz, seu posicionamento e pronto para negociar.',
        metricHighlight: '+ Leads Qualificados',
      },
      {
        title: 'Velocidade & Leveza',
        description: 'Páginas que abrem instantaneamente em qualquer conexão móvel, sem travamentos ou esperas desnecessárias.',
        metricHighlight: '< 1.5s de Carga',
      },
      {
        title: 'Autonomia Total',
        description: 'Você e sua equipe não ficam reféns de terceiros para atualizar textos, serviços e dados de contato fundamentais.',
        metricHighlight: 'Gestão Simples',
      },
    ],

    // 6. Como funciona / Processo
    processSteps: [
      {
        step: '01',
        title: 'Diagnóstico & Posicionamento',
        description: 'Mapeamos o perfil dos seus clientes, os pontos fortes do seu serviço e as falhas da presença atual.',
      },
      {
        step: '02',
        title: 'Estrutura & Mensagem (Copywriting)',
        description: 'Definimos a ordem dos argumentos, os textos de impacto e o roteiro exato que o visitante irá percorrer.',
      },
      {
        step: '03',
        title: 'Design sob Medida',
        description: 'Criamos interfaces visuais exclusivas com a identidade da sua marca, sem modelos prontos genéricos.',
      },
      {
        step: '04',
        title: 'Construção & Otimização',
        description: 'Implementação de alta performance, compatibilidade mobile e integração com seus canais de atendimento.',
      },
      {
        step: '05',
        title: 'Publicação & Acompanhamento',
        description: 'Lançamento seguro, monitoramento de acessos e treinamento da sua equipe para uso prático.',
      },
    ],

    // 7. Cases relacionados
    relatedCaseSlugs: ['portal-b2b-distribuicao'],

    // 8. FAQ
    faqs: [
      {
        question: 'O site da MAVITH usa modelos prontos de internet?',
        answer: 'Não. Cada layout é desenhado exclusivamente para o seu negócio, respeitando a identidade da sua marca, a psicologia do seu cliente e os objetivos comerciais da sua empresa.',
      },
      {
        question: 'O site funciona perfeitamente no celular?',
        answer: 'Sim, seguimos o padrão de responsividade total. Mais de 70% dos acessos B2B hoje acontecem em telas móveis, por isso a experiência no celular recebe o mesmo cuidado que a versão de desktop.',
      },
      {
        question: 'Vocês ajudam na redação dos textos e na organização das informações?',
        answer: 'Com certeza. Não exigimos que você nos entregue tudo pronto. Nós entrevistamos sua equipe para extrair a essência do negócio e redigimos os textos com foco em clareza comercial.',
      },
      {
        question: 'É possível integrar o formulário do site direto no WhatsApp e no nosso e-mail?',
        answer: 'Sim. Todos os pontos de contato são conectados aos canais onde sua equipe já atende, evitando que oportunidades fiquem esquecidas em caixas de entrada isoladas.',
      },
    ],
  },

  sistemas: {
    id: 'solucao-sistemas',
    slug: 'sistemas',
    pillarNumber: '02',
    title: 'Sistemas & Gestão Sob Medida',
    badge: 'Operação & Produtividade',
    accent: 'turquoise',
    headline: 'Seu negócio não precisa se adaptar a uma ferramenta. A ferramenta pode ser construída para o seu negócio.',
    tagline: 'Softwares engessados forçam sua equipe a trabalhar com gambiarras e planilhas paralelas. Criamos sistemas internos que acompanham com exatidão a lógica, os prazos e a cultura da sua empresa.',

    // 1. Problema
    problemHeadline: 'Sua equipe passa mais tempo alimentando sistemas complicados do que cuidando dos clientes?',
    problemDescription: 'Grande parte das empresas atinge um ponto de crescimento onde as ferramentas de mercado não servem mais: ou são simples demais e geram dezenas de planilhas desordenadas, ou são gigantescas, caras, cheias de campos inúteis e que ninguém da equipe gosta de usar.',
    symptoms: [
      {
        title: 'Proliferação de planilhas paralelas e desatualizadas',
        description: 'Cada setor cria seu próprio arquivo Excel porque o sistema oficial é burocrático e não entrega o que eles precisam.',
      },
      {
        title: 'Retrabalho e digitação manual duplicada',
        description: 'A mesma informação precisa ser digitada duas ou três vezes em locais diferentes para que a operação funcione.',
      },
      {
        title: 'Falta de visão clara do status de cada cliente',
        description: 'Ninguém sabe exatamente em que etapa está um projeto ou pedido sem perguntar diretamente no chat ou sala ao lado.',
      },
      {
        title: 'Custos de mensalidades por usuário que não param de subir',
        description: 'Licenças caras em dólar para ferramentas das quais sua equipe utiliza menos de 10% dos recursos disponíveis.',
      },
    ],

    // 2. Como podemos ajudar & Para quem serve
    targetAudience: [
      {
        segment: 'Empresas com fluxos de trabalho específicos',
        description: 'Negócios cujo processo produtivo ou de atendimento é um diferencial e não se encaixa em pacotes de prateleira.',
      },
      {
        segment: 'Operações com equipes externas ou múltiplas unidades',
        description: 'Empresas que precisam padronizar registros, checklists e coletas de dados em tempo real no campo.',
      },
      {
        segment: 'Prestadores de serviços recorrentes',
        description: 'Escritórios, oficinas e assessorias com volume alto de ordens de serviço, prazos e entregáveis técnicos.',
      },
      {
        segment: 'Empresas buscando independência de softwares legados',
        description: 'Negócios reféns de sistemas antigos, lentos e que não oferecem suporte nem evolução técnica.',
      },
    ],
    approachPhilosophy: 'Em vez de inventar uma rotina nova, mapeamos como a sua equipe já trabalha com sucesso e transformamos essa rotina em telas limpas, botões intuitivos e regras claras.',

    // 3. O que pode ser construído
    offerings: [
      {
        title: 'Sistemas Internos de Operação (Backoffice)',
        description: 'Painéis administrativos desenhados para centralizar ordens de serviço, cadastros, estoques de insumos e aprovações.',
        deliverables: ['Controle de acessos e permissões por cargo', 'Histórico completo de alterações por usuário', 'Alertas de prazos e pendências críticas', 'Exportação limpa de relatórios'],
        idealFor: 'Substituir pilhas de papel, mensagens desorganizadas e planilhas com fórmulas quebradas.',
      },
      {
        title: 'CRMs & Gestão Comercial Própria',
        description: 'Funis de vendas personalizados que refletem com fidelidade cada etapa da sua negociação, desde o primeiro contato até o pós-venda.',
        deliverables: ['Funil visual em Kanban', 'Registro simplificado de conversas e propostas', 'Lembretes automáticos de follow-up', 'Métricas de conversão por vendedor'],
        idealFor: 'Empresas que perdem vendas porque os vendedores esquecem de retornar no momento certo.',
      },
      {
        title: 'Portais do Cliente & Autoatendimento',
        description: 'Espaço digital onde seu cliente consulta o andamento do projeto, baixa relatórios, solicita demandas e aprova orçamentos.',
        deliverables: ['Login transparente e seguro', 'Linha do tempo do projeto em tempo real', 'Central de documentos e contratos', 'Canal estruturado de chamados'],
        idealFor: 'Reduzir em até 80% as mensagens de "como está meu pedido?" no WhatsApp da equipe.',
      },
      {
        title: 'Plataformas de Gestão Especializada',
        description: 'Aplicações desenhadas para regras de negócios complexas (cálculo de comissões, agendamento de frotas, orçamentos paramétricos).',
        deliverables: ['Cálculos automáticos sem risco de erro humano', 'Validações obrigatórias antes da emissão', 'Integração com sistemas fiscais ou ERPs', 'Interface rápida e sem distrações'],
        idealFor: 'Processos onde um erro humano de cálculo gera prejuízos financeiros imediatos.',
      },
    ],

    // 4. Exemplos práticos
    examples: [
      {
        scenario: 'Empresa de Instalação e Manutenção de Ar Condicionado',
        before: 'Técnicos anotavam ordens em fichas de papel. No final do dia, a secretária passava horas decifrando caligrafias para gerar notas e cobranças.',
        after: 'Aplicativo web leve no celular do técnico com checklist, fotos do serviço e assinatura digital do cliente. A ordem fecha automaticamente no financeiro.',
        impact: 'Eliminação de 100% dos extravios de fichas e faturamento 4 dias mais rápido de cada ordem.',
      },
      {
        scenario: 'Escritório de Perícias e Avaliações de Engenharia',
        before: 'Cada engenheiro salvava laudos em pastas locais. Quando um cliente pedia histórico, a equipe demorava dias para localizar arquivos antigos.',
        after: 'Sistema interno centralizado com busca instantânea por endereço, cliente ou número de processo, com versionamento seguro.',
        impact: 'Tempo de recuperação de documentos reduzido de 2 dias para menos de 15 segundos.',
      },
    ],

    // 5. Benefícios
    benefits: [
      {
        title: 'Aderência Perfeita',
        description: 'O software faz exatamente o que sua empresa precisa, sem campos sobrando e sem funções inúteis atrapalhando.',
        metricHighlight: '100% Customizado',
      },
      {
        title: 'Redução de Erro Humano',
        description: 'Regras de validação que impedem cadastros incompletos, cálculos errados ou ordens sem responsável definido.',
        metricHighlight: 'Segurança Operacional',
      },
      {
        title: 'Sem Mensalidade por Usuário',
        description: 'O sistema é um ativo da sua empresa. Você pode cadastrar novos colaboradores sem medo da fatura explodir no final do mês.',
        metricHighlight: 'Ativo Próprio',
      },
      {
        title: 'Velocidade e Facilidade de Adoção',
        description: 'Telas limpas e objetivas que qualquer novo funcionário aprende a operar em menos de uma tarde de treinamento.',
        metricHighlight: 'Curva Rápida de Uso',
      },
    ],

    // 6. Como funciona / Processo
    processSteps: [
      {
        step: '01',
        title: 'Mapeamento do Fluxo Real',
        description: 'Sentamos com quem realmente opera o dia a dia para entender o passo a passo, as dores e os atalhos atuais.',
      },
      {
        step: '02',
        title: 'Prototipagem Interativa',
        description: 'Desenhamos as telas do sistema para que a equipe valide os botões, campos e etapas antes de qualquer código ser escrito.',
      },
      {
        step: '03',
        title: 'Desenvolvimento Incremental',
        description: 'Construção modular com entregas frequentes para que você teste os módulos principais em funcionamento real.',
      },
      {
        step: '04',
        title: 'Migração de Dados & Testes',
        description: 'Trazemos os dados das suas planilhas antigas e realizamos simulações rigorosas de uso diário.',
      },
      {
        step: '05',
        title: 'Treinamento & Acompanhamento',
        description: 'Treinamento direto dos usuários e suporte próximo durante as primeiras semanas de operação plena.',
      },
    ],

    // 7. Cases relacionados
    relatedCaseSlugs: ['portal-b2b-distribuicao', 'sistema-gestao-ordens-servico'],

    // 8. FAQ
    faqs: [
      {
        question: 'Um sistema sob medida demora anos para ficar pronto?',
        answer: 'Não na MAVITH. Trabalhamos com metodologia ágil e entregas por fases. Muitas vezes a primeira versão funcional (com o módulo mais crítico) entra em uso em questão de semanas, gerando alívio operacional imediato.',
      },
      {
        question: 'O que acontece com os dados que já temos em planilhas hoje?',
        answer: 'Nós cuidamos da higienização e migração dos dados históricos das suas planilhas para a nova base segura do sistema, sem interrupção abrupta do seu trabalho.',
      },
      {
        question: 'O sistema precisa ser instalado no computador de cada funcionário?',
        answer: 'Não. Desenvolvemos aplicações web modernas na nuvem. Sua equipe pode acessar com segurança pelo navegador do computador, tablet ou celular, em qualquer lugar com internet.',
      },
      {
        question: 'Se a minha empresa crescer e precisar de novos botões e relatórios?',
        answer: 'A arquitetura é modular justamente para permitir que novos campos, relatórios e permissões sejam incorporados com facilidade ao longo dos anos.',
      },
    ],
  },

  ia: {
    id: 'solucao-ia',
    slug: 'ia',
    pillarNumber: '03',
    title: 'Inteligência Artificial Aplicada',
    badge: 'Produtividade & Escala',
    accent: 'orange',
    headline: 'Coloque inteligência para trabalhar junto com sua equipe.',
    tagline: 'A Inteligência Artificial não serve para substituir o discernimento humano, mas para eliminar a sobrecarga cognitiva e as tarefas mecânicas que drenam o tempo dos seus profissionais mais qualificados.',

    // 1. Problema
    problemHeadline: 'Seus melhores profissionais estão presos lendo documentos repetitivos e respondendo as mesmas dúvidas?',
    problemDescription: 'Toda empresa acumula montanhas de informações em PDFs, tabelas, e-mails e conversas. No entanto, quando um cliente precisa de uma resposta rápida ou um gestor precisa de um resumo, alguém altamente pago precisa parar o que está fazendo para vasculhar arquivos manualmente.',
    symptoms: [
      {
        title: 'Demora para responder clientes fora do horário comercial',
        description: 'Dúvidas frequentes de compradores chegam à noite ou finais de semana e ficam horas sem atendimento, esfriando o interesse.',
      },
      {
        title: 'Horas gastas na triagem e leitura de documentos',
        description: 'Profissionais seniores gastando até 30% da jornada apenas checando conformidade de arquivos ou extraindo dados de notas fiscais.',
      },
      {
        title: 'Conhecimento da empresa disperso na cabeça de poucos',
        description: 'Quando o colaborador mais antigo não está, ninguém encontra os manuais internos ou regras de precificação corretas.',
      },
      {
        title: 'Insegurança com ferramentas genéricas de IA públicas',
        description: 'Receio legítimo de colar dados confidenciais de clientes no ChatGPT aberto sem governança, privacidade ou contexto do negócio.',
      },
    ],

    // 2. Como podemos ajudar & Para quem serve
    targetAudience: [
      {
        segment: 'Escritórios de Advocacia, Contabilidade & Finanças',
        description: 'Operações com alto volume de leitura técnica, pareceres, cruzamento de normas e conferência contratual.',
      },
      {
        segment: 'Centrais de Atendimento & Suporte Técnico',
        description: 'Empresas com centenas de dúvidas recorrentes de clientes sobre produtos, prazos e procedimentos.',
      },
      {
        segment: 'Equipes Comerciais de Vendas Complexas',
        description: 'Vendedores que precisam de respostas instantâneas sobre catálogo, estoque e políticas comerciais durante a ligação.',
      },
      {
        segment: 'Clínicas & Prestadores de Cuidados',
        description: 'Recepção sobrecarregada com agendamentos, orientações de exames e lembretes de preparo.',
      },
    ],
    approachPhilosophy: 'Não implementamos "IA de vitrine". Treinamos modelos sobre os manuais, regras e limites reais da sua empresa, garantindo privacidade estrita e respostas 100% verificáveis.',

    // 3. O que pode ser construído
    offerings: [
      {
        title: 'Agentes Virtuais de Triagem & Qualificação',
        description: 'Assistentes inteligentes que conversam naturalmente com novos clientes, coletam dados iniciais, respondem dúvidas e direcionam apenas casos qualificados para a equipe.',
        deliverables: ['Comunicação fluida em linguagem natural', 'Integração direta com WhatsApp Business', 'Identificação de intenção e urgência', 'Encaminhamento organizado para o atendente correto'],
        idealFor: 'Reduzir o tempo de espera do cliente de horas para segundos, mantendo tom humanizado.',
      },
      {
        title: 'Assistentes de Conhecimento Interno (Brain Corporativo)',
        description: 'Uma IA privada que leu todos os manuais, procedimentos operacionais (POPs) e tabelas da sua empresa e responde qualquer dúvida dos funcionários instantaneamente.',
        deliverables: ['Pesquisa semântica em base confidencial', 'Citação da fonte exata do documento onde achou a resposta', 'Proteção estrita de dados sigilosos', 'Atualização fácil com novos documentos'],
        idealFor: 'Onboarding acelerado de novos colaboradores e consulta rápida de normas internas.',
      },
      {
        title: 'Leitura & Extração Inteligente de Documentos',
        description: 'Sistemas que recebem PDFs, contratos, notas ou pedidos em imagem, extraem os campos críticos com precisão e preenchem seu sistema automaticamente.',
        deliverables: ['Reconhecimento ótico avançado (OCR + IA)', 'Cruzamento e validação de dados inconsistentes', 'Alertas para divergências ou valores suspeitos', 'Alimentação direta do banco de dados'],
        idealFor: 'Eliminar a digitação manual de notas, faturas e certidões na rotina financeira.',
      },
      {
        title: 'Geração Automatizada de Rascunhos & Relatórios',
        description: 'Ferramentas que combinam dados do sistema para criar minutas de relatórios, resumos de atendimento ou propostas comerciais prontas para revisão humana.',
        deliverables: ['Modelos de texto alinhados ao tom de voz da marca', 'Revisão humana antes do disparo final', 'Padronização de relatórios técnicos', 'Economia de até 70% do tempo de redação'],
        idealFor: 'Equipes técnicas que precisam redigir dezenas de pareceres ou resumos executivos semanais.',
      },
    ],

    // 4. Exemplos práticos
    examples: [
      {
        scenario: 'Escritório Contábil com 250 Clientes Ativos',
        before: 'A equipe de atendimento recebia centenas de mensagens diárias com pedidos triviais: "Qual é a guia do FGTS deste mês?", "Qual a documentação para admissão?".',
        after: 'Agente de IA integrado ao WhatsApp responde instantaneamente com base nas regras contábeis atualizadas e emite orientações padronizadas.',
        impact: 'Redução de 75% no volume de chamados triviais, liberando analistas para planejamento tributário consultivo.',
      },
      {
        scenario: 'Distribuidora com Catálogo de 4.000 Itens Técnicos',
        before: 'Novos vendedores demoravam até 6 meses para aprender as compatibilidades entre peças e sempre tinham que parar a gerência para tirar dúvidas.',
        after: 'Assistente interno de IA treinado nos manuais de fabricantes: o vendedor digita a marca do equipamento e recebe as peças compatíveis em 3 segundos.',
        impact: 'Tempo de adaptação do vendedor reduzido pela metade e fim dos orçamentos com peças erradas.',
      },
    ],

    // 5. Benefícios
    benefits: [
      {
        title: 'Disponibilidade 24/7 sem Cansaço',
        description: 'Seus clientes recebem orientações imediatas e qualificadas mesmo às 23h de um domingo.',
        metricHighlight: 'Atendimento Contínuo',
      },
      {
        title: 'Respostas Confiáveis e Delimitadas',
        description: 'A IA só responde aquilo que está documentado nos materiais aprovados pela sua diretoria, sem inventar informações.',
        metricHighlight: 'Zero Alucinação',
      },
      {
        title: 'Valorização do Talento Humano',
        description: 'Sua equipe para de fazer papel de robô e passa a se dedicar a relacionamentos, estratégias e fechamentos.',
        metricHighlight: '+ Tempo Nobre',
      },
      {
        title: 'Privacidade e Sigilo Empresarial',
        description: 'Ambiente fechado onde nenhum dado da sua empresa ou do seu cliente é utilizado para treinar modelos públicos externos.',
        metricHighlight: 'Segurança Total',
      },
    ],

    // 6. Como funciona / Processo
    processSteps: [
      {
        step: '01',
        title: 'Seleção do Caso de Uso de Alto Retorno',
        description: 'Identificamos qual gargalo atual gera mais perda de tempo ou atrito com clientes para começar pelo maior impacto.',
      },
      {
        step: '02',
        title: 'Organização da Base de Conhecimento',
        description: 'Reunimos e higienizamos os manuais, perguntas frequentes e procedimentos que servirão de fonte única da verdade.',
      },
      {
        step: '03',
        title: 'Construção & Calibração de Regras',
        description: 'Configuramos o agente com limites estritos de segurança, tom de voz adequado e rotas de encaminhamento humano.',
      },
      {
        step: '04',
        title: 'Bateria de Testes com Cenários Reais',
        description: 'Simulamos centenas de perguntas complexas e pegadinhas para garantir que as respostas sejam impecáveis.',
      },
      {
        step: '05',
        title: 'Ativação & Monitoramento Contínuo',
        description: 'Lançamento assistido com painel de auditoria para acompanhar as conversas e refinar respostas continuamente.',
      },
    ],

    // 7. Cases relacionados
    relatedCaseSlugs: ['agente-ia-triagem-contabil'],

    // 8. FAQ
    faqs: [
      {
        question: 'A Inteligência Artificial vai inventar respostas erradas (alucinar)?',
        answer: 'Não no nosso modelo. Implementamos arquitetura RAG (Recuperação Aumentada por Conhecimento), o que significa que o agente só pode responder com base em trechos literais dos documentos oficiais da sua empresa. Se ele não souber, ele é instruído a encaminhar para um atendente humano.',
      },
      {
        question: 'Os dados da minha empresa ficam seguros e confidenciais?',
        answer: 'Sim, totalmente. Utilizamos conexões corporativas com criptografia onde os seus dados não são compartilhados nem aproveitados para treinamento de inteligências públicas de mercado.',
      },
      {
        question: 'A IA substitui nossos funcionários?',
        answer: 'Não. Nosso foco é dar um assistente para cada profissional. Ela absorve o volume mecânico inicial para que sua equipe atue no momento decisivo com mais energia e precisão.',
      },
      {
        question: 'Funciona no WhatsApp?',
        answer: 'Sim, integramos diretamente com a API Oficial do WhatsApp Business, garantindo estabilidade, sem risco de banimento de número.',
      },
    ],
  },

  automacao: {
    id: 'solucao-automacao',
    slug: 'automacao',
    pillarNumber: '04',
    title: 'Automação de Processos & Integrações',
    badge: 'Eficiência Operacional',
    accent: 'orange',
    headline: 'Automatize o que não precisa continuar sendo manual.',
    tagline: 'Se uma tarefa na sua empresa envolve copiar dados de uma tela para colar em outra, ela pode — e deve — ser automatizada para evitar falhas, atrasos e frustração na equipe.',

    // 1. Problema
    problemHeadline: 'Quantas horas por semana sua equipe perde copiando dados entre sistemas que não conversam?',
    problemDescription: 'Uma empresa moderna utiliza diversos canais: WhatsApp, e-mail, gateway de pagamento, emissor de notas fiscais, ERP e planilhas. No entanto, quando essas ferramentas operam isoladas, os funcionários viram "pontes humanas" de transferência de dados, gerando gargalos e falhas constantes.',
    symptoms: [
      {
        title: 'Esquecimentos no pós-venda e entrega',
        description: 'O cliente comprou, mas o setor de expedição só ficou sabendo horas depois porque o vendedor esqueceu de avisar por e-mail.',
      },
      {
        title: 'Notificações manuais de cobrança e lembretes',
        description: 'Pessoas gastando horas mandando mensagens manuais para lembrar clientes de faturas, agendamentos ou reuniões.',
      },
      {
        title: 'Erros de digitação em notas fiscais e contratos',
        description: 'Dados de CNPJ ou valores digitados com erro que geram retrabalho fiscal e desgaste com o comprador.',
      },
      {
        title: 'Atrasos no atendimento a novos contatos',
        description: 'O lead preenche um formulário no site e demora mais de 4 horas para receber qualquer resposta ou confirmação.',
      },
    ],

    // 2. Como podemos ajudar & Para quem serve
    targetAudience: [
      {
        segment: 'Empresas com Múltiplos Softwares Desconectados',
        description: 'Operações que usam um sistema para vendas, outro para estoque e outro para financeiro sem integração nativa.',
      },
      {
        segment: 'Prestadores de Serviços com Agendamentos Recorrentes',
        description: 'Negócios onde a ausência do cliente (no-show) gera prejuízos diretos na agenda de atendimento.',
      },
      {
        segment: 'Comércios Eletrônicos & Distribuidores B2B',
        description: 'Empresas que precisam sincronizar status de estoque, emissão de faturamento e rastreio de entregas instantaneamente.',
      },
      {
        segment: 'Departamentos Administrativos e Financeiros',
        description: 'Setores sobrecarregados com conciliação bancária, conferência de comprovantes e envio de recibos.',
      },
    ],
    approachPhilosophy: 'Em vez de contratar mais pessoas apenas para lidar com volume mecânico, criamos conexões automáticas entre seus sistemas que trabalham em silêncio 24 horas por dia.',

    // 3. O que pode ser construído
    offerings: [
      {
        title: 'Workflows de Comunicação & Notificações Automáticas',
        description: 'Disparo de mensagens instantâneas via WhatsApp, e-mail ou SMS quando um evento acontece (novo pedido, confirmação de consulta, código de rastreio).',
        deliverables: ['Lembretes inteligentes de agendamento', 'Redução drástica de faltas (no-show)', 'Pesquisas automáticas de satisfação (NPS)', 'Comunicação padronizada e profissional'],
        idealFor: 'Clínicas, escritórios e serviços que sofrem com esquecimentos de clientes.',
      },
      {
        title: 'Integrações entre Sistemas & APIs',
        description: 'Conexão direta entre seu CRM, ERP, gateways de pagamento (Pix/Cartão) e plataformas de marketing para que a informação flua sem intervenção manual.',
        deliverables: ['Sincronização bidirecional em tempo real', 'Tratamento inteligente de erros e falhas', 'Fim do retrabalho de digitação duplicada', 'Logs transparentes de cada transação executada'],
        idealFor: 'Empresas onde o financeiro precisa digitar dados que o comercial já coletou.',
      },
      {
        title: 'Automação Financeira & Cobrança Preventiva',
        description: 'Geração automática de boletos, Pix dinâmico, emissão de NF-e e régua de lembretes amigáveis antes e após o vencimento.',
        deliverables: ['Régua de cobrança automática por WhatsApp', 'Baixa automática após confirmação do Pix', 'Emissão de nota fiscal acionada por pagamento', 'Redução média de 35% na inadimplência'],
        idealFor: 'Empresas com mensalidades ou vendas faturadas que sofrem com atrasos por simples esquecimento.',
      },
      {
        title: 'Esteiras de Entrada de Leads & Distribuição Comercial',
        description: 'Assim que um potencial cliente preenche o formulário, ele recebe uma saudação imediata e a oportunidade cai no WhatsApp do vendedor da vez.',
        deliverables: ['Distribuição justa (roleta) entre vendedores', 'Alerta sonoro de lead quente na equipe', 'Registro automático no funil comercial', 'Contato inicial em menos de 2 minutos'],
        idealFor: 'Times de vendas que perdem negócios por demorar para atender clientes interessados.',
      },
    ],

    // 4. Exemplos práticos
    examples: [
      {
        scenario: 'Clínica Odontológica Especializada',
        before: 'A secretária passava 3 horas toda tarde ligando para 40 pacientes para confirmar as consultas do dia seguinte. Cerca de 25% dos pacientes ainda faltavam sem avisar.',
        after: 'Automação via WhatsApp envia mensagem personalizada com botões "Confirmar" ou "Reagendar" 24h antes. As respostas atualizam a agenda médica em tempo real.',
        impact: 'A taxa de faltas caiu para menos de 6% e a secretária ganhou 3 horas livres por dia para cuidar da recepção física.',
      },
      {
        scenario: 'Distribuidora de Peças Automotivas',
        before: 'Vendedores fechavam pedidos no WhatsApp e tinham que digitar tudo no ERP para liberar o faturamento. Pedidos ficavam acumulados e atrasavam o caminhão.',
        after: 'Formulário rápido que gera a pré-ordem no ERP, checa o estoque e já avisa o almoxarifado para separação imediata.',
        impact: 'Tempo de expedição reduzido de 5 horas para 45 minutos no mesmo dia útil.',
      },
    ],

    // 5. Benefícios
    benefits: [
      {
        title: 'Zero Esquecimentos',
        description: 'Toda tarefa programada é executada religiosamente no horário certo, sem depender da memória de ninguém.',
        metricHighlight: '100% Pontualidade',
      },
      {
        title: 'Tempo Recuperado para a Equipe',
        description: 'Sua equipe ganha horas preciosas todas as semanas para focar no que gera receita de verdade.',
        metricHighlight: '+15h Semanais',
      },
      {
        title: 'Experiência Superior do Cliente',
        description: 'O cliente se sente acolhido e bem informado em cada etapa com atualizações ágeis e transparentes.',
        metricHighlight: 'Satisfação Alta',
      },
      {
        title: 'Redução de Custos Operacionais',
        description: 'Sua empresa consegue aumentar o volume de clientes atendidos sem precisar inflar o quadro de funcionários operacionais.',
        metricHighlight: 'Escalabilidade',
      },
    ],

    // 6. Como funciona / Processo
    processSteps: [
      {
        step: '01',
        title: 'Auditoria de Gargalos Manuais',
        description: 'Identificamos onde ocorrem as transferências manuais de dados mais repetitivas e sujeitas a falhas.',
      },
      {
        step: '02',
        title: 'Desenho da Lógica de Integração',
        description: 'Definimos os gatilhos (quando algo acontece) e as ações automáticas (o que deve ser executado em cada sistema).',
      },
      {
        step: '03',
        title: 'Construção Segura com Redundância',
        description: 'Criamos as conexões com proteções contra duplicidade de dados e rotinas de contingência em caso de oscilações.',
      },
      {
        step: '04',
        title: 'Testes em Ambiente Controlado',
        description: 'Validamos centenas de disparos e atualizações simulando todas as variações possíveis de clientes e pagamentos.',
      },
      {
        step: '05',
        title: 'Operação Ativa & Monitoramento',
        description: 'Ligamos as automações com alertas para os gestores e relatórios de tempo economizado.',
      },
    ],

    // 7. Cases relacionados
    relatedCaseSlugs: ['portal-b2b-distribuicao', 'agente-ia-triagem-contabil'],

    // 8. FAQ
    faqs: [
      {
        question: 'Preciso trocar os sistemas que já uso para ter automação?',
        answer: 'Geralmente não. Nós conectamos as ferramentas que você já tem (como ERPs, bancos, CRMs e WhatsApp) através de APIs e conectores modernos, preservando seus investimentos atuais.',
      },
      {
        question: 'E se a internet cair ou um sistema falhar momentaneamente?',
        answer: 'Construímos mecanismos de re-tentativa automática (retry queue). Se um sistema estiver temporariamente indisponível, a automação guarda a tarefa com segurança e executa assim que o serviço normalizar, sem perder nenhum dado.',
      },
      {
        question: 'O cliente vai perceber que é uma mensagem automática?',
        answer: 'Configuramos textos humanizados com o nome do cliente, saudação adequada ao horário e informações pertinentes ao pedido dele, eliminando aquele aspecto frio de "robô engessado".',
      },
      {
        question: 'Quanto tempo leva para colocar as primeiras automações no ar?',
        answer: 'Muitos fluxos de comunicação e integração direta começam a rodar em poucos dias, gerando alívio imediato para a equipe.',
      },
    ],
  },

  dashboards: {
    id: 'solucao-dashboards',
    slug: 'dashboards',
    pillarNumber: '05',
    title: 'Dashboards, BI & Análise de Dados',
    badge: 'Visibilidade & Decisão',
    accent: 'blue',
    headline: 'Dados não servem apenas para serem armazenados.',
    tagline: 'Ter um monte de números espalhados em sistemas diferentes não ajuda a tomar decisões. Transformamos dados dispersos em visões limpas e em tempo real para que você lidere com convicção e clareza.',

    // 1. Problema
    problemHeadline: 'Você sabe exatamente quanto a sua empresa lucrou esta semana ou precisa esperar o fechamento do mês que vem?',
    problemDescription: 'A maioria dos empresários gerencia negócios complexos olhando pelo espelho retrovisor: relatórios estáticos em PDF entregues com semanas de atraso, planilhas que ninguém tem certeza se as fórmulas estão certas e divergências entre o faturamento e o financeiro.',
    symptoms: [
      {
        title: 'Horas perdidas montando apresentações no fim do mês',
        description: 'Gestores gastando dias inteiros exportando arquivos, cruzando colunas no Excel e formatando gráficos manuais.',
      },
      {
        title: 'Divergência entre números de setores diferentes',
        description: 'O setor de vendas diz que vendeu 100, o financeiro diz que entrou 80 e a logística diz que entregou 70. Ninguém sabe quem está certo.',
      },
      {
        title: 'Decisões baseadas no "feeling" por falta de visão imediata',
        description: 'Dúvidas críticas sobre contratações, compras ou investimentos tomadas na intuição por falta de indicadores confiáveis.',
      },
      {
        title: 'Inadimplência e gargalos descobertos tarde demais',
        description: 'Descobrir que um cliente estratégico está há 60 dias sem pagar ou que um produto está dando prejuízo apenas no fechamento anual.',
      },
    ],

    // 2. Como podemos ajudar & Para quem serve
    targetAudience: [
      {
        segment: 'Diretoria & Sócios Executivos',
        description: 'Líderes que precisam de um painel único no celular para checar a saúde financeira e operacional a qualquer momento.',
      },
      {
        segment: 'Gestores Financeiros & Controladoria',
        description: 'Profissionais responsáveis por fluxo de caixa projetado, DRE gerencial, margem de contribuição e ponto de equilíbrio.',
      },
      {
        segment: 'Líderes Comerciais & de Vendas',
        description: 'Coordenadores que precisam monitorar metas em tempo real, ticket médio por consultor e taxa de perda de oportunidades.',
      },
      {
        segment: 'Operações de Saúde, Serviços & Logística',
        description: 'Negócios que dependem de indicadores de ocupação por sala, tempo médio de atendimento e custo por unidade entregue.',
      },
    ],
    approachPhilosophy: 'Não montamos painéis cheios de gráficos confusos só para parecer complexo. Definimos os 3 a 5 indicadores vitais que realmente movem o ponteiro do seu negócio e colocamos eles em primeiro plano.',

    // 3. O que pode ser construído
    offerings: [
      {
        title: 'Dashboards Executivos de Gestão Financeira',
        description: 'Visão consolidada de entradas, saídas, fluxo de caixa diário, inadimplência em aberto e DRE gerencial atualizada automaticamente.',
        deliverables: ['DRE dinâmico em tempo real', 'Previsibilidade de caixa para os próximos 30/60 dias', 'Identificação rápida de custos fora do padrão', 'Compatível com telas de reunião e celulares'],
        idealFor: 'Eliminar surpresas na conta bancária no final do mês.',
      },
      {
        title: 'Painéis Comerciais & Performance de Vendas',
        description: 'Acompanhamento do funil de vendas, ticket médio por região, atingimento de metas diárias e comparativo histórico de crescimento.',
        deliverables: ['Mural de metas em tempo real', 'Conversão por canal de aquisição', 'Taxa de recompra de clientes antigos', 'Identificação dos produtos mais lucrativos'],
        idealFor: 'Direcionar a equipe de vendas com base em dados, e não em palpites.',
      },
      {
        title: 'Monitoramento Operacional & Produtividade',
        description: 'Métricas de tempo de resposta, volume de entregas, ocupação de capacidade instalada e gargalos de atendimento.',
        deliverables: ['Indicadores de lead time operacional', 'Status de ordens em andamento', 'Índice de retrabalho ou devoluções', 'Alertas automáticos para metas em risco'],
        idealFor: 'Manter a operação rodando no ritmo planejado sem desvios silenciosos.',
      },
      {
        title: 'Relatórios Gerenciais Automatizados',
        description: 'Geração e envio periódico (semanal ou mensal) de resumos executivos direto no e-mail ou WhatsApp da diretoria.',
        deliverables: ['Resumo em uma página (One-page report)', 'Destaque dos desvios mais importantes da semana', 'Disparo automático sem trabalho manual', 'Acesso seguro por nível hierárquico'],
        idealFor: 'Diretores e conselheiros que querem apenas os números cruciais sem precisar abrir sistemas.',
      },
    ],

    // 4. Exemplos práticos
    examples: [
      {
        scenario: 'Clínica Médica Multidisciplinar com 12 Salas',
        before: 'O faturamento das salas era calculado no dia 10 do mês seguinte cruzando recibos físicos. Descobriram tardiamente que duas salas estavam dando prejuízo constante.',
        after: 'Dashboard operacional que mostra em tempo real a taxa de ocupação de cada sala, faturamento por especialista e repasse exato a pagar.',
        impact: 'Aumento imediato de 18% na ocupação após remanejamento de horários ociosos.',
      },
      {
        scenario: 'Empresa de Serviços de Facilities e Manutenção',
        before: 'Planilhas dispersas com mais de 80 contratos vigentes. Ninguém sabia quando venciam os reajustes de IPCA e muitos contratos ficaram defasados por 2 anos.',
        after: 'Painel gerencial com calendário de reajustes contratuais, margem de contribuição por contrato e alertas de margem negativa.',
        impact: 'Recuperação de mais de R$ 140.000 em receitas que estavam defasadas por falta de acompanhamento.',
      },
    ],

    // 5. Benefícios
    benefits: [
      {
        title: 'Clareza Absoluta em Tempo Real',
        description: 'Você sabe exatamente como sua empresa está se comportando agora, sem esperar o fim do mês.',
        metricHighlight: 'Visão Imediata',
      },
      {
        title: 'Fim das Discussões sobre Números',
        description: 'Uma única fonte confiável da verdade para todos os diretores e sócios da empresa.',
        metricHighlight: 'Fonte Única',
      },
      {
        title: 'Ação Preventiva Rápida',
        description: 'Identifique quedas de vendas ou subidas de custos antes que se transformem em rombos financeiros.',
        metricHighlight: 'Correção Antecipada',
      },
      {
        title: 'Liberdade para Gestores',
        description: 'Sua equipe financeira para de gastar semanas montando planilhas e passa a atuar na análise de cenários.',
        metricHighlight: 'Zero Retrabalho',
      },
    ],

    // 6. Como funciona / Processo
    processSteps: [
      {
        step: '01',
        title: 'Mapeamento dos Indicadores Críticos',
        description: 'Definimos quais são as métricas essenciais que a diretoria realmente precisa acompanhar para tomar decisões.',
      },
      {
        step: '02',
        title: 'Conexão Segura com as Fontes de Dados',
        description: 'Integramos os bancos de dados do seu ERP, CRM, sistemas bancários ou planilhas existentes.',
      },
      {
        step: '03',
        title: 'Tratamento & Higienização dos Dados',
        description: 'Criamos regras de cálculo precisas para que divergências entre setores sejam tratadas e resolvidas.',
      },
      {
        step: '04',
        title: 'Design Visual Objetivo & Intuitivo',
        description: 'Estruturação de telas limpas, com contrastes claros e hierarquia visual sem poluição visual.',
      },
      {
        step: '05',
        title: 'Validação com a Diretoria & Treinamento',
        description: 'Apresentação prática, testes de cenários reais e liberação de acessos em computadores e celulares.',
      },
    ],

    // 7. Cases relacionados
    relatedCaseSlugs: ['dashboard-bi-financeiro-clinica'],

    // 8. FAQ
    faqs: [
      {
        question: 'Preciso ter um banco de dados sofisticado para ter um dashboard?',
        answer: 'Não necessariamente. Conseguimos conectar desde bancos de dados modernos até sistemas em nuvem, ERPs e inclusive planilhas de trabalho consolidadas, estruturando os dados de forma segura.',
      },
      {
        question: 'As informações ficam atualizadas sozinhas?',
        answer: 'Sim. Os dados são sincronizados de forma programada e automática (diariamente, de hora em hora ou em tempo real, conforme a necessidade do processo).',
      },
      {
        question: 'Posso acessar o painel pelo meu celular ou tablet?',
        answer: 'Sim, todos os nossos dashboards são construídos com design responsivo e telas otimizadas para leitura rápida na tela do smartphone.',
      },
      {
        question: 'Os dados financeiros da minha empresa estarão seguros?',
        answer: 'Absolutamente. Aplicamos rigoroso controle de permissões por login, criptografia de ponta a ponta e seus dados não saem do ambiente seguro configurado para o seu negócio.',
      },
    ],
  },
};

export const SOLUTIONS_LIST = Object.values(SOLUTIONS_DATA);

export function getSolutionBySlug(slug: string): SolutionData | undefined {
  return SOLUTIONS_DATA[slug as SolutionSlug];
}
