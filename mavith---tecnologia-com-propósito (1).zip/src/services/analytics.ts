import { AnalyticsEvent, AnalyticsEventType, LeadPayload, LeadProjectType } from '../types/lead';

// Global window extensions for GA4, GTM, Meta Pixel
declare global {
  interface Window {
    dataLayer?: any[];
    gtag?: (...args: any[]) => void;
    fbq?: (...args: any[]) => void;
  }
}

const EVENTS_STORAGE_KEY = 'mavith_analytics_events';
const LEADS_STORAGE_KEY = 'mavith_crm_leads';

// Official MAVITH WhatsApp contact number
export const MAVITH_WHATSAPP_NUMBER = '5511988887777'; // Format: Country code + Area + Number
export const MAVITH_DEFAULT_WHATSAPP_MESSAGE =
  'Olá, MAVITH! Gostaria de conversar sobre uma solução digital para minha empresa.';

/**
 * Extracts UTM parameters or referrer to enrich CRM lead context
 */
export function getLeadContext() {
  if (typeof window === 'undefined') {
    return {
      source: 'direct',
      campaign: 'organico',
      page: '/',
    };
  }

  const searchParams = new URLSearchParams(window.location.search);
  const hash = window.location.hash || '/';
  const referrer = document.referrer ? new URL(document.referrer).hostname : 'direto';

  const source =
    searchParams.get('utm_source') ||
    (referrer !== 'direto' ? `ref:${referrer}` : 'direto');
  const campaign = searchParams.get('utm_campaign') || 'organico';

  return {
    source,
    campaign,
    page: hash,
  };
}

/**
 * Builds standard WhatsApp deep-link with URL-encoded pre-filled message
 */
export function buildWhatsAppLink(customMessage?: string): string {
  const message = customMessage || MAVITH_DEFAULT_WHATSAPP_MESSAGE;
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${MAVITH_WHATSAPP_NUMBER}?text=${encoded}`;
}

/**
 * Analytics & Tracking Engine
 */
class AnalyticsService {
  private events: AnalyticsEvent[] = [];

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem(EVENTS_STORAGE_KEY);
        if (stored) {
          this.events = JSON.parse(stored);
        }
      } catch (e) {
        console.warn('Could not restore analytics events from localStorage');
      }
    }
  }

  /**
   * Dispatch and record an analytics event
   */
  public track(event: AnalyticsEventType, params: Record<string, any> = {}) {
    const page = typeof window !== 'undefined' ? window.location.hash || '/' : '/';
    const timestamp = new Date().toISOString();

    const record: AnalyticsEvent = {
      id: `evt-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      event,
      params,
      timestamp,
      page,
    };

    this.events.unshift(record);
    if (this.events.length > 100) {
      this.events = this.events.slice(0, 100);
    }

    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(EVENTS_STORAGE_KEY, JSON.stringify(this.events));
      } catch (e) {
        // ignore storage quota errors
      }

      // 1. Google Tag Manager (GTM)
      if (window.dataLayer && Array.isArray(window.dataLayer)) {
        window.dataLayer.push({
          event,
          ...params,
          page,
          timestamp,
        });
      }

      // 2. Google Analytics 4 (GA4)
      if (typeof window.gtag === 'function') {
        window.gtag('event', event, {
          ...params,
          page_location: page,
        });
      }

      // 3. Meta Pixel (Facebook Pixel)
      if (typeof window.fbq === 'function') {
        if (event === 'form_submitted') {
          window.fbq('track', 'Lead', {
            content_name: params.lead_service,
            content_category: 'Tech Services',
          });
        } else if (event === 'whatsapp_click') {
          window.fbq('trackCustom', 'WhatsAppClick', params);
        } else {
          window.fbq('trackCustom', event, params);
        }
      }

      // Log in dev environment for auditing
      console.log(`[MAVITH Analytics] ${event}`, record);
    }

    return record;
  }

  // Specialized convenience helpers

  public trackCtaClick(ctaName: string, location: string, target?: string) {
    return this.track('cta_click', {
      cta_name: ctaName,
      location,
      target: target || 'contact_modal',
    });
  }

  public trackWhatsAppClick(location: string, prefilledMessage?: string) {
    return this.track('whatsapp_click', {
      location,
      message: prefilledMessage || MAVITH_DEFAULT_WHATSAPP_MESSAGE,
      timestamp: new Date().toISOString(),
    });
  }

  public trackFormStarted(formName = 'contact_lead_form', field = 'nome') {
    return this.track('form_started', {
      form_name: formName,
      first_field: field,
    });
  }

  public trackFormSubmitted(payload: Partial<LeadPayload>) {
    return this.track('form_submitted', {
      lead_service: payload.projectType,
      lead_company: payload.company,
      lead_page: payload.lead_page,
      lead_source: payload.lead_source,
    });
  }

  public trackPortfolioViewed(projectSlug: string, category = 'all') {
    return this.track('portfolio_viewed', {
      project_slug: projectSlug,
      category,
    });
  }

  public trackServiceViewed(solutionSlug: string) {
    return this.track('service_viewed', {
      solution_slug: solutionSlug,
    });
  }

  public trackArticleViewed(articleSlug: string, category = 'all') {
    return this.track('article_viewed', {
      article_slug: articleSlug,
      category,
    });
  }

  public getRecentEvents(): AnalyticsEvent[] {
    return [...this.events];
  }

  public clearEvents() {
    this.events = [];
    if (typeof window !== 'undefined') {
      localStorage.removeItem(EVENTS_STORAGE_KEY);
    }
  }
}

export const analytics = new AnalyticsService();

/**
 * CRM Lead Storage & Architecture Dispatcher
 */
class CRMService {
  public getStoredLeads(): LeadPayload[] {
    if (typeof window === 'undefined') return [];
    try {
      const stored = localStorage.getItem(LEADS_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (e) {
      return [];
    }
  }

  public saveLead(
    leadData: Omit<LeadPayload, 'id' | 'lead_timestamp' | 'status' | 'lead_source' | 'lead_campaign' | 'lead_page' | 'lead_service'> & {
      lead_source?: string;
      lead_campaign?: string;
      lead_page?: string;
      lead_service?: string;
    }
  ): LeadPayload {
    const context = getLeadContext();

    const fullLead: LeadPayload = {
      id: `lead-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      name: leadData.name,
      company: leadData.company,
      whatsapp: leadData.whatsapp,
      email: leadData.email,
      projectType: leadData.projectType,
      message: leadData.message,
      lead_source: leadData.lead_source || context.source,
      lead_campaign: leadData.lead_campaign || context.campaign,
      lead_page: leadData.lead_page || context.page,
      lead_service: leadData.lead_service || leadData.projectType,
      lead_timestamp: new Date().toISOString(),
      status: 'novo',
    };

    const currentLeads = this.getStoredLeads();
    currentLeads.unshift(fullLead);

    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(LEADS_STORAGE_KEY, JSON.stringify(currentLeads));
      } catch (e) {
        console.warn('Could not save lead to localStorage', e);
      }
    }

    // Track analytics event
    analytics.trackFormSubmitted(fullLead);

    return fullLead;
  }

  public clearLeads() {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(LEADS_STORAGE_KEY);
    }
  }
}

export const crm = new CRMService();
