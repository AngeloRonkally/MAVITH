import React from 'react';
import { DeviceType } from '../../types/portfolio';
import {
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  User,
  Send,
  Calendar,
  Check,
  Package,
  Layers,
  Sparkles,
  ArrowUpRight,
  ShieldCheck,
  Building2,
  Search,
  ShoppingCart,
  Phone,
  Bot,
} from 'lucide-react';

interface MockupRendererProps {
  device: DeviceType;
  screenType: 'dashboard' | 'crm' | 'chat_ai' | 'b2b_portal' | 'institutional_site' | 'automation_flow';
  title?: string;
  isDemo?: boolean;
  className?: string;
}

export const MockupRenderer: React.FC<MockupRendererProps> = ({
  device,
  screenType,
  title,
  isDemo = true,
  className = '',
}) => {
  // Inner screen UI representations
  const renderScreenContent = () => {
    switch (screenType) {
      case 'dashboard':
        return (
          <div className="h-full bg-slate-900 text-slate-100 p-3 sm:p-4 flex flex-col justify-between font-sans select-none text-[11px] sm:text-xs">
            {/* Top Bar */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#2CBEBF]" />
                <span className="font-bold text-white tracking-wide">Painel Executivo • Saúde & Repasse</span>
              </div>
              <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/50">
                ● Ao vivo
              </span>
            </div>

            {/* Metrics row */}
            <div className="grid grid-cols-3 gap-2 mb-3">
              <div className="bg-slate-800/80 p-2 rounded-lg border border-slate-700/60">
                <span className="text-[10px] text-slate-400 block">Faturamento Bruto</span>
                <span className="text-sm sm:text-base font-extrabold text-white">R$ 184.500</span>
                <span className="text-[9px] text-emerald-400 flex items-center gap-0.5 mt-0.5">
                  <TrendingUp className="w-2.5 h-2.5" /> +14.2% mês
                </span>
              </div>
              <div className="bg-slate-800/80 p-2 rounded-lg border border-slate-700/60">
                <span className="text-[10px] text-slate-400 block">Repasse Médico</span>
                <span className="text-sm sm:text-base font-extrabold text-[#2CBEBF]">R$ 112.400</span>
                <span className="text-[9px] text-slate-400 mt-0.5">18 profissionais</span>
              </div>
              <div className="bg-slate-800/80 p-2 rounded-lg border border-slate-700/60">
                <span className="text-[10px] text-slate-400 block">Margem Líquida</span>
                <span className="text-sm sm:text-base font-extrabold text-[#FE7001]">39.1%</span>
                <span className="text-[9px] text-emerald-400 mt-0.5">Sem glosas ativas</span>
              </div>
            </div>

            {/* Mini Chart and Breakdown */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-800/50 p-2.5 rounded-lg border border-slate-700/40 mb-2">
              <div>
                <span className="text-[10px] font-bold text-slate-300 block mb-1">
                  Distribuição por Especialidade
                </span>
                <div className="space-y-1.5">
                  <div>
                    <div className="flex justify-between text-[9px] text-slate-400 mb-0.5">
                      <span>Cardiologia (Sala 02)</span>
                      <span className="text-white font-mono">R$ 64.200</span>
                    </div>
                    <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                      <div className="h-full bg-[#2CBEBF] w-[75%]" />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-[9px] text-slate-400 mb-0.5">
                      <span>Ortopedia (Sala 04)</span>
                      <span className="text-white font-mono">R$ 51.100</span>
                    </div>
                    <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                      <div className="h-full bg-[#FE7001] w-[58%]" />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-[9px] text-slate-400 mb-0.5">
                      <span>Dermatologia (Sala 01)</span>
                      <span className="text-white font-mono">R$ 38.900</span>
                    </div>
                    <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-400 w-[42%]" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Status table */}
              <div className="border-t sm:border-t-0 sm:border-l border-slate-700/60 pt-2 sm:pt-0 sm:pl-2.5">
                <span className="text-[10px] font-bold text-slate-300 block mb-1">
                  Últimos Repasses Auditados
                </span>
                <div className="space-y-1 text-[9px]">
                  <div className="flex items-center justify-between p-1 bg-slate-900/60 rounded">
                    <span>Dra. Mariana Costa (Cardio)</span>
                    <span className="text-emerald-400 font-bold">R$ 18.240 • OK</span>
                  </div>
                  <div className="flex items-center justify-between p-1 bg-slate-900/60 rounded">
                    <span>Dr. Roberto F. (Ortopedia)</span>
                    <span className="text-emerald-400 font-bold">R$ 14.890 • OK</span>
                  </div>
                  <div className="flex items-center justify-between p-1 bg-slate-900/60 rounded">
                    <span>Dra. Camila L. (Pediatria)</span>
                    <span className="text-emerald-400 font-bold">R$ 11.200 • OK</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Bar */}
            <div className="flex items-center justify-between text-[9px] text-slate-500 pt-1 border-t border-slate-800">
              <span>Sincronizado com Tasy / Prontuário</span>
              <span className="text-slate-400">Tempo de fechamento: 42 minutos</span>
            </div>
          </div>
        );

      case 'b2b_portal':
        return (
          <div className="h-full bg-slate-50 text-slate-800 p-3 sm:p-4 flex flex-col justify-between font-sans select-none text-[11px] sm:text-xs">
            {/* Header */}
            <div className="flex items-center justify-between bg-white p-2 rounded-lg border border-slate-200 shadow-xs mb-2">
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded bg-[#002B58] text-white flex items-center justify-center font-bold text-[10px]">
                  M
                </div>
                <div>
                  <span className="font-bold text-[#002B58] block leading-tight">Distribuidora Atacadista</span>
                  <span className="text-[9px] text-slate-400">Cliente: Padaria Central • CNPJ Ativo</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-[#169495] bg-[#E2F8F8] px-2 py-0.5 rounded">
                  Limite: R$ 45.000
                </span>
                <span className="flex items-center gap-1 text-[10px] font-bold bg-[#002B58] text-white px-2 py-1 rounded">
                  <ShoppingCart className="w-3 h-3" /> 8 itens
                </span>
              </div>
            </div>

            {/* Table Mockup */}
            <div className="bg-white rounded-lg border border-slate-200 overflow-hidden mb-2">
              <div className="bg-slate-100/80 px-2.5 py-1.5 border-b border-slate-200 flex justify-between font-bold text-[10px] text-slate-600">
                <span>Produto / SKU</span>
                <span>Estoque</span>
                <span>Preço B2B</span>
                <span>Qtd.</span>
              </div>
              <div className="divide-y divide-slate-100 text-[10px]">
                <div className="p-2 flex items-center justify-between hover:bg-slate-50">
                  <div>
                    <span className="font-bold text-[#002B58] block">Farinha Especial Tipo 1 (Saco 25kg)</span>
                    <span className="text-[9px] text-slate-400">SKU-8821 • Validade 180 dias</span>
                  </div>
                  <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded text-[9px] font-semibold">
                    1.420 un em depósito
                  </span>
                  <span className="font-mono font-bold text-slate-700">R$ 89,40</span>
                  <div className="flex items-center gap-1 font-mono font-bold bg-slate-100 px-2 py-0.5 rounded">
                    <span>40 cx</span>
                  </div>
                </div>

                <div className="p-2 flex items-center justify-between hover:bg-slate-50">
                  <div>
                    <span className="font-bold text-[#002B58] block">Açúcar Cristal Industrial (Fardo 30kg)</span>
                    <span className="text-[9px] text-slate-400">SKU-4029 • Safra Atual</span>
                  </div>
                  <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded text-[9px] font-semibold">
                    890 un em depósito
                  </span>
                  <span className="font-mono font-bold text-slate-700">R$ 114,00</span>
                  <div className="flex items-center gap-1 font-mono font-bold bg-slate-100 px-2 py-0.5 rounded">
                    <span>25 cx</span>
                  </div>
                </div>

                <div className="p-2 flex items-center justify-between hover:bg-slate-50">
                  <div>
                    <span className="font-bold text-[#002B58] block">Fermento Biológico Seco (Cx 20x500g)</span>
                    <span className="text-[9px] text-slate-400">SKU-1194 • Linha Panificação</span>
                  </div>
                  <span className="text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded text-[9px] font-semibold">
                    120 un restantes
                  </span>
                  <span className="font-mono font-bold text-slate-700">R$ 210,00</span>
                  <div className="flex items-center gap-1 font-mono font-bold bg-slate-100 px-2 py-0.5 rounded">
                    <span>10 cx</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Checkout Action */}
            <div className="bg-white p-2.5 rounded-lg border border-slate-200 flex items-center justify-between shadow-xs">
              <div>
                <span className="text-[10px] text-slate-500 block">Total do Pedido (c/ Impostos e Frete CIF)</span>
                <span className="text-sm font-extrabold text-[#002B58]">R$ 8.526,00</span>
              </div>
              <button
                type="button"
                className="bg-[#FE7001] text-white text-[11px] font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 shadow-xs pointer-events-none"
              >
                <span>Transmitir para Expedição</span>
                <Check className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        );

      case 'chat_ai':
        return (
          <div className="h-full bg-slate-100 text-slate-800 p-3 sm:p-4 flex flex-col justify-between font-sans select-none text-[11px] sm:text-xs">
            {/* WhatsApp / Chat Header */}
            <div className="flex items-center justify-between bg-[#002B58] text-white p-2 rounded-t-lg">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-[#2CBEBF] flex items-center justify-center text-[#002B58] font-bold">
                  <Bot className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold block leading-tight text-[11px]">Agente IA • Silva & Associados</span>
                  <span className="text-[9px] text-emerald-300">● Online para atendimento</span>
                </div>
              </div>
              <span className="text-[9px] bg-white/10 px-2 py-0.5 rounded text-slate-200">
                IA Corporativa
              </span>
            </div>

            {/* Message Feed */}
            <div className="bg-[#EFEAE2] p-2.5 flex-1 space-y-2 overflow-y-auto rounded-b-lg border-x border-b border-slate-300">
              {/* Bot greeting */}
              <div className="max-w-[85%] bg-white p-2 rounded-lg shadow-xs text-[10px] leading-relaxed text-slate-700">
                <p className="font-semibold text-[#002B58] mb-0.5">Assistente Contábil</p>
                Olá, bem-vindo! Sou o assistente inteligente da Silva & Associados. Para agilizar seu diagnóstico, qual é a atividade principal da sua empresa e faixa de faturamento mensal aproximada?
                <span className="text-[8px] text-slate-400 block text-right mt-1">14:02</span>
              </div>

              {/* User Reply */}
              <div className="max-w-[80%] ml-auto bg-[#D9FDD3] p-2 rounded-lg shadow-xs text-[10px] leading-relaxed text-slate-800">
                Somos uma empresa de instalação de energia solar, faturamos cerca de R$ 180 mil/mês e queremos revisar nossos impostos. Segue nosso contrato social em anexo.
                <div className="mt-1.5 p-1.5 bg-white/70 rounded border border-emerald-300/60 flex items-center gap-1.5 text-[9px] font-mono">
                  <FileText className="w-3.5 h-3.5 text-red-500" />
                  <span>Contrato_Social_Solar.pdf (1.2 MB)</span>
                </div>
                <span className="text-[8px] text-slate-500 block text-right mt-1">14:03</span>
              </div>

              {/* Bot validation */}
              <div className="max-w-[85%] bg-white p-2 rounded-lg shadow-xs text-[10px] leading-relaxed text-slate-700">
                <p className="font-semibold text-[#002B58] mb-0.5">Assistente Contábil</p>
                <div className="flex items-center gap-1 text-emerald-700 font-bold text-[9px] mb-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  <span>Documento analisado: CNPJ ativo no Simples Nacional / Anexo IV.</span>
                </div>
                Você é elegível para o nosso plano de redução lícita de impostos. Nosso sócio especialista Dr. Fernando tem disponibilidade amanhã às 10h ou 15h. Deseja confirmar?
                <div className="mt-1.5 flex gap-1">
                  <span className="bg-[#2CBEBF]/20 text-[#002B58] font-bold px-2 py-0.5 rounded text-[9px]">
                    [1] Confirmar 10h
                  </span>
                  <span className="bg-[#2CBEBF]/20 text-[#002B58] font-bold px-2 py-0.5 rounded text-[9px]">
                    [2] Confirmar 15h
                  </span>
                </div>
                <span className="text-[8px] text-slate-400 block text-right mt-1">14:04</span>
              </div>
            </div>

            {/* Input bar */}
            <div className="mt-1 flex items-center gap-1 bg-white p-1.5 rounded-lg border border-slate-200">
              <input
                type="text"
                placeholder="Digite sua resposta..."
                className="w-full bg-transparent text-[10px] outline-hidden px-1 text-slate-600"
                readOnly
                value="Opção 1, confirmado às 10h!"
              />
              <div className="w-6 h-6 rounded-full bg-[#FE7001] text-white flex items-center justify-center shrink-0">
                <Send className="w-3 h-3" />
              </div>
            </div>
          </div>
        );

      case 'automation_flow':
        return (
          <div className="h-full bg-slate-900 text-slate-100 p-3 sm:p-4 flex flex-col justify-between font-sans select-none text-[11px] sm:text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#FE7001]" />
                Esteira de Automação • Régua & Pix
              </span>
              <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/70 border border-emerald-800 px-1.5 py-0.5 rounded">
                Ativo (284 execuções hoje)
              </span>
            </div>

            {/* Diagram Flow nodes */}
            <div className="space-y-2 py-1">
              {/* Step 1 */}
              <div className="flex items-center gap-2 bg-slate-800/90 p-2 rounded-lg border-l-4 border-[#2CBEBF]">
                <div className="w-6 h-6 rounded bg-[#2CBEBF]/20 text-[#2CBEBF] flex items-center justify-center font-bold text-[10px]">
                  01
                </div>
                <div className="flex-1">
                  <span className="font-bold text-white text-[10px] block">Gatilho: Vencimento D-3</span>
                  <span className="text-[9px] text-slate-400">Identifica fatura em aberto e gera Pix copia-e-cola único</span>
                </div>
                <span className="text-[9px] text-emerald-400 font-mono">100% OK</span>
              </div>

              {/* Arrow */}
              <div className="w-0.5 h-2 bg-slate-700 mx-auto" />

              {/* Step 2 */}
              <div className="flex items-center gap-2 bg-slate-800/90 p-2 rounded-lg border-l-4 border-[#FE7001]">
                <div className="w-6 h-6 rounded bg-[#FE7001]/20 text-[#FE7001] flex items-center justify-center font-bold text-[10px]">
                  02
                </div>
                <div className="flex-1">
                  <span className="font-bold text-white text-[10px] block">Disparo Cordial via WhatsApp</span>
                  <span className="text-[9px] text-slate-400">Lembrete amigável com botão de copiar chave e PDF</span>
                </div>
                <span className="text-[9px] text-emerald-400 font-mono">Entregue</span>
              </div>

              {/* Arrow */}
              <div className="w-0.5 h-2 bg-slate-700 mx-auto" />

              {/* Step 3 */}
              <div className="flex items-center gap-2 bg-slate-800/90 p-2 rounded-lg border-l-4 border-emerald-500">
                <div className="w-6 h-6 rounded bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px]">
                  03
                </div>
                <div className="flex-1">
                  <span className="font-bold text-white text-[10px] block">Webhook Bancário & Baixa</span>
                  <span className="text-[9px] text-slate-400">Dinheiro entra na conta → baixa contábil e recibo em 3 segundos</span>
                </div>
                <span className="text-[9px] text-emerald-400 font-mono">Instantâneo</span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[9px] text-slate-400">
              <span>Taxa de retenção espontânea: 92%</span>
              <span className="text-[#2CBEBF]">Zero intervenção humana</span>
            </div>
          </div>
        );

      case 'institutional_site':
        return (
          <div className="h-full bg-white text-slate-800 p-3 sm:p-4 flex flex-col justify-between font-sans select-none text-[11px] sm:text-xs">
            {/* Site Header */}
            <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-2">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-[#002B58]" />
                <span className="font-extrabold text-[#002B58] tracking-tight">ALFA ENGENHARIA</span>
              </div>
              <div className="flex items-center gap-3 text-[9px] font-bold text-slate-600">
                <span className="text-[#FE7001]">Início</span>
                <span>Obras</span>
                <span>Acervo Técnico</span>
                <span>Contato</span>
              </div>
            </div>

            {/* Site Hero Banner */}
            <div className="bg-gradient-to-r from-[#002B58] to-[#001C3B] p-3 rounded-lg text-white mb-2">
              <span className="text-[8px] font-bold uppercase tracking-widest text-[#2CBEBF] block mb-1">
                Soluções Construtivas B2B
              </span>
              <h4 className="text-xs sm:text-sm font-extrabold leading-tight mb-1">
                Construção Pesada e Obras Industriais com Precisão Técnica
              </h4>
              <p className="text-[9px] text-slate-300 mb-2">
                Mais de 140.000m² executados sob rígido padrão de conformidade e pontualidade.
              </p>
              <div className="flex items-center gap-2">
                <span className="bg-[#FE7001] text-white font-bold text-[9px] px-2 py-1 rounded">
                  Solicitar Cotação
                </span>
                <span className="text-[9px] text-slate-300">ISO 9001 / PBQP-H</span>
              </div>
            </div>

            {/* Featured Projects Grid */}
            <div className="grid grid-cols-3 gap-1.5">
              <div className="p-1.5 bg-slate-50 border border-slate-200 rounded text-center">
                <span className="text-[9px] font-bold text-[#002B58] block">Galpão Logístico</span>
                <span className="text-[8px] text-slate-400">18.000m² • SP</span>
              </div>
              <div className="p-1.5 bg-slate-50 border border-slate-200 rounded text-center">
                <span className="text-[9px] font-bold text-[#002B58] block">Planta Farmacêutica</span>
                <span className="text-[8px] text-slate-400">Sala Limpa • RJ</span>
              </div>
              <div className="p-1.5 bg-slate-50 border border-slate-200 rounded text-center">
                <span className="text-[9px] font-bold text-[#002B58] block">Centro Comercial</span>
                <span className="text-[8px] text-slate-400">Estrutura Mista</span>
              </div>
            </div>
          </div>
        );

      case 'crm':
        return (
          <div className="h-full bg-slate-50 text-slate-800 p-3 sm:p-4 flex flex-col justify-between font-sans select-none text-[11px] sm:text-xs">
            {/* Header OS */}
            <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-2">
              <div>
                <span className="text-[9px] text-slate-400 uppercase font-mono font-bold block">
                  Ordem de Serviço #4082
                </span>
                <span className="font-bold text-[#002B58] text-xs">Frigorífico Central • Manutenção Preventiva</span>
              </div>
              <span className="text-[9px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                Em Andamento
              </span>
            </div>

            {/* Checklist */}
            <div className="space-y-1.5 mb-2">
              <div className="flex items-center justify-between p-1.5 bg-white rounded border border-slate-200 text-[10px]">
                <div className="flex items-center gap-1.5">
                  <div className="w-3.5 h-3.5 rounded bg-emerald-500 text-white flex items-center justify-center">
                    <Check className="w-2.5 h-2.5" />
                  </div>
                  <span className="text-slate-700 font-medium">Aferição de pressão e vazamento de gás</span>
                </div>
                <span className="text-[8px] text-slate-400">09:30</span>
              </div>

              <div className="flex items-center justify-between p-1.5 bg-white rounded border border-slate-200 text-[10px]">
                <div className="flex items-center gap-1.5">
                  <div className="w-3.5 h-3.5 rounded bg-emerald-500 text-white flex items-center justify-center">
                    <Check className="w-2.5 h-2.5" />
                  </div>
                  <span className="text-slate-700 font-medium">Troca de filtros e limpeza de evaporadora</span>
                </div>
                <span className="text-[8px] text-slate-400">10:15</span>
              </div>

              <div className="flex items-center justify-between p-1.5 bg-white rounded border border-slate-200 text-[10px]">
                <div className="flex items-center gap-1.5">
                  <div className="w-3.5 h-3.5 rounded bg-amber-400 text-white flex items-center justify-center">
                    <Clock className="w-2.5 h-2.5" />
                  </div>
                  <span className="text-slate-700 font-medium">Foto comprobatória do painel elétrico</span>
                </div>
                <span className="text-[8px] text-amber-700 font-bold bg-amber-50 px-1 rounded">Pendente</span>
              </div>
            </div>

            {/* Digital Signature section */}
            <div className="p-2 bg-white rounded border border-dashed border-slate-300 text-[9px] mb-2">
              <span className="font-bold text-slate-500 block mb-1">Validação do Cliente (Assinatura na Tela):</span>
              <div className="h-7 bg-slate-50 rounded flex items-center justify-center border border-slate-200">
                <span className="font-serif italic text-slate-700 text-xs select-none">
                  Roberto S. Alcantara (Resp. Técnico)
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between text-[9px] text-slate-400 pt-1 border-t border-slate-200">
              <span>Técnico: Lucas V. • Geolocalização validada</span>
              <span className="text-[#002B58] font-bold">Gerar Laudo PDF</span>
            </div>
          </div>
        );
    }
  };

  // Outer device frame layout
  return (
    <div className={`relative ${className}`}>
      {/* Demo watermark tag if demo */}
      {isDemo && (
        <div className="absolute top-3 right-3 z-30 pointer-events-none">
          <span className="text-[10px] font-mono font-bold bg-slate-900/85 text-[#2CBEBF] border border-[#2CBEBF]/40 px-2 py-0.5 rounded-md backdrop-blur-xs shadow-xs">
            PROJETO DEMONSTRATIVO
          </span>
        </div>
      )}

      {/* Frame based on device type */}
      {device === 'desktop' || device === 'notebook' ? (
        <div className="rounded-2xl bg-slate-800 p-2 sm:p-2.5 shadow-2xl border border-slate-700/80">
          {/* Top Browser Bar */}
          <div className="flex items-center justify-between px-2 py-1.5 bg-slate-900 rounded-t-xl mb-1 border-b border-slate-800">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
            </div>

            <div className="bg-slate-800/90 text-slate-400 text-[10px] px-4 py-0.5 rounded-md font-mono flex items-center gap-1.5 max-w-[280px] truncate border border-slate-700/50">
              <span className="text-emerald-400 text-[8px]">🔒</span>
              <span>app.mavith.com.br/plataforma</span>
            </div>

            <span className="text-[10px] text-slate-500 font-mono">1920 × 1080</span>
          </div>

          {/* Screen Content Container */}
          <div className="rounded-b-xl overflow-hidden aspect-[16/10] sm:aspect-[16/9] w-full relative">
            {renderScreenContent()}
          </div>

          {device === 'notebook' && (
            <div className="h-2.5 bg-slate-700 rounded-b-xl mt-1 mx-8 opacity-70" />
          )}
        </div>
      ) : device === 'tablet' ? (
        <div className="rounded-3xl bg-slate-800 p-3 sm:p-4 shadow-2xl border border-slate-700 max-w-xl mx-auto">
          {/* Tablet Camera dot */}
          <div className="w-2 h-2 rounded-full bg-slate-700 mx-auto mb-2" />

          {/* Screen Container */}
          <div className="rounded-2xl overflow-hidden aspect-[4/3] w-full relative bg-slate-900 border border-slate-800">
            {renderScreenContent()}
          </div>

          {/* Bottom Bar indicator */}
          <div className="w-20 h-1 bg-slate-600 rounded-full mx-auto mt-2" />
        </div>
      ) : (
        /* Mobile Device Frame */
        <div className="rounded-[36px] bg-slate-800 p-3 shadow-2xl border-4 border-slate-700 max-w-[320px] mx-auto">
          {/* Dynamic Island / Speaker */}
          <div className="w-24 h-4 bg-slate-950 rounded-full mx-auto mb-2 flex items-center justify-center gap-1">
            <span className="w-2 h-2 rounded-full bg-slate-800" />
            <span className="w-1.5 h-1.5 rounded-full bg-blue-950" />
          </div>

          {/* Screen Container */}
          <div className="rounded-[24px] overflow-hidden aspect-[9/16] w-full relative bg-slate-950">
            {renderScreenContent()}
          </div>

          {/* Home indicator */}
          <div className="w-24 h-1 bg-slate-600 rounded-full mx-auto mt-2" />
        </div>
      )}
    </div>
  );
};
