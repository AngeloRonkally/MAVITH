import React from 'react';
import { PortfolioProject } from '../../types/portfolio';
import { Card } from '../../design-system/components/Card';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import { MockupRenderer } from './MockupRenderer';
import {
  ArrowRight,
  Sparkles,
  Layers,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';

interface PortfolioCardProps {
  project: PortfolioProject;
  onSelectProject: (slug: string) => void;
}

export const PortfolioCard: React.FC<PortfolioCardProps> = ({
  project,
  onSelectProject,
}) => {
  const getCategoryBadgeVariant = (cat: PortfolioProject['category']) => {
    switch (cat) {
      case 'IA':
        return 'orange' as const;
      case 'Sistemas':
        return 'turquoise' as const;
      case 'Dashboards':
        return 'blue' as const;
      case 'Automação':
        return 'orange' as const;
      case 'Sites':
        return 'neutral' as const;
      default:
        return 'blue' as const;
    }
  };

  return (
    <Card
      variant="outline"
      padding="none"
      className="bg-white hover:border-[#2CBEBF]/60 transition-all duration-300 flex flex-col justify-between overflow-hidden group shadow-xs hover:shadow-lg"
    >
      {/* Visual Mockup Header Area */}
      <div className="relative bg-slate-900 p-4 sm:p-6 overflow-hidden border-b border-slate-200">
        {/* Subtle background glow */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-[#2CBEBF]/15 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#FE7001]/10 rounded-full blur-2xl pointer-events-none" />

        {/* Top Badges */}
        <div className="relative z-10 flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <Badge variant={getCategoryBadgeVariant(project.category)} size="sm">
              {project.category}
            </Badge>
            {project.featured && (
              <span className="text-[10px] font-bold text-amber-300 bg-amber-950/80 border border-amber-600/40 px-2 py-0.5 rounded flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5" /> Destaque
              </span>
            )}
          </div>

          {project.isDemo && (
            <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">
              Projeto demonstrativo
            </span>
          )}
        </div>

        {/* Embedded UI Preview */}
        <div className="relative z-10 group-hover:scale-[1.01] transition-transform duration-300">
          <MockupRenderer
            device={project.mockupData.device}
            screenType={project.mockupData.screenType}
            isDemo={false} // Already indicated in badge
            className="max-h-[220px] overflow-hidden"
          />
        </div>
      </div>

      {/* Content Area */}
      <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            {project.segment}
          </span>

          <h3
            className="text-lg sm:text-xl font-bold text-[#002B58] group-hover:text-[#2CBEBF] transition-colors leading-snug"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            {project.title}
          </h3>

          <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed line-clamp-3">
            {project.description}
          </p>

          {/* Micro pipeline pills (Problema -> Solução -> Resultado) */}
          <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-[11px]">
            <div className="bg-amber-50/70 p-2 rounded-lg border border-amber-200/50">
              <span className="font-bold text-amber-900 block text-[9px] uppercase">Gargalo Inicial</span>
              <p className="text-slate-700 line-clamp-2 text-[11px]">
                {project.problem}
              </p>
            </div>
            <div className="bg-emerald-50/70 p-2 rounded-lg border border-emerald-200/50">
              <span className="font-bold text-emerald-900 block text-[9px] uppercase">Resultado</span>
              <p className="text-slate-800 font-medium line-clamp-2 text-[11px]">
                {project.results[0]?.detail || 'Processos otimizados'}
              </p>
            </div>
          </div>

          {/* Tech tags preview */}
          <div className="mt-4 flex flex-wrap gap-1.5">
            {project.technologies.slice(0, 4).map((tech) => (
              <span
                key={tech}
                className="text-[10px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded"
              >
                {tech}
              </span>
            ))}
            {project.technologies.length > 4 && (
              <span className="text-[10px] font-mono text-slate-400 py-0.5">
                +{project.technologies.length - 4}
              </span>
            )}
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
          <span className="text-[11px] font-semibold text-[#002B58]">
            Estudo de caso completo
          </span>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => onSelectProject(project.slug)}
            rightIcon={<ArrowRight className="w-4 h-4 text-[#FE7001]" />}
          >
            Ver projeto
          </Button>
        </div>
      </div>
    </Card>
  );
};
