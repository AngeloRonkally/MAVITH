import React, { useState } from 'react';
import { PortfolioProject, DeviceType } from '../../types/portfolio';
import { Container } from '../../design-system/components/Container';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import { Card } from '../../design-system/components/Card';
import { MockupRenderer } from './MockupRenderer';
import {
  ArrowLeft,
  ArrowRight,
  AlertTriangle,
  Search,
  Compass,
  Code2,
  TrendingUp,
  CheckCircle2,
  Calendar,
  Layers,
  Sparkles,
  ShieldCheck,
  Send,
  HelpCircle,
  ExternalLink,
  Laptop,
  Smartphone,
  Tablet as TabletIcon,
  Monitor,
} from 'lucide-react';

interface ProjectDetailPageProps {
  project: PortfolioProject;
  onBackToPortfolio: () => void;
  onSelectAnotherProject: (slug: string) => void;
  onOpenContactModal: (interest?: string) => void;
}

export const ProjectDetailPage: React.FC<ProjectDetailPageProps> = ({
  project,
  onBackToPortfolio,
  onSelectAnotherProject,
  onOpenContactModal,
}) => {
  const [selectedGalleryDevice, setSelectedGalleryDevice] = useState<DeviceType>(
    project.primaryDevice
  );

  return (
    <div className="bg-white min-h-screen py-8">
      {/* 1. Breadcrumb & Back navigation */}
      <div className="border-b border-slate-200 pb-4 mb-8 bg-slate-50/70">
        <Container size="xl">
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={onBackToPortfolio}
              className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#002B58] hover:text-[#FE7001] transition-colors cursor-pointer py-1"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar ao Portfólio</span>
            </button>

            <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
              <span>/portfolio</span>
              <span>/</span>
              <span className="text-[#002B58] font-bold truncate max-w-[200px]">
                {project.slug}
              </span>
            </div>
          </div>
        </Container>
      </div>

      {/* 2. Hero Section */}
      <Container size="xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center pb-12 border-b border-slate-200">
          {/* Left Hero Content */}
          <div className="lg:col-span-6 space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="blue" size="md">
                {project.category}
              </Badge>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {project.segment}
              </span>
              {project.isDemo && (
                <span className="text-xs font-mono font-bold text-[#169495] bg-[#E2F8F8] border border-[#2CBEBF]/30 px-2.5 py-0.5 rounded-full">
                  Projeto demonstrativo
                </span>
              )}
            </div>

            <h1
              className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#002B58] tracking-tight leading-tight"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              {project.title}
            </h1>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed font-medium">
              {project.subtitle}
            </p>

            <div className="pt-2 flex flex-wrap gap-3">
              <Button
                variant="primary-orange"
                size="md"
                onClick={() => onOpenContactModal(project.title)}
                rightIcon={<Send className="w-4 h-4" />}
              >
                Quero uma solução parecida
              </Button>
              <Button
                variant="secondary"
                size="md"
                onClick={() => {
                  const el = document.getElementById('case-metodologia');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Ver análise e método
              </Button>
            </div>
          </div>

          {/* Right Hero: High-fidelity Device Mockup */}
          <div className="lg:col-span-6">
            <div className="relative">
              <div className="absolute -inset-2 bg-gradient-to-r from-[#2CBEBF]/20 to-[#FE7001]/20 rounded-3xl blur-xl opacity-70 pointer-events-none" />
              <MockupRenderer
                device={project.primaryDevice}
                screenType={project.mockupData.screenType}
                title={project.title}
                isDemo={project.isDemo}
              />
              <p className="mt-3 text-center text-xs text-slate-500 italic">
                {project.mockupData.caption}
              </p>
            </div>
          </div>
        </div>

        {/* 3. Context & Quick Specs */}
        <div className="py-10 grid grid-cols-1 md:grid-cols-4 gap-6 border-b border-slate-200">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-[11px] font-mono font-bold text-slate-400 uppercase block mb-1">
              Segmento
            </span>
            <span className="text-sm font-bold text-[#002B58]">
              {project.segment}
            </span>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-[11px] font-mono font-bold text-slate-400 uppercase block mb-1">
              Categoria
            </span>
            <span className="text-sm font-bold text-[#002B58]">
              {project.category}
            </span>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-[11px] font-mono font-bold text-slate-400 uppercase block mb-1">
              Foco da Intervenção
            </span>
            <span className="text-sm font-bold text-[#002B58]">
              {project.objective}
            </span>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-[11px] font-mono font-bold text-slate-400 uppercase block mb-1">
              Status de Validação
            </span>
            <span className="text-sm font-bold text-emerald-700 flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              Fluxo Validado
            </span>
          </div>
        </div>

        {/* 4. A Esteira do Case: 
            PROBLEMA -> ANÁLISE -> ESTRATÉGIA -> SOLUÇÃO -> RESULTADO 
        */}
        <section id="case-metodologia" className="py-14 border-b border-slate-200">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <Badge variant="orange" size="sm" className="mb-2">
              Estrutura do Case
            </Badge>
            <h2
              className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Do diagnóstico ao impacto real
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-600">
              Não começamos escrevendo código. Começamos investigando a causa raiz do problema operacional.
            </p>
          </div>

          <div className="space-y-8 max-w-4xl mx-auto">
            {/* 1. PROBLEMA */}
            <div className="p-6 sm:p-8 rounded-2xl bg-amber-50/50 border-l-4 border-amber-500 border border-slate-200/60 shadow-xs">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500 text-white flex items-center justify-center">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-amber-700">
                    Etapa 01 • Problema
                  </span>
                  <h3 className="text-lg font-bold text-amber-950">
                    O que estava acontecendo?
                  </h3>
                </div>
              </div>
              <p className="text-sm sm:text-base text-slate-700 leading-relaxed pl-0 sm:pl-11">
                {project.problem}
              </p>
            </div>

            {/* 2. ANÁLISE */}
            <div className="p-6 sm:p-8 rounded-2xl bg-[#EBF6FC]/60 border-l-4 border-[#002B58] border border-slate-200/60 shadow-xs">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-lg bg-[#002B58] text-white flex items-center justify-center">
                  <Search className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-[#002B58]">
                    Etapa 02 • Análise
                  </span>
                  <h3 className="text-lg font-bold text-[#002B58]">
                    O que precisava mudar?
                  </h3>
                </div>
              </div>
              <p className="text-sm sm:text-base text-slate-700 leading-relaxed pl-0 sm:pl-11">
                {project.analysis}
              </p>
            </div>

            {/* 3. ESTRATÉGIA */}
            <div className="p-6 sm:p-8 rounded-2xl bg-[#E2F8F8]/60 border-l-4 border-[#2CBEBF] border border-slate-200/60 shadow-xs">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-lg bg-[#2CBEBF] text-[#002B58] flex items-center justify-center">
                  <Compass className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-[#169495]">
                    Etapa 03 • Estratégia
                  </span>
                  <h3 className="text-lg font-bold text-[#002B58]">
                    Qual caminho foi definido?
                  </h3>
                </div>
              </div>
              <p className="text-sm sm:text-base text-slate-700 leading-relaxed pl-0 sm:pl-11">
                {project.strategy}
              </p>
            </div>

            {/* 4. SOLUÇÃO */}
            <div className="p-6 sm:p-8 rounded-2xl bg-[#FFF2E7]/60 border-l-4 border-[#FE7001] border border-slate-200/60 shadow-xs">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-lg bg-[#FE7001] text-white flex items-center justify-center">
                  <Code2 className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-[#FE7001]">
                    Etapa 04 • Solução
                  </span>
                  <h3 className="text-lg font-bold text-slate-900">
                    O que foi construído?
                  </h3>
                </div>
              </div>
              <p className="text-sm sm:text-base text-slate-700 leading-relaxed pl-0 sm:pl-11">
                {project.solution}
              </p>
            </div>

            {/* 5. RESULTADO */}
            <div className="p-6 sm:p-8 rounded-2xl bg-emerald-50/80 border-l-4 border-emerald-500 border border-emerald-200 shadow-xs">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-emerald-800">
                    Etapa 05 • Resultado
                  </span>
                  <h3 className="text-lg font-bold text-emerald-950">
                    O que mudou na operação?
                  </h3>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4 pl-0 sm:pl-11">
                {project.results.map((res) => (
                  <div
                    key={res.metric}
                    className="p-4 bg-white rounded-xl border border-emerald-200/80 shadow-xs"
                  >
                    <span className="text-xl font-extrabold text-[#002B58] block mb-1">
                      {res.metric}
                    </span>
                    <span className="text-xs font-bold text-emerald-800 block mb-1">
                      {res.label}
                    </span>
                    <span className="text-[11px] text-slate-600 leading-relaxed block">
                      {res.detail}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* 5. Funcionalidades Entregues */}
        <section className="py-14 border-b border-slate-200">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <h2
              className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Funcionalidades em Destaque
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-600">
              Recursos planejados sob medida para o perfil do usuário final da operação.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {project.features.map((feat, index) => (
              <Card
                key={feat.title}
                variant="outline"
                padding="md"
                className="bg-white hover:border-[#2CBEBF]/40 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#EBF6FC] text-[#002B58] flex items-center justify-center shrink-0 font-bold font-mono text-xs">
                    0{index + 1}
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-[#002B58]">
                      {feat.title}
                    </h4>
                    <p className="mt-1 text-xs sm:text-sm text-slate-600 leading-relaxed">
                      {feat.description}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* 6. Tecnologias Empregadas */}
        <section className="py-12 border-b border-slate-200">
          <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6 p-6 rounded-2xl bg-slate-50 border border-slate-200">
            <div>
              <span className="text-[11px] font-mono font-bold text-slate-400 uppercase block mb-1">
                Stack & Arquitetura
              </span>
              <h3 className="text-base font-bold text-[#002B58]">
                Tecnologias Utilizadas na Construção
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Construído com base estável, segura e compatível com expansões futuras.
              </p>
            </div>

            <div className="flex flex-wrap gap-2 justify-end">
              {project.technologies.map((tech) => (
                <span
                  key={tech}
                  className="text-xs font-mono font-semibold text-[#002B58] bg-white border border-slate-300 px-3 py-1.5 rounded-lg shadow-2xs"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </section>

        {/* 7. Galeria de Telas & Dispositivos */}
        <section className="py-14 border-b border-slate-200">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <h2
              className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Apresentação Visual & Interfaces
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-600">
              Alternância entre formatos para demonstrar a flexibilidade responsiva do projeto.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            {/* Device Switcher */}
            <div className="flex justify-center gap-2 mb-8">
              <button
                type="button"
                onClick={() => setSelectedGalleryDevice('desktop')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedGalleryDevice === 'desktop'
                    ? 'bg-[#002B58] text-white shadow-md'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <Monitor className="w-4 h-4" />
                <span>Desktop (1920p)</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedGalleryDevice('tablet')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedGalleryDevice === 'tablet'
                    ? 'bg-[#002B58] text-white shadow-md'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <TabletIcon className="w-4 h-4" />
                <span>Tablet</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedGalleryDevice('mobile')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedGalleryDevice === 'mobile'
                    ? 'bg-[#002B58] text-white shadow-md'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <Smartphone className="w-4 h-4" />
                <span>Mobile</span>
              </button>
            </div>

            {/* Render selected device */}
            <div className="bg-slate-100/60 p-6 sm:p-8 rounded-3xl border border-slate-200 flex justify-center">
              <MockupRenderer
                device={selectedGalleryDevice}
                screenType={project.mockupData.screenType}
                title={project.title}
                isDemo={project.isDemo}
                className="w-full max-w-3xl"
              />
            </div>
          </div>
        </section>

        {/* 8. CTA Final de Conversão do Case */}
        <section className="py-16">
          <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-[#002B58] via-[#002447] to-[#001C3B] text-white text-center max-w-3xl mx-auto shadow-xl relative overflow-hidden">
            {/* Accent glow */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#2CBEBF]/15 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#FE7001]/15 rounded-full blur-2xl pointer-events-none" />

            <div className="relative z-10">
              <Badge variant="orange" size="md" className="mb-4">
                Próximo Passo
              </Badge>

              <h3
                className="text-2xl sm:text-3xl font-extrabold text-white leading-tight"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
              >
                Tem um problema parecido no seu negócio?
              </h3>

              <p className="mt-4 text-sm sm:text-base text-slate-200 max-w-xl mx-auto leading-relaxed">
                Podemos analisar seus processos atuais, mapear as dores operacionais e propor a rota técnica ideal para sua empresa.
              </p>

              <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
                <Button
                  variant="primary-orange"
                  size="md"
                  onClick={() => onOpenContactModal(project.title)}
                  rightIcon={<Send className="w-4 h-4" />}
                  className="shadow-lg font-bold"
                >
                  Fale com a MAVITH
                </Button>

                <Button
                  variant="secondary"
                  size="md"
                  onClick={onBackToPortfolio}
                >
                  Explorar outros projetos
                </Button>
              </div>
            </div>
          </div>
        </section>
      </Container>
    </div>
  );
};
