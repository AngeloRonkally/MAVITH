import React, { useState, useMemo } from 'react';
import { PortfolioCategory, PortfolioProject } from '../../types/portfolio';
import { PORTFOLIO_PROJECTS } from '../../data/portfolioData';
import { Container } from '../../design-system/components/Container';
import { SectionTitle } from '../../design-system/components/Section';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import { PortfolioCard } from './PortfolioCard';
import {
  Compass,
  Search,
  SlidersHorizontal,
  Layers,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Info,
} from 'lucide-react';

interface PortfolioPageProps {
  onSelectProject: (slug: string) => void;
  onOpenContactModal: (interest?: string) => void;
}

export const PortfolioPage: React.FC<PortfolioPageProps> = ({
  onSelectProject,
  onOpenContactModal,
}) => {
  const [activeCategory, setActiveCategory] = useState<PortfolioCategory>('Todos');
  const [searchQuery, setSearchQuery] = useState('');

  const categories: PortfolioCategory[] = [
    'Todos',
    'Sites',
    'Sistemas',
    'IA',
    'Automação',
    'Dashboards',
  ];

  // Data-driven filtering
  const filteredProjects = useMemo(() => {
    return PORTFOLIO_PROJECTS.filter((proj) => {
      const matchCategory =
        activeCategory === 'Todos' || proj.category === activeCategory;
      const matchSearch =
        proj.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        proj.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        proj.segment.toLowerCase().includes(searchQuery.toLowerCase()) ||
        proj.problem.toLowerCase().includes(searchQuery.toLowerCase()) ||
        proj.technologies.some((t) =>
          t.toLowerCase().includes(searchQuery.toLowerCase())
        );
      return matchCategory && matchSearch;
    });
  }, [activeCategory, searchQuery]);

  return (
    <div className="bg-slate-50/50 min-h-screen py-12">
      {/* Portfolio Header & Strategic Narrative */}
      <Container size="xl">
        <SectionTitle
          badge="Portfólio & Casos de Transformação"
          title="Não apenas programamos."
          highlightText="Resolvemos problemas reais."
          description="Cada projeto da MAVITH nasce de um gargalo operacional concreto. Não construímos código por vaidade técnica, mas para transformar a rotina, a produtividade e a saúde financeira das empresas."
          align="center"
        />

        {/* Concept Flow Banner: ENTENDER -> ANALISAR -> PROJETAR -> CONSTRUIR -> TRANSFORMAR */}
        <div className="mt-10 mb-12 p-6 rounded-2xl bg-white border border-slate-200 shadow-xs max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#002B58] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#FE7001]" />
              O Método por Trás de Cada Entrega
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              Esteira de Engenharia de Valor
            </span>
          </div>

          <div className="grid grid-cols-5 gap-2 sm:gap-4 text-center">
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <span className="text-[10px] font-mono text-[#FE7001] font-bold block">01</span>
              <span className="text-xs sm:text-sm font-extrabold text-[#002B58] block">ENTENDER</span>
              <span className="text-[10px] text-slate-400 hidden sm:block">A dor da operação</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <span className="text-[10px] font-mono text-[#2CBEBF] font-bold block">02</span>
              <span className="text-xs sm:text-sm font-extrabold text-[#002B58] block">ANALISAR</span>
              <span className="text-[10px] text-slate-400 hidden sm:block">A causa raiz</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <span className="text-[10px] font-mono text-[#002B58] font-bold block">03</span>
              <span className="text-xs sm:text-sm font-extrabold text-[#002B58] block">PROJETAR</span>
              <span className="text-[10px] text-slate-400 hidden sm:block">A rota ideal</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <span className="text-[10px] font-mono text-[#2CBEBF] font-bold block">04</span>
              <span className="text-xs sm:text-sm font-extrabold text-[#002B58] block">CONSTRUIR</span>
              <span className="text-[10px] text-slate-400 hidden sm:block">Software sólido</span>
            </div>

            <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
              <span className="text-[10px] font-mono text-emerald-700 font-bold block">05</span>
              <span className="text-xs sm:text-sm font-extrabold text-emerald-900 block">TRANSFORMAR</span>
              <span className="text-[10px] text-emerald-700 hidden sm:block">Resultado prático</span>
            </div>
          </div>
        </div>

        {/* Honest Disclosure Banner (Rule 6: Prova & Transparência) */}
        <div className="mb-10 max-w-4xl mx-auto p-4 rounded-xl bg-blue-50/60 border border-blue-200/70 text-xs text-[#002B58] flex items-start gap-3">
          <Info className="w-4 h-4 text-[#2CBEBF] shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong>Transparência MAVITH:</strong> Não inventamos depoimentos nem nomes fictícios de clientes. Os cases a seguir foram modelados como <strong>projetos demonstrativos (DEMO)</strong> para ilustrar com precisão a arquitetura de solução, interfaces e o fluxo técnico que empregamos em negócios reais.
          </div>
        </div>

        {/* Filter Bar & Search */}
        <div className="mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
            {categories.map((cat) => {
              const count =
                cat === 'Todos'
                  ? PORTFOLIO_PROJECTS.length
                  : PORTFOLIO_PROJECTS.filter((p) => p.category === cat).length;
              const isActive = activeCategory === cat;

              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setActiveCategory(cat)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-[#002B58] text-white shadow-xs'
                      : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  <span>{cat}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-md font-mono ${
                      isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Buscar por dor, setor ou tech..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-white border border-slate-200 focus:outline-hidden focus:border-[#2CBEBF] transition-colors"
            />
          </div>
        </div>

        {/* Projects Grid */}
        {filteredProjects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project) => (
              <PortfolioCard
                key={project.id}
                project={project}
                onSelectProject={onSelectProject}
              />
            ))}
          </div>
        ) : (
          <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 max-w-lg mx-auto">
            <Search className="w-8 h-8 text-slate-300 mx-auto mb-3" />
            <h4 className="text-base font-bold text-[#002B58]">
              Nenhum projeto encontrado
            </h4>
            <p className="text-xs text-slate-500 mt-1 mb-4">
              Não encontramos projetos com os termos pesquisados. Tente limpar os filtros.
            </p>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                setActiveCategory('Todos');
                setSearchQuery('');
              }}
            >
              Restaurar todos os projetos
            </Button>
          </div>
        )}

        {/* Bottom Conversion Section */}
        <div className="mt-20 p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-[#002B58] to-[#001C3B] text-white flex flex-col md:flex-row items-center justify-between gap-8 shadow-xl">
          <div className="max-w-xl">
            <span className="text-xs font-mono font-bold text-[#2CBEBF] uppercase tracking-wider block mb-2">
              Arquitetura Sob Medida
            </span>
            <h3
              className="text-2xl sm:text-3xl font-extrabold leading-tight text-white"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Sua empresa tem um processo que precisa ser transformado?
            </h3>
            <p className="mt-3 text-xs sm:text-sm text-slate-300 leading-relaxed">
              Não existe problema pequeno demais quando ele consome o tempo da sua equipe ou custa a fidelidade dos seus clientes.
            </p>
          </div>

          <div className="shrink-0">
            <Button
              variant="primary-orange"
              size="md"
              onClick={() => onOpenContactModal('diagnostico')}
              rightIcon={<ArrowRight className="w-4 h-4" />}
              className="font-bold shadow-md"
            >
              Fale com a MAVITH
            </Button>
          </div>
        </div>
      </Container>
    </div>
  );
};
