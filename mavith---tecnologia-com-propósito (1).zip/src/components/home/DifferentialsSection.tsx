import React from 'react';
import { Container } from '../../design-system/components/Container';
import { SectionTitle } from '../../design-system/components/Section';
import { Card } from '../../design-system/components/Card';
import {
  Sparkles,
  Cpu,
  Sliders,
  Check,
  ShieldCheck,
  Users,
} from 'lucide-react';

export const DifferentialsSection: React.FC = () => {
  const diffs = [
    {
      title: 'Inovação',
      desc: 'Tecnologia moderna e atualizada, mas com aplicação prática em negócios reais — sem modismos vazios.',
      icon: Sparkles,
      color: 'turquoise',
    },
    {
      title: 'Inteligência',
      desc: 'Análise de dados e inteligência artificial aplicadas para reduzir custos operacionais e acelerar vendas.',
      icon: Cpu,
      color: 'orange',
    },
    {
      title: 'Personalização',
      desc: 'Não empurramos pacotes prontos genéricos. Construímos a solução exata que a sua operação necessita.',
      icon: Sliders,
      color: 'blue',
    },
    {
      title: 'Simplicidade',
      desc: 'Interfaces descomplicadas e linguagem clara. Sua equipe não precisa ser técnica para operar as ferramentas.',
      icon: Check,
      color: 'turquoise',
    },
    {
      title: 'Confiabilidade',
      desc: 'Sistemas estáveis, arquitetura segura na nuvem e proteção de dados para você dormir tranquilo.',
      icon: ShieldCheck,
      color: 'blue',
    },
    {
      title: 'Proximidade',
      desc: 'Atendimento consultivo direto com quem constrói e entende a sua dor, sem robôs de suporte ou filas infinitas.',
      icon: Users,
      color: 'orange',
    },
  ];

  return (
    <section className="py-20 bg-slate-50 border-b border-slate-200">
      <Container size="xl">
        <SectionTitle
          badge="Pilares de Valor"
          title="Por que escolher a"
          highlightText="MAVITH?"
          description="Acreditamos que pequenas e médias empresas merecem o mesmo nível de excelência tecnológica que as gigantes do mercado, com atendimento próximo e foco em retorno."
          align="center"
        />

        <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {diffs.map((d) => {
            const Icon = d.icon;
            return (
              <Card
                key={d.title}
                variant="elevated"
                padding="lg"
                className="bg-white flex flex-col justify-between hover:shadow-md transition-all duration-200"
              >
                <div>
                  <div
                    className={`w-11 h-11 rounded-xl flex items-center justify-center mb-4 ${
                      d.color === 'orange'
                        ? 'bg-[#FFF2E7] text-[#FE7001]'
                        : d.color === 'turquoise'
                        ? 'bg-[#E2F8F8] text-[#169495]'
                        : 'bg-[#EBF6FC] text-[#002B58]'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>

                  <h3
                    className="text-base font-bold text-[#002B58]"
                    style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                  >
                    {d.title}
                  </h3>

                  <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed">
                    {d.desc}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Pilar MAVITH</span>
                  <span className="font-semibold text-[#002B58]">Garantido</span>
                </div>
              </Card>
            );
          })}
        </div>
      </Container>
    </section>
  );
};
