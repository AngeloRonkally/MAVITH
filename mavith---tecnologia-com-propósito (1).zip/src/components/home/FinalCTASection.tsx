import React from 'react';
import { Container } from '../../design-system/components/Container';
import { Button } from '../../design-system/components/Button';
import { Badge } from '../../design-system/components/Badge';
import { ArrowRight, Send, CheckCircle2 } from 'lucide-react';

interface FinalCTASectionProps {
  onContactClick: () => void;
}

export const FinalCTASection: React.FC<FinalCTASectionProps> = ({ onContactClick }) => {
  return (
    <section className="py-24 bg-gradient-to-b from-[#002B58] via-[#002447] to-[#001C3B] text-white relative overflow-hidden">
      {/* Background circuit watermark */}
      <div className="absolute inset-0 bg-circuit-dark opacity-35 pointer-events-none" />

      {/* Radiant glow highlights */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#2CBEBF]/12 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-80 h-80 bg-[#FE7001]/10 rounded-full blur-3xl pointer-events-none" />

      <Container size="xl" className="relative z-10">
        <div className="max-w-3xl mx-auto text-center flex flex-col items-center">
          {/* Badge */}
          <Badge variant="orange" size="md" className="mb-6 shadow-md">
            Próximo Passo
          </Badge>

          {/* Main Title */}
          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Seu próximo projeto pode começar aqui<span className="text-[#FE7001]">.</span>
          </h2>

          {/* Text */}
          <p className="mt-6 text-base sm:text-lg text-slate-200 leading-relaxed max-w-2xl">
            Tem uma ideia, um processo que precisa melhorar ou um problema que a tecnologia pode resolver?
          </p>

          <p className="mt-2 text-sm text-[#2CBEBF] font-medium">
            Não presuma conhecimento técnico. Falamos a língua da sua operação diária.
          </p>

          {/* Main Action Button */}
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <Button
              variant="primary-orange"
              size="lg"
              onClick={onContactClick}
              rightIcon={<Send className="w-5 h-5" />}
              className="shadow-xl hover:shadow-2xl text-base px-8 py-4"
            >
              Fale com a MAVITH
            </Button>
          </div>

          {/* Trust Guarantees */}
          <div className="mt-12 pt-8 border-t border-white/15 w-full flex flex-wrap items-center justify-center gap-8 text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#2CBEBF]" />
              <span>Sem jargões complicados</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#2CBEBF]" />
              <span>Diagnóstico inicial sem compromisso</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#2CBEBF]" />
              <span>Resposta em até 24h úteis</span>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};
