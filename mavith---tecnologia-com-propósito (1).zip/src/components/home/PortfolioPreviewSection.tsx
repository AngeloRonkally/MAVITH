import React from 'react';
import { Container } from '../../design-system/components/Container';
import { SectionTitle } from '../../design-system/components/Section';
import { Card } from '../../design-system/components/Card';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import {
  Building2,
  Briefcase,
  Store,
  ArrowRight,
  TrendingUp,
  Clock,
  ShieldCheck,
} from 'lucide-react';

interface PortfolioPreviewSectionProps {
  onContactClick: () => void;
  onViewAllProjects?: () => void;
  onSelectProject?: (slug: string) => void;
}

export const PortfolioPreviewSection: React.FC<PortfolioPreviewSectionProps> = ({
  onContactClick,
  onViewAllProjects,
  onSelectProject,
}) => {
  const projects = [
    {
      id: 'distribuidora',
      slug: 'portal-b2b-distribuicao',
      sector: 'Distribuição & Comércio B2B',
      clientType: 'Média Distribuidora Regional',
      title: 'Eliminação de gargalos na emissão e conferência de pedidos',
      icon: Store,
      accent: 'orange' as const,
      problem:
        'A equipe de vendas recebia mais de 120 pedidos diários por áudio e texto no WhatsApp, digitando um a um em planilhas. Erros de expedição e atrasos de faturamento eram frequentes.',
      solution:
        'Desenvolvimento de uma plataforma web de catálogo digital com autenticação para clientes B2B e automação direta integrando pedidos ao sistema fiscal.',
      result:
        'Redução imediata de 4 horas diárias de digitação manual da equipe e taxa de erro em pedidos reduzida a zero.',
      metrics: [
        { label: 'Tempo manual', val: '-4h/dia' },
        { label: 'Erros de expedição', val: '0%' },
      ],
    },
    {
      id: 'consultoria',
      slug: 'agente-ia-triagem-contabil',
      sector: 'Serviços Corporativos & Consultoria',
      clientType: 'Escritório Contábil & Tributário',
      title: 'Triagem de novos clientes e pré-qualificação automatizada',
      icon: Briefcase,
      accent: 'turquoise' as const,
      problem:
        'Contadores seniores gastavam até 40% da jornada semanal respondendo dúvidas triviais e recolhendo documentos básicos de novos clientes sem saber se tinham perfil ideal.',
      solution:
        'Criação de um Agente de IA treinado nas rotinas fiscais da empresa para recepção de documentos, validação inicial e agendamento automático na agenda do especialista.',
      result:
        'Aumento de 38% no volume de reuniões comerciais qualificadas e liberação dos analistas para trabalhos de alta rentabilidade.',
      metrics: [
        { label: 'Reuniões qualificadas', val: '+38%' },
        { label: 'Horas liberadas', val: '18h/sem' },
      ],
    },
    {
      id: 'saude',
      slug: 'dashboard-bi-financeiro-clinica',
      sector: 'Saúde & Clínicas Especializadas',
      clientType: 'Clínica Multidisciplinar',
      title: 'Visão unificada de faturamento por sala e controle de repasse',
      icon: Building2,
      accent: 'blue' as const,
      problem:
        'O gestor passava os primeiros 10 dias de cada mês calculando em 5 planilhas desconexas o repasse médico, custos de materiais e a margem de cada especialidade.',
      solution:
        'Construção de um Dashboard de Business Intelligence seguro, consolidando prontuários eletrônicos, despesas bancárias e extrato automático de repasse para os profissionais.',
      result:
        'Fechamento mensal realizado em menos de 1 hora com auditoria transparente e visibilidade diária da margem líquida da clínica.',
      metrics: [
        { label: 'Fechamento financeiro', val: 'De 10 dias p/ 1h' },
        { label: 'Visão de margem', val: 'Tempo Real' },
      ],
    },
  ];

  return (
    <section id="portfolio" className="py-20 bg-slate-50 border-b border-slate-200">
      <Container size="xl">
        <SectionTitle
          badge="Casos de Transformação"
          title="Projetos que"
          highlightText="resolvem problemas."
          description="Cada iniciativa da MAVITH nasce de um gargalo específico e é medida pelo impacto tangível na rotina, na produtividade e no lucro da empresa."
          align="center"
        />

        <div className="mt-14 grid grid-cols-1 lg:grid-cols-3 gap-8">
          {projects.map((proj) => {
            const Icon = proj.icon;
            return (
              <Card
                key={proj.id}
                variant="elevated"
                accent={proj.accent}
                padding="lg"
                className="bg-white flex flex-col justify-between hover:shadow-lg transition-all duration-300"
              >
                <div>
                  {/* Header info */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-lg bg-slate-100 text-[#002B58] flex items-center justify-center">
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-[11px] font-bold text-slate-500 uppercase block">
                          {proj.sector}
                        </span>
                        <span className="text-xs text-slate-400">
                          {proj.clientType}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Project Title */}
                  <h3
                    className="text-base font-bold text-[#002B58] leading-snug mb-6"
                    style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                  >
                    {proj.title}
                  </h3>

                  {/* Problema + Solução + Resultado Pipeline */}
                  <div className="space-y-4">
                    {/* 1. Problema */}
                    <div className="p-3 rounded-xl bg-amber-50/60 border border-amber-200/60 text-xs">
                      <span className="font-bold text-amber-900 block mb-1 uppercase tracking-wider text-[10px]">
                        1. O Problema
                      </span>
                      <p className="text-slate-700 leading-relaxed">
                        {proj.problem}
                      </p>
                    </div>

                    {/* 2. Solução */}
                    <div className="p-3 rounded-xl bg-[#EBF6FC] border border-[#2CBEBF]/30 text-xs">
                      <span className="font-bold text-[#002B58] block mb-1 uppercase tracking-wider text-[10px]">
                        2. A Solução MAVITH
                      </span>
                      <p className="text-slate-700 leading-relaxed">
                        {proj.solution}
                      </p>
                    </div>

                    {/* 3. Resultado */}
                    <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs">
                      <span className="font-bold text-emerald-800 block mb-1 uppercase tracking-wider text-[10px]">
                        3. O Resultado Concreto
                      </span>
                      <p className="text-slate-800 font-semibold leading-relaxed">
                        {proj.result}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Metrics Highlight */}
                <div className="mt-6 pt-4 border-t border-slate-100 grid grid-cols-2 gap-3 text-center">
                  {proj.metrics.map((m) => (
                    <div key={m.label} className="p-2 rounded-lg bg-slate-50 border border-slate-200/60">
                      <span className="text-base font-extrabold text-[#002B58] block">
                        {m.val}
                      </span>
                      <span className="text-[10px] text-slate-500 font-medium">
                        {m.label}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Case Link */}
                {onSelectProject && (
                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <Button
                      variant="secondary"
                      size="sm"
                      className="w-full justify-center text-xs"
                      onClick={() => onSelectProject(proj.slug)}
                      rightIcon={<ArrowRight className="w-3.5 h-3.5 text-[#FE7001]" />}
                    >
                      Ver case detalhado
                    </Button>
                  </div>
                )}
              </Card>
            );
          })}
        </div>

        {/* Action callout below projects */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-4">
          <Button
            variant="primary-orange"
            size="md"
            onClick={onContactClick}
            className="font-bold shadow-sm"
          >
            Quero transformar meu negócio
          </Button>

          {onViewAllProjects && (
            <Button
              variant="secondary"
              size="md"
              onClick={onViewAllProjects}
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Explorar Portfólio Completo
            </Button>
          )}
        </div>
      </Container>
    </section>
  );
};
