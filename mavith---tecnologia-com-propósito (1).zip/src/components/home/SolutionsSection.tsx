import React from 'react';
import { Container } from '../../design-system/components/Container';
import { SectionTitle } from '../../design-system/components/Section';
import { Card } from '../../design-system/components/Card';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import { SolutionSlug } from '../../types/solutions';
import {
  Globe,
  Database,
  Cpu,
  LineChart,
  Zap,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Layers,
  Sparkles,
  BarChart3,
} from 'lucide-react';

interface SolutionsSectionProps {
  onSelectSolution: (sol: string) => void;
  onExploreSolutionPage?: (slug: SolutionSlug) => void;
  onGoToSolutionsHub?: () => void;
  onConsultClick?: (solutionName?: string) => void;
}

export const SolutionsSection: React.FC<SolutionsSectionProps> = ({
  onSelectSolution,
  onExploreSolutionPage,
  onGoToSolutionsHub,
  onConsultClick,
}) => {
  const pillars: {
    id: string;
    slug: SolutionSlug;
    pillar: string;
    subtitle: string;
    icon: React.ComponentType<{ className?: string }>;
    color: 'blue' | 'turquoise' | 'orange';
    problem: string;
    solution: string;
    deliverables: string[];
    impact: string;
  }[] = [
    {
      id: 'sites',
      slug: 'sites',
      pillar: 'Sites & Plataformas',
      subtitle: 'Presença Digital com Autoridade e Alta Conversão',
      icon: Globe,
      color: 'blue',
      problem: 'Empresas invisíveis no Google ou com sites desatualizados que não passam credibilidade nem geram oportunidades reais de negócios.',
      solution:
        'Desenvolvemos experiências web sólidas, velozes e responsivas, orientadas a transmitir o valor real da sua empresa e gerar contatos qualificados.',
      deliverables: [
        'Sites institucionais corporativos de alta autoridade',
        'Portais comerciais e páginas de produtos/serviços',
        'Landing pages com funis de conversão validados',
        'Otimização técnica para Google (SEO) e velocidade máxima',
      ],
      impact: 'Mais credibilidade comercial e contatos qualificados diários.',
    },
    {
      id: 'sistemas',
      slug: 'sistemas',
      pillar: 'Sistemas Sob Medida',
      subtitle: 'Substituição de Planilhas e Processos Manuais',
      icon: Layers,
      color: 'turquoise',
      problem: 'Dependência de planilhas complexas com fórmulas quebradas, controle em papéis ou softwares engessados que não atendem sua regra de negócio.',
      solution:
        'Criamos plataformas e painéis web centralizados, construídos exatamente para o fluxo da sua empresa, sem custos abusivos de licenças por usuário.',
      deliverables: [
        'Painéis de gestão operacional e controle de ordens de serviço',
        'Portais do cliente para autoatendimento e solicitações',
        'Controle financeiro, faturamento e fluxo de aprovações',
        'Bancos de dados estruturados e seguros na nuvem',
      ],
      impact: 'Fim do retrabalho e controle total da operação em um único painel.',
    },
    {
      id: 'ia',
      slug: 'ia',
      pillar: 'Inteligência Artificial',
      subtitle: 'Agentes Inteligentes e Análise de Documentos',
      icon: Sparkles,
      color: 'orange',
      problem: 'Equipes sobrecarregadas respondendo dúvidas idênticas, analisando contratos manualmente e gastando horas em pesquisas repetitivas.',
      solution:
        'Treinamos e integramos agentes de IA na base de conhecimento da sua empresa para atender clientes, resumir laudos e apoiar os colaboradores.',
      deliverables: [
        'Agentes de atendimento e triagem 24/7 com tom humanizado',
        'Assistentes internos para pesquisa rápida em manuais e políticas',
        'Extração automática de dados de contratos, notas e PDFs',
        'Integração segura com WhatsApp, CRM e sistemas internos',
      ],
      impact: 'Horas operacionais devolvidas à equipe para focar no crescimento.',
    },
    {
      id: 'automacao',
      slug: 'automacao',
      pillar: 'Automação de Processos',
      subtitle: 'Integrações de Software e Rotinas Automáticas',
      icon: Zap,
      color: 'orange',
      problem: 'Pessoas gastando horas copiando e colando informações de um sistema para o outro, gerando atrasos e erros humanos frequentes.',
      solution:
        'Conectamos as ferramentas que você já utiliza (ERP, CRM, WhatsApp, e-mail) através de fluxos automáticos confiáveis e sem falhas.',
      deliverables: [
        'Sincronização instantânea de pedidos entre CRM e financeiro',
        'Lembretes e avisos automáticos de status para clientes via WhatsApp',
        'Geração e envio automático de faturas e relatórios periódicos',
        'Eliminação de digitação duplicada entre plataformas',
      ],
      impact: 'Processos que rodam sozinhos 24 horas por dia, sem falhas.',
    },
    {
      id: 'dashboards',
      slug: 'dashboards',
      pillar: 'Dashboards & BI',
      subtitle: 'Métricas e Indicadores em Tempo Real para Decisão',
      icon: BarChart3,
      color: 'blue',
      problem: 'Diretoria tomando decisões no escuro ou no "feeling", dependendo de relatórios manuais demorados com números que divergem entre setores.',
      solution:
        'Transformamos bases dispersas em painéis visuais interativos que atualizam sozinhos e mostram claramente onde estão os lucros e os gargalos.',
      deliverables: [
        'Dashboards interativos de vendas, estoque e margem líquida',
        'Cruzamento em tempo real de dados de filiais e canais',
        'Alertas inteligentes de metas e desvios operacionais',
        'Visão executiva simplificada acessível por computador ou celular',
      ],
      impact: 'Decisões ágeis baseadas em dados consolidados e confiáveis.',
    },
  ];

  return (
    <section id="solucoes" className="py-20 bg-white border-b border-slate-200">
      <Container size="xl">
        <SectionTitle
          badge="Conexão Problema → Solução"
          title="Transformamos problemas em"
          highlightText="soluções estratégicas."
          description="A tecnologia não é um fim isolado. Cada uma de nossas frentes de atuação existe para solucionar uma dor concreta do dia a dia do seu negócio."
          align="center"
        />

        {/* 5 Pillars Grid with Problem & Solution Dual Hierarchy */}
        <div className="mt-14 space-y-8">
          {pillars.map((item, index) => {
            const Icon = item.icon;
            return (
              <Card
                key={item.id}
                variant="outline"
                padding="lg"
                className="bg-white hover:border-[#2CBEBF]/60 transition-all duration-300 shadow-xs hover:shadow-md"
              >
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  {/* Column 1: Pillar Identity & Icon */}
                  <div className="lg:col-span-4 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <div
                          className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                            item.color === 'orange'
                              ? 'bg-[#FFF2E7] text-[#FE7001]'
                              : item.color === 'turquoise'
                              ? 'bg-[#E2F8F8] text-[#169495]'
                              : 'bg-[#EBF6FC] text-[#002B58]'
                          }`}
                        >
                          <Icon className="w-6 h-6" />
                        </div>
                        <div>
                          <span className="text-[11px] font-mono text-slate-400 uppercase font-bold tracking-wider">
                            Pilar 0{index + 1}
                          </span>
                          <h3
                            className="text-xl font-bold text-[#002B58]"
                            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                          >
                            {item.pillar}
                          </h3>
                        </div>
                      </div>

                      <p className="text-xs font-semibold text-slate-500 mb-4">
                        {item.subtitle}
                      </p>

                      <div className="p-3 rounded-lg bg-emerald-50/70 border border-emerald-200/60 text-xs text-emerald-800 font-medium flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span><strong>Resultado esperado:</strong> {item.impact}</span>
                      </div>
                    </div>

                    <div className="mt-6 flex flex-col sm:flex-row gap-2">
                      {onExploreSolutionPage && (
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => onExploreSolutionPage(item.slug)}
                          rightIcon={<ArrowRight className="w-4 h-4 text-[#FE7001]" />}
                        >
                          Conhecer Solução Completa
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onSelectSolution(item.pillar)}
                      >
                        Avaliar para minha empresa
                      </Button>
                    </div>
                  </div>

                  {/* Column 2: The Specific Problem vs MAVITH Solution */}
                  <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6 p-6 rounded-2xl bg-slate-50 border border-slate-200/80">
                    {/* The Problem */}
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-[#FE7001] text-xs font-bold uppercase tracking-wider">
                        <AlertCircle className="w-4 h-4" />
                        <span>O Problema Típico</span>
                      </div>
                      <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">
                        {item.problem}
                      </p>
                    </div>

                    {/* The MAVITH Solution */}
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-[#169495] text-xs font-bold uppercase tracking-wider">
                        <CheckCircle2 className="w-4 h-4 text-[#2CBEBF]" />
                        <span>A Resposta da MAVITH</span>
                      </div>
                      <p className="text-xs sm:text-sm text-[#002B58] leading-relaxed font-semibold">
                        {item.solution}
                      </p>
                    </div>

                    {/* What is Delivered */}
                    <div className="md:col-span-2 pt-4 border-t border-slate-200">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2.5">
                        O que entregamos na prática:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {item.deliverables.map((del) => (
                          <div key={del} className="flex items-center gap-2 text-xs text-slate-600">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#2CBEBF]" />
                            <span>{del}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Explore Hub Banner */}
        <div className="mt-12 p-6 sm:p-8 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-6 text-center sm:text-left">
          <div>
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#2CBEBF]">
              Orientação personalizada
            </span>
            <h4 className="text-base sm:text-lg font-bold text-[#002B58] mt-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              Precisa de ajuda para definir a solução ideal para o seu momento?
            </h4>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-xl">
              Nossos especialistas técnicos avaliam sua estrutura e apontam o caminho de menor risco e maior retorno.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center sm:justify-end gap-3 shrink-0 w-full sm:w-auto">
            {onConsultClick && (
              <Button
                variant="primary-orange"
                size="md"
                onClick={() => onConsultClick('Geral')}
                className="w-full sm:w-auto font-bold shadow-sm"
              >
                Fale com a MAVITH
              </Button>
            )}
            {onGoToSolutionsHub && (
              <Button
                variant="secondary"
                size="md"
                onClick={onGoToSolutionsHub}
                rightIcon={<ArrowRight className="w-4 h-4" />}
                className="w-full sm:w-auto"
              >
                Acessar Hub de Soluções
              </Button>
            )}
          </div>
        </div>
      </Container>
    </section>
  );
};
