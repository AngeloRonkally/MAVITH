import React from 'react';
import { Container } from '../../design-system/components/Container';
import { SectionTitle } from '../../design-system/components/Section';
import { Card } from '../../design-system/components/Card';
import { MavithLogo } from '../../design-system/components/MavithLogo';
import { Target, HeartHandshake, Lightbulb, Compass } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="sobre" className="py-20 bg-white border-b border-slate-200">
      <Container size="xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Brand Statement */}
          <div className="lg:col-span-6">
            <SectionTitle
              badge="Nossa Filosofia"
              title="Mais do que"
              highlightText="tecnologia."
              description="A MAVITH nasceu de uma constatação simples: a maioria das soluções de software no mercado ou é cara demais, ou é genérica demais para a realidade das pequenas empresas."
              align="left"
            />

            <div className="mt-6 space-y-4 text-sm sm:text-base text-slate-600 leading-relaxed">
              <p>
                Não acreditamos em tecnologia que serve apenas para impressionar em apresentações.
                Acreditamos na tecnologia que resolve a planilha que trava toda sexta-feira, na
                automação que impede o cliente de ficar sem resposta e no painel que mostra onde está o lucro real.
              </p>
              <p className="font-semibold text-[#002B58]">
                Nosso propósito é democratizar soluções digitais inteligentes com rigor técnico,
                linguagem clara e compromisso direto com os resultados do seu negócio.
              </p>
            </div>

            {/* Micro value badges */}
            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                <Target className="w-5 h-5 text-[#FE7001]" />
                <span className="text-xs font-bold text-[#002B58]">Foco em Resultado</span>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                <HeartHandshake className="w-5 h-5 text-[#2CBEBF]" />
                <span className="text-xs font-bold text-[#002B58]">Parceria Próxima</span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Brand Plaque */}
          <div className="lg:col-span-6 flex justify-center">
            <Card
              variant="dark"
              padding="lg"
              className="w-full max-w-md bg-gradient-to-br from-[#002B58] via-[#002447] to-[#001C3B] text-white border border-[#2CBEBF]/30 shadow-xl relative overflow-hidden"
            >
              {/* Circuit watermark */}
              <div className="absolute inset-0 bg-circuit-dark opacity-35 pointer-events-none" />

              <div className="relative z-10 flex flex-col items-center text-center p-4">
                <MavithLogo variant="full" theme="dark" size="lg" />

                <div className="mt-8 pt-6 border-t border-white/10 w-full space-y-3 text-left">
                  <div className="flex items-start gap-3">
                    <Lightbulb className="w-4 h-4 text-[#FE7001] shrink-0 mt-1" />
                    <div>
                      <span className="text-xs font-bold text-white block">Inovação Aplicada</span>
                      <span className="text-[11px] text-slate-300">Cada linha de código com uma razão de negócio.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Compass className="w-4 h-4 text-[#2CBEBF] shrink-0 mt-1" />
                    <div>
                      <span className="text-xs font-bold text-white block">Visão de Longo Prazo</span>
                      <span className="text-[11px] text-slate-300">Construímos bases sólidas que acompanham sua expansão.</span>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-white/10 w-full flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>MAVITH • Tecnologia com propósito</span>
                  <span className="text-[#2CBEBF]">Desde o dia 1</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </Container>
    </section>
  );
};
