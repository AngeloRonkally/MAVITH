import React from 'react';
import { Container } from '../../design-system/components/Container';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import { Card } from '../../design-system/components/Card';
import { Clock, ArrowRight, BookOpen, Sparkles, MonitorPlay } from 'lucide-react';
import { INSIGHT_ARTICLES } from '../../data/insightsData';

interface InsightsPreviewSectionProps {
  onViewAllInsights: () => void;
  onSelectArticle: (slug: string) => void;
  onOpenDemos: () => void;
}

export const InsightsPreviewSection: React.FC<InsightsPreviewSectionProps> = ({
  onViewAllInsights,
  onSelectArticle,
  onOpenDemos,
}) => {
  const topArticles = INSIGHT_ARTICLES.slice(0, 3);

  return (
    <section className="py-20 bg-slate-50 border-t border-slate-200" id="insights">
      <Container size="xl">
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <Badge variant="teal" size="md" className="mb-3">
              Conhecimento & Autoridade
            </Badge>

            <h2
              className="text-3xl sm:text-4xl font-extrabold text-[#002B58] tracking-tight leading-tight"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Tecnologia explicada para quem toma decisões.
            </h2>

            <p className="mt-3 text-sm sm:text-base text-slate-600 leading-relaxed">
              Artigos estratégicos sobre automação de processos, migração de planilhas frágeis, IA aplicada e construção de sistemas sob medida.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <Button
              variant="secondary"
              size="sm"
              onClick={onOpenDemos}
              leftIcon={<MonitorPlay className="w-4 h-4 text-[#FE7001]" />}
            >
              Testar Demonstrações
            </Button>

            <Button
              variant="primary-teal"
              size="sm"
              onClick={onViewAllInsights}
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Ver Todos os Artigos
            </Button>
          </div>
        </div>

        {/* 3 Featured Article Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {topArticles.map((article) => (
            <Card
              key={article.slug}
              variant="outline"
              padding="lg"
              className="bg-white hover:border-[#2CBEBF] transition-all duration-300 shadow-xs hover:shadow-md flex flex-col justify-between group cursor-pointer"
              onClick={() => onSelectArticle(article.slug)}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#2CBEBF] font-mono">
                    {article.category}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{article.readTime}</span>
                  </div>
                </div>

                <h3
                  className="text-lg font-bold text-[#002B58] mb-2.5 group-hover:text-[#2CBEBF] transition-colors leading-snug"
                  style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                >
                  {article.title}
                </h3>

                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6 line-clamp-3">
                  {article.subtitle}
                </p>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-[#002B58] group-hover:text-[#2CBEBF] transition-colors">
                <span className="text-slate-400 font-normal font-mono">
                  {article.date}
                </span>
                <span className="flex items-center gap-1">
                  Ler artigo
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </span>
              </div>
            </Card>
          ))}
        </div>
      </Container>
    </section>
  );
};
