import React from 'react';
import { Container } from '../../design-system/components/Container';
import { Button } from '../../design-system/components/Button';
import { Badge } from '../../design-system/components/Badge';
import { ArrowRight, Sparkles, TrendingUp, Cpu, Network, CheckCircle2 } from 'lucide-react';

interface HomeHeroProps {
  onPrimaryCta: () => void;
  onSecondaryCta: () => void;
}

export const HomeHero: React.FC<HomeHeroProps> = ({ onPrimaryCta, onSecondaryCta }) => {
  return (
    <section className="relative bg-gradient-to-b from-white via-slate-50/70 to-slate-100/50 pt-12 pb-16 md:pt-20 md:pb-28 overflow-hidden border-b border-slate-200/80">
      {/* Subtle brand circuit pattern background */}
      <div className="absolute inset-0 bg-circuit-subtle opacity-35 pointer-events-none" />

      {/* Decorative ambient lighting - warm orange and cool turquoise highlights */}
      <div className="absolute -top-24 right-0 w-96 h-96 bg-[#2CBEBF]/12 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 -left-20 w-80 h-80 bg-[#FE7001]/8 rounded-full blur-3xl pointer-events-none" />

      <Container size="xl" className="relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Narrative Headline & CTAs */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            {/* Context Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-[#2CBEBF]/40 text-xs font-bold text-[#002B58] shadow-xs mb-6">
              <span className="w-2 h-2 rounded-full bg-[#FE7001]" />
              <span className="uppercase tracking-wider">Tecnologia com propósito para empresas reais</span>
            </div>

            {/* Main Headline */}
            <h1
              className="text-4xl sm:text-5xl lg:text-[3.25rem] font-extrabold tracking-tight text-[#002B58] leading-[1.12]"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Seu negócio evoluiu.<br />
              <span className="text-slate-800">A tecnologia também precisa evoluir.</span>
            </h1>

            {/* Subheadline */}
            <p className="mt-6 text-lg sm:text-xl font-medium text-slate-700 leading-relaxed max-w-2xl">
              Transformamos processos, ideias e desafios em soluções digitais inteligentes.
            </p>

            {/* Complemento */}
            <p className="mt-3 text-sm sm:text-base text-slate-600 leading-relaxed max-w-xl">
              Sites, sistemas, automações, agentes de IA e inteligência analítica para empresas que querem crescer.
            </p>

            {/* CTAs */}
            <div className="mt-8 flex flex-wrap items-center gap-4 w-full sm:w-auto">
              <Button
                variant="primary-orange"
                size="lg"
                onClick={onPrimaryCta}
                rightIcon={<ArrowRight className="w-5 h-5" />}
                className="w-full sm:w-auto shadow-md hover:shadow-lg"
              >
                Quero transformar meu negócio
              </Button>

              <Button
                variant="secondary"
                size="lg"
                onClick={onSecondaryCta}
                className="w-full sm:w-auto"
              >
                Conhecer nossas soluções
              </Button>
            </div>

            {/* Trust & Foundation Bar */}
            <div className="mt-10 pt-6 border-t border-slate-200/80 flex flex-wrap items-center gap-6 text-xs text-slate-500 font-medium">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#2CBEBF]" />
                <span>Problema real no centro</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#2CBEBF]" />
                <span>Soluções personalizadas</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#2CBEBF]" />
                <span>Foco em pequenos e médios negócios</span>
              </div>
            </div>
          </div>

          {/* Right Column: Custom Visual Composition (No stock photos) */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            <div className="relative w-full max-w-md">
              {/* Main Structural Visual Container */}
              <div className="relative rounded-2xl bg-gradient-to-br from-[#002B58] via-[#002447] to-[#001C3B] p-6 sm:p-7 text-white shadow-xl border border-[#2CBEBF]/30 overflow-hidden">
                {/* Internal circuit watermark */}
                <div className="absolute inset-0 bg-circuit-dark opacity-35 pointer-events-none" />

                {/* Top Bar: Connected Node Status */}
                <div className="relative z-10 flex items-center justify-between border-b border-white/10 pb-4 mb-6">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#2CBEBF] animate-pulse" />
                    <span className="text-xs font-mono font-bold tracking-wider text-slate-200 uppercase">
                      MAVITH • FLUXO CONECTADO
                    </span>
                  </div>
                  <Badge variant="orange" size="sm">
                    Evolução Ativa
                  </Badge>
                </div>

                {/* Central Connected Nodes Diagram (Inspirado na logo MAVITH) */}
                <div className="relative z-10 space-y-4">
                  {/* Node 1: Do Problema à Estrutura */}
                  <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between hover:bg-white/10 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-[#FE7001]/20 border border-[#FE7001]/40 flex items-center justify-center text-[#FE7001]">
                        <TrendingUp className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-white block">Processo & Desafio</span>
                        <span className="text-[11px] text-slate-300">Gargalos operacionais mapeados</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#FE7001]" />
                      <span className="text-[11px] font-mono text-[#FE7001]">Fase 01</span>
                    </div>
                  </div>

                  {/* Connecting circuit line */}
                  <div className="flex justify-center -my-2">
                    <div className="h-4 w-0.5 bg-gradient-to-b from-[#FE7001] via-[#2CBEBF] to-[#2CBEBF]" />
                  </div>

                  {/* Node 2: Conexão e Inteligência */}
                  <div className="p-3.5 rounded-xl bg-[#002447] border border-[#2CBEBF]/40 flex items-center justify-between shadow-inner">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-[#2CBEBF]/20 border border-[#2CBEBF]/40 flex items-center justify-center text-[#2CBEBF]">
                        <Cpu className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-white block">Automação & IA</span>
                        <span className="text-[11px] text-[#2CBEBF]">Sistemas e agentes conectados</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#2CBEBF]" />
                      <span className="text-[11px] font-mono text-[#2CBEBF]">Fase 02</span>
                    </div>
                  </div>

                  {/* Connecting circuit line */}
                  <div className="flex justify-center -my-2">
                    <div className="h-4 w-0.5 bg-gradient-to-b from-[#2CBEBF] to-[#002B58]" />
                  </div>

                  {/* Node 3: Resultado Mensurável */}
                  <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between hover:bg-white/10 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                        <Network className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-white block">Decisão & Lucro</span>
                        <span className="text-[11px] text-slate-300">Painéis de controle e tempo recuperado</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      <span className="text-[11px] font-mono text-emerald-300">Fase 03</span>
                    </div>
                  </div>
                </div>

                {/* Bottom Graphic Ribbon (Faceted like MAVITH logo) */}
                <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-xs">
                  <span className="text-slate-400">Tecnologia como MEIO.</span>
                  <span className="text-[#2CBEBF] font-semibold flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    Resultado como FIM.
                  </span>
                </div>
              </div>

              {/* Floating micro card 1: Indicador de Eficiência */}
              <div className="absolute -bottom-4 -left-4 bg-white text-slate-800 p-3 rounded-xl border border-slate-200/80 shadow-lg flex items-center gap-3 select-none">
                <div className="w-3 h-3 rounded-full bg-[#2CBEBF]" />
                <div className="text-left">
                  <span className="text-[11px] text-slate-500 block">Tempo operacional</span>
                  <span className="text-xs font-bold text-[#002B58]">Processos automáticos</span>
                </div>
              </div>

              {/* Floating micro card 2: Decisão Embasada */}
              <div className="absolute -top-4 -right-4 bg-white text-slate-800 p-3 rounded-xl border border-slate-200/80 shadow-lg flex items-center gap-2.5 select-none hidden sm:flex">
                <div className="w-3 h-3 rounded-full bg-[#FE7001]" />
                <div className="text-left">
                  <span className="text-[11px] text-slate-500 block">Visão de dados</span>
                  <span className="text-xs font-bold text-[#002B58]">Decisão sem feeling</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};
