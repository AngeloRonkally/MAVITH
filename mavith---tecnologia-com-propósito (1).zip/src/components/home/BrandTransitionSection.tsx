import React from 'react';
import { Container } from '../../design-system/components/Container';
import { MavithLogo } from '../../design-system/components/MavithLogo';
import { Sparkles, ArrowDown } from 'lucide-react';

export const BrandTransitionSection: React.FC = () => {
  return (
    <section className="relative py-24 bg-gradient-to-b from-[#001C3B] via-[#002447] to-[#002B58] text-white overflow-hidden">
      {/* Circuit overlay */}
      <div className="absolute inset-0 bg-circuit-dark opacity-30 pointer-events-none" />

      {/* Radiant glow around the MAVITH mark */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-[#2CBEBF]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[280px] h-[280px] bg-[#FE7001]/10 rounded-full blur-2xl pointer-events-none" />

      <Container size="xl" className="relative z-10">
        <div className="max-w-3xl mx-auto text-center flex flex-col items-center">
          {/* Transition Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 border border-white/15 text-xs font-semibold text-[#2CBEBF] backdrop-blur-xs mb-8">
            <Sparkles className="w-3.5 h-3.5 text-[#FE7001]" />
            <span className="uppercase tracking-wider">A ponte entre o desafio e a solução</span>
          </div>

          {/* Core Transition Statement */}
          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-[1.2] text-white"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            A tecnologia evoluiu.<br />
            <span className="text-slate-300">Seu negócio pode evoluir junto.</span>
          </h2>

          {/* Visual Bridge Element: MAVITH Symbol in Center */}
          <div className="my-10 relative flex flex-col items-center">
            {/* Top connecting trace */}
            <div className="h-10 w-0.5 bg-gradient-to-b from-transparent via-[#2CBEBF] to-[#FE7001]" />

            {/* Glowing Logo Plaque */}
            <div className="p-6 rounded-2xl bg-[#001C3B]/90 border border-[#2CBEBF]/40 shadow-2xl backdrop-blur-md flex flex-col items-center">
              <MavithLogo variant="full" theme="dark" size="lg" />
            </div>

            {/* Bottom connecting trace */}
            <div className="h-10 w-0.5 bg-gradient-to-b from-[#FE7001] via-[#2CBEBF] to-transparent" />
          </div>

          {/* Punchline Statement */}
          <div className="space-y-2">
            <span className="text-xs sm:text-sm font-mono tracking-widest text-[#2CBEBF] uppercase block">
              Ponto de Virada
            </span>
            <p
              className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#FE7001] tracking-tight"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              É aqui que a MAVITH entra.
            </p>
          </div>

          <p className="mt-6 text-base text-slate-300 max-w-xl leading-relaxed">
            Não trazemos ferramentas vazias ou linguagens complicadas. Trazemos método,
            estratégia e desenvolvimento direto ao ponto para resolver os gargalos reais da sua rotina.
          </p>

          <div className="mt-8 animate-bounce text-slate-400">
            <ArrowDown className="w-5 h-5 text-[#2CBEBF]" />
          </div>
        </div>
      </Container>
    </section>
  );
};
