import React from 'react';
import { Container } from '../../design-system/components/Container';
import { SectionTitle } from '../../design-system/components/Section';
import { Card } from '../../design-system/components/Card';
import {
  Compass,
  Target,
  Palette,
  Code2,
  CheckCircle,
  TrendingUp,
} from 'lucide-react';

export const ProcessSection: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'Descoberta',
      icon: Compass,
      desc: 'Imersão no seu negócio. Ouvimos os gestores e a operação para mapear dores, gargalos reais e oportunidades imediatas.',
      accent: 'orange',
    },
    {
      num: '02',
      title: 'Estratégia',
      icon: Target,
      desc: 'Desenho da rota técnica e priorização. Definimos o que gera maior retorno de investimento (ROI) com a menor fricção de implantação.',
      accent: 'turquoise',
    },
    {
      num: '03',
      title: 'Design',
      icon: Palette,
      desc: 'Prototipagem focada na usabilidade humana. Interfaces limpas, intuitivas e corporativas para que qualquer colaborador aprenda sem esforço.',
      accent: 'blue',
    },
    {
      num: '04',
      title: 'Desenvolvimento',
      icon: Code2,
      desc: 'Construção com tecnologias sólidas, modernas e seguras. Código limpo, integrações estáveis e arquitetura preparada para crescer.',
      accent: 'blue',
    },
    {
      num: '05',
      title: 'Validação',
      icon: CheckCircle,
      desc: 'Testes práticos com quem realmente usa a ferramenta no dia a dia. Ajustes finos de fluxo e homologação de segurança.',
      accent: 'turquoise',
    },
    {
      num: '06',
      title: 'Evolução',
      icon: TrendingUp,
      desc: 'Tecnologia não é estática. Acompanhamos os dados de uso, realizamos melhorias contínuas e mantemos o sistema alinhado ao crescimento.',
      accent: 'orange',
    },
  ];

  return (
    <section id="processo" className="py-20 bg-white border-b border-slate-200">
      <Container size="xl">
        <SectionTitle
          badge="Metodologia MAVITH"
          title="Da necessidade"
          highlightText="à solução definitiva."
          description="Um método transparente em seis etapas para garantir que você não receba apenas software, mas uma transformação real na rotina da sua empresa."
          align="center"
        />

        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <Card
                key={step.num}
                variant="outline"
                padding="lg"
                className="bg-white hover:border-[#002B58]/40 transition-all duration-200 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-black font-mono text-slate-300">
                      {step.num}
                    </span>
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        step.accent === 'orange'
                          ? 'bg-[#FFF2E7] text-[#FE7001]'
                          : step.accent === 'turquoise'
                          ? 'bg-[#E2F8F8] text-[#169495]'
                          : 'bg-[#EBF6FC] text-[#002B58]'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>

                  <h3
                    className="text-lg font-bold text-[#002B58]"
                    style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                  >
                    {step.title}
                  </h3>

                  <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed">
                    {step.desc}
                  </p>
                </div>

                <div className="mt-6 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>Passo {step.num} de 06</span>
                  <span className="text-[#002B58] font-bold">Consistência</span>
                </div>
              </Card>
            );
          })}
        </div>
      </Container>
    </section>
  );
};
