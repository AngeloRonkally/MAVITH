import React from 'react';
import { Container } from '../../design-system/components/Container';
import { SectionTitle } from '../../design-system/components/Section';
import { Card } from '../../design-system/components/Card';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import {
  Clock,
  FileSpreadsheet,
  Share2,
  Repeat,
  Unplug,
  BarChart3,
  HelpCircle,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

interface ProblemsSectionProps {
  onCtaClick?: () => void;
}

export const ProblemsSection: React.FC<ProblemsSectionProps> = ({ onCtaClick }) => {
  const problems = [
    {
      id: 'processos-manuais',
      title: 'Processos manuais',
      question: 'Quanto tempo sua equipe perde fazendo algo que poderia ser automático?',
      detail:
        'Ordens em papel, preenchimentos manuais de pedidos e tarefas operacionais que consomem a energia que deveria estar nas vendas.',
      icon: Clock,
      tag: 'Operação lenta',
      accent: 'orange' as const,
    },
    {
      id: 'planilhas',
      title: 'Planilhas que travam a gestão',
      question: 'Sua empresa ainda é refém de arquivos salvos localmente e fórmulas que quebram?',
      detail:
        'Múltiplas versões da mesma planilha circulando por e-mail, gerando dados conflitantes e decisões baseadas em números desatualizados.',
      icon: FileSpreadsheet,
      tag: 'Risco de erro',
      accent: 'blue' as const,
    },
    {
      id: 'informacoes-espalhadas',
      title: 'Informações espalhadas',
      question: 'Onde está o histórico daquele cliente que comprou no mês passado?',
      detail:
        'Conversas no WhatsApp de funcionários, notas de bloco, e-mails soltos. Ninguém sabe exatamente qual é o status real de cada negociação.',
      icon: Share2,
      tag: 'Comunicação frouxa',
      accent: 'turquoise' as const,
    },
    {
      id: 'tarefas-repetitivas',
      title: 'Tarefas repetitivas',
      question: 'Seus profissionais qualificados passam o dia copiando e colando informações?',
      detail:
        'Emitir notas, reenviar comprovantes, atualizar status em dois lugares diferentes. O talento humano é desperdiçado em rotinas mecânicas.',
      icon: Repeat,
      tag: 'Custo oculto',
      accent: 'orange' as const,
    },
    {
      id: 'sistemas-desconectados',
      title: 'Sistemas desconectados',
      question: 'Seu sistema de vendas conversa com o financeiro e com o estoque?',
      detail:
        'Ter várias ferramentas isoladas que não se comunicam cria retrabalho duplo e pontos cegos críticos para o faturamento.',
      icon: Unplug,
      tag: 'Falta de integração',
      accent: 'blue' as const,
    },
    {
      id: 'falta-de-indicadores',
      title: 'Falta de indicadores',
      question: 'Você tem dados. Mas consegue enxergar o que eles dizem agora?',
      detail:
        'Não saber com precisão o custo real de aquisição, o ticket médio por canal ou a lucratividade líquida no fechamento do dia.',
      icon: BarChart3,
      tag: 'Decisão no feeling',
      accent: 'turquoise' as const,
    },
  ];

  return (
    <section id="problemas" className="py-20 bg-slate-50 border-b border-slate-200">
      <Container size="xl">
        <SectionTitle
          badge="Diagnóstico Real"
          title="Talvez sua empresa esteja"
          highlightText="pronta para uma mudança."
          description="A maioria das empresas não sofre por falta de esforço, mas por processos arcaicos que drenam energia, tempo e receita. Reconhece algum destes cenários na sua rotina?"
          align="center"
        />

        {/* Dynamic Question Bar */}
        <div className="mt-8 mb-12 p-4 rounded-xl bg-white border border-[#2CBEBF]/30 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4 max-w-3xl mx-auto text-center sm:text-left">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#E2F8F8] text-[#169495] flex items-center justify-center shrink-0">
              <HelpCircle className="w-5 h-5 text-[#2CBEBF]" />
            </div>
            <p className="text-xs sm:text-sm font-bold text-[#002B58]">
              &ldquo;Seu negócio cresceu. Seus processos acompanharam esse crescimento?&rdquo;
            </p>
          </div>
          <span className="text-[11px] font-mono text-[#FE7001] uppercase font-bold tracking-wider shrink-0">
            Autoavaliação
          </span>
        </div>

        {/* Problems Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {problems.map((prob) => {
            const Icon = prob.icon;
            return (
              <Card
                key={prob.id}
                variant="elevated"
                accent={prob.accent}
                padding="lg"
                className="flex flex-col justify-between hover:shadow-md transition-all duration-200 bg-white"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 text-[#002B58] flex items-center justify-center">
                      <Icon className="w-5 h-5" />
                    </div>
                    <Badge variant={prob.accent === 'orange' ? 'orange' : prob.accent === 'turquoise' ? 'turquoise' : 'blue'} size="sm">
                      {prob.tag}
                    </Badge>
                  </div>

                  <h3
                    className="text-lg font-bold text-[#002B58]"
                    style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                  >
                    {prob.title}
                  </h3>

                  <p className="mt-3 text-sm font-semibold text-slate-800 leading-snug italic">
                    &ldquo;{prob.question}&rdquo;
                  </p>

                  <p className="mt-2 text-xs text-slate-500 leading-relaxed">
                    {prob.detail}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>Gargalo de negócio</span>
                  <span className="text-[#FE7001] font-bold">Solucionável</span>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Strategic CTA below problems */}
        {onCtaClick && (
          <div className="mt-12 p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#002B58] to-[#001D3D] text-white border border-[#002B58] flex flex-col sm:flex-row items-center justify-between gap-6 shadow-sm">
            <div className="space-y-1.5 text-center sm:text-left">
              <span className="text-xs font-mono uppercase tracking-wider text-[#2CBEBF] font-bold">
                Identificou algum desses gargalos na sua operação?
              </span>
              <h4 className="text-lg sm:text-xl font-bold text-white" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                Sua empresa não precisa continuar convivendo com processos manuais.
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
                Uma conversa objetiva de 30 minutos pode mapear exatamente quanto tempo e dinheiro sua equipe está perdendo.
              </p>
            </div>

            <Button
              variant="primary-orange"
              size="lg"
              onClick={onCtaClick}
              className="shrink-0 w-full sm:w-auto font-bold shadow-md"
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Quero transformar meu negócio
            </Button>
          </div>
        )}
      </Container>
    </section>
  );
};
