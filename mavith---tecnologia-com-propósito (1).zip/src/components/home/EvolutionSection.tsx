import React from 'react';
import { Container } from '../../design-system/components/Container';
import { SectionTitle } from '../../design-system/components/Section';
import {
  BookOpen,
  FileSpreadsheet,
  Layers,
  Zap,
  Cpu,
  ArrowRight,
} from 'lucide-react';

export const EvolutionSection: React.FC = () => {
  const steps = [
    {
      icon: BookOpen,
      era: 'Passado',
      label: 'CADERNO',
      desc: 'Anotações manuais, controle em blocos de papel e risco constante de perda.',
      color: 'slate',
      badgeClass: 'bg-slate-100 text-slate-700 border-slate-200',
    },
    {
      icon: FileSpreadsheet,
      era: 'Transição',
      label: 'PLANILHA',
      desc: 'Primeira digitalização: tabelas locais, fórmulas que quebram e retrabalho.',
      color: 'blue',
      badgeClass: 'bg-blue-50 text-blue-700 border-blue-200',
    },
    {
      icon: Layers,
      era: 'Consolidação',
      label: 'SISTEMA',
      desc: 'Bancos de dados e softwares de gestão, mas muitas vezes desconectados.',
      color: 'navy',
      badgeClass: 'bg-[#EBF6FC] text-[#002B58] border-slate-300',
    },
    {
      icon: Zap,
      era: 'Eficiência',
      label: 'AUTOMAÇÃO',
      desc: 'Gatilhos integrando vendas, cobrança, estoque e comunicação sem esforço manual.',
      color: 'turquoise',
      badgeClass: 'bg-[#E2F8F8] text-[#169495] border-[#2CBEBF]/40',
    },
    {
      icon: Cpu,
      era: 'Estratégia',
      label: 'INTELIGÊNCIA ARTIFICIAL',
      desc: 'Agentes inteligentes que analisam dados, atendem clientes e antecipam decisões.',
      color: 'orange',
      badgeClass: 'bg-[#FFF2E7] text-[#FE7001] border-[#FE7001]/40',
    },
  ];

  return (
    <section className="py-20 bg-white border-b border-slate-200">
      <Container size="xl">
        <SectionTitle
          badge="Linha de Evolução"
          title="O jeito de fazer negócios"
          highlightText="mudou."
          description="Durante anos, empresas evoluíram seus processos utilizando as ferramentas disponíveis. Hoje, tecnologia não precisa apenas acompanhar o negócio. Ela pode fazer parte da estratégia."
          align="center"
        />

        {/* Visual Timeline Stepper */}
        <div className="mt-14 relative">
          {/* Connecting Line (Desktop) */}
          <div className="hidden lg:block absolute top-1/2 left-4 right-4 h-0.5 bg-gradient-to-r from-slate-200 via-[#2CBEBF]/50 to-[#FE7001] -translate-y-8 z-0" />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 relative z-10">
            {steps.map((step, idx) => {
              const Icon = step.icon;
              const isLast = idx === steps.length - 1;
              return (
                <div
                  key={step.label}
                  className={`flex flex-col items-center text-center p-6 rounded-2xl transition-all duration-300 ${
                    isLast
                      ? 'bg-gradient-to-b from-[#FFF2E7]/40 via-white to-white border-2 border-[#FE7001]/60 shadow-md'
                      : 'bg-white border border-slate-200/80 shadow-xs hover:border-slate-300'
                  }`}
                >
                  {/* Step Era Badge */}
                  <span className={`text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border mb-4 ${step.badgeClass}`}>
                    {step.era}
                  </span>

                  {/* Step Icon Node */}
                  <div
                    className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 transition-transform ${
                      isLast
                        ? 'bg-[#FE7001] text-white shadow-md'
                        : idx >= 3
                        ? 'bg-[#2CBEBF]/15 text-[#169495] border border-[#2CBEBF]/40'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>

                  {/* Step Title */}
                  <h3
                    className={`text-sm font-extrabold tracking-wider ${
                      isLast ? 'text-[#FE7001]' : 'text-[#002B58]'
                    }`}
                    style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                  >
                    {step.label}
                  </h3>

                  {/* Step Description */}
                  <p className="mt-2 text-xs text-slate-500 leading-relaxed">
                    {step.desc}
                  </p>

                  {/* Flow Arrow indicator on mobile/tablet */}
                  {!isLast && (
                    <div className="lg:hidden mt-4 text-slate-300">
                      <ArrowRight className="w-4 h-4 rotate-90 sm:rotate-0" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Strategic Quote box */}
        <div className="mt-14 max-w-3xl mx-auto p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center">
          <p className="text-sm sm:text-base font-semibold text-[#002B58] leading-relaxed">
            &ldquo;A tecnologia não é o fim, mas o meio pelo qual a sua empresa ganha fôlego, reduz desperdício e foca no que realmente gera receita.&rdquo;
          </p>
        </div>
      </Container>
    </section>
  );
};
