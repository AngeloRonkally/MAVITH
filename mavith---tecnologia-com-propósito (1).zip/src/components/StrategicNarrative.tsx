import React, { useState } from 'react';
import { Card } from '../design-system/components/Card';
import { Badge } from '../design-system/components/Badge';
import { Button } from '../design-system/components/Button';
import {
  FileSpreadsheet,
  Clock,
  Folders,
  RefreshCw,
  LineChart,
  ArrowRight,
  CheckCircle2,
  Cpu,
  Target,
  TrendingUp,
} from 'lucide-react';

interface PainPoint {
  id: string;
  question: string;
  situation: string;
  impact: string;
  strategy: string;
  techSolution: string;
  techType: 'Sites' | 'Sistemas' | 'Agentes de IA' | 'Dashboards';
  result: string;
  icon: React.ReactNode;
}

const PAIN_POINTS: PainPoint[] = [
  {
    id: 'spreadsheets',
    question: 'Seu negócio ainda depende de planilhas para tudo?',
    situation: 'Planilhas com versões conflitantes, fórmulas quebradas e risco diário de perda de informações financeiras.',
    impact: 'Lentidão operacional e insegurança fiscal na tomada de decisão.',
    strategy: 'Centralizar fluxos críticos em base estruturada com níveis de acesso seguros.',
    techSolution: 'Sistema sob medida em nuvem com sincronização contínua e validações automáticas.',
    techType: 'Sistemas',
    result: 'Redução de 75% no tempo de fechamento e eliminação total de perda de registros.',
    icon: <FileSpreadsheet className="w-5 h-5 text-[#FE7001]" />,
  },
  {
    id: 'repetitive',
    question: 'Você perde horas com tarefas repetitivas e manuais?',
    situation: 'Equipe gastando metade do dia copiando dados de clientes, emitindo ordens ou respondendo dúvidas frequentes.',
    impact: 'Custo de folha elevado para tarefas mecânicas e desmotivação dos colaboradores.',
    strategy: 'Mapear gatilhos de rotina e introduzir automação inteligente sem fricção.',
    techSolution: 'Agentes de IA e fluxos de integração automática conectados a canais de atendimento.',
    techType: 'Agentes de IA',
    result: 'Economia de mais de 20 horas semanais por colaborador direcionadas para vendas.',
    icon: <Clock className="w-5 h-5 text-[#2CBEBF]" />,
  },
  {
    id: 'scattered',
    question: 'As informações da sua empresa estão espalhadas?',
    situation: 'Mensagens no WhatsApp, anotações de papel, emails isolados e arquivos em pastas locais desconexas.',
    impact: 'Clientes esquecidos, pedidos atrasados e falta de rastreabilidade de histórico.',
    strategy: 'Criar um repositório único de relacionamento e histórico operacional.',
    techSolution: 'Plataforma web integrada com portal de clientes e canal unificado de atendimento.',
    techType: 'Sites',
    result: '100% dos contatos rastreados com histórico unificado em um clique.',
    icon: <Folders className="w-5 h-5 text-[#002B58]" />,
  },
  {
    id: 'silos',
    question: 'Seus sistemas não conversam entre si?',
    situation: 'O financeiro não sabe o que o comercial vendeu; o estoque fica desatualizado gerando retrabalho manual.',
    impact: 'Erros de faturamento, atrasos na entrega e retrabalho constante entre equipes.',
    strategy: 'Construir barramento de integração que conecta os softwares legados em tempo real.',
    techSolution: 'Integrações via APIs e middlewares leves com sincronização bidirecional.',
    techType: 'Sistemas',
    result: 'Estoque e vendas sincronizados em tempo real com zero duplicidade.',
    icon: <RefreshCw className="w-5 h-5 text-[#2CBEBF]" />,
  },
  {
    id: 'data-blind',
    question: 'Você tem dados, mas não consegue transformá-los em decisões?',
    situation: 'Milhares de linhas registradas, mas o gestor ainda decide preços e contratações no feeling.',
    impact: 'Oportunidades de margem desperdiçadas e decisões tardias sobre produtos com prejuízo.',
    strategy: 'Definir os 5 indicadores vitais do negócio e estruturar painéis analíticos visuais.',
    techSolution: 'Dashboards de Business Intelligence interativos com alertas automáticos.',
    techType: 'Dashboards',
    result: 'Visibilidade instantânea da rentabilidade diária na palma da mão do gestor.',
    icon: <LineChart className="w-5 h-5 text-[#FE7001]" />,
  },
];

export const StrategicNarrative: React.FC<{ onConsultClick?: () => void }> = ({
  onConsultClick,
}) => {
  const [selectedId, setSelectedId] = useState<string>('spreadsheets');
  const activePain = PAIN_POINTS.find((p) => p.id === selectedId) || PAIN_POINTS[0];

  return (
    <div className="w-full">
      {/* Narrative Concept Flow Banner */}
      <div className="bg-[#002B58] text-white rounded-2xl p-6 sm:p-8 mb-10 border border-[#2CBEBF]/30 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 border-b border-white/10 pb-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-[#2CBEBF] flex items-center gap-1.5">
              <Target className="w-4 h-4 text-[#FE7001]" />
              Decisão Estratégica Central da MAVITH
            </span>
            <h3
              className="text-xl sm:text-2xl font-bold text-white mt-1"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Tecnologia nunca é o ponto de partida. É a consequência da estratégia.
            </h3>
          </div>
          <Badge variant="turquoise" size="md">
            Problema no Centro
          </Badge>
        </div>

        {/* The 5-step Flow Arrow Diagram */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 relative">
          <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex flex-col justify-between">
            <span className="text-xs font-mono text-[#FE7001] font-bold">ETAPA 01</span>
            <span className="text-base font-bold text-white mt-2">1. Problema</span>
            <span className="text-xs text-slate-300 mt-1">Dor real que o empresário sente no dia a dia.</span>
          </div>

          <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex flex-col justify-between">
            <span className="text-xs font-mono text-[#2CBEBF] font-bold">ETAPA 02</span>
            <span className="text-base font-bold text-white mt-2">2. Negócio</span>
            <span className="text-xs text-slate-300 mt-1">Impacto nos custos, margem e tempo da equipe.</span>
          </div>

          <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex flex-col justify-between">
            <span className="text-xs font-mono text-white font-bold">ETAPA 03</span>
            <span className="text-base font-bold text-white mt-2">3. Estratégia</span>
            <span className="text-xs text-slate-300 mt-1">Desenho do fluxo ideal e prioridades do gestor.</span>
          </div>

          <div className="p-4 rounded-xl bg-[#002447] border border-[#2CBEBF]/50 flex flex-col justify-between shadow-inner">
            <span className="text-xs font-mono text-[#2CBEBF] font-bold">ETAPA 04</span>
            <span className="text-base font-bold text-white mt-2 flex items-center gap-1">
              <Cpu className="w-4 h-4 text-[#2CBEBF]" />
              4. Tecnologia
            </span>
            <span className="text-xs text-slate-300 mt-1">Sites, Sistemas, IA ou Dashboards específicos.</span>
          </div>

          <div className="p-4 rounded-xl bg-[#FE7001]/20 border border-[#FE7001]/50 flex flex-col justify-between">
            <span className="text-xs font-mono text-[#FE7001] font-bold">ETAPA 05</span>
            <span className="text-base font-bold text-white mt-2 flex items-center gap-1">
              <TrendingUp className="w-4 h-4 text-[#FE7001]" />
              5. Resultado
            </span>
            <span className="text-xs text-slate-200 mt-1">Lucro, tempo recuperado e previsibilidade.</span>
          </div>
        </div>
      </div>

      {/* Interactive Problem Diagnostic Selector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left column: List of Real Problems */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
            Reconheça a situação da sua empresa:
          </div>

          {PAIN_POINTS.map((item) => {
            const isSelected = item.id === selectedId;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setSelectedId(item.id)}
                className={`text-left p-4 rounded-xl border transition-all duration-200 cursor-pointer flex items-start gap-3.5 ${
                  isSelected
                    ? 'bg-white border-[#002B58] shadow-[0_4px_16px_rgba(0,43,88,0.1)] ring-2 ring-[#002B58]/10'
                    : 'bg-white/80 border-slate-200 hover:border-slate-300 hover:bg-white'
                }`}
              >
                <div
                  className={`p-2.5 rounded-lg shrink-0 mt-0.5 ${
                    isSelected ? 'bg-[#EBF6FC]' : 'bg-slate-100'
                  }`}
                >
                  {item.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={`text-sm font-bold ${
                        isSelected ? 'text-[#002B58]' : 'text-slate-800'
                      }`}
                    >
                      {item.question}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                    {item.situation}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Right column: The Strategic Transformation Card */}
        <div className="lg:col-span-7">
          <Card
            variant="elevated"
            padding="lg"
            accent="blue"
            className="border-slate-200"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-[#EBF6FC]">
                  {activePain.icon}
                </div>
                <div>
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    Diagnóstico Estratégico
                  </span>
                  <h4 className="text-lg font-bold text-[#002B58]">
                    {activePain.question}
                  </h4>
                </div>
              </div>
              <Badge variant="turquoise">
                Vertical: {activePain.techType}
              </Badge>
            </div>

            <div className="space-y-6">
              {/* Problem in Context */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
                  <span className="w-2 h-2 rounded-full bg-red-500" />
                  O Problema Real no Negócio
                </div>
                <p className="text-sm text-slate-700 leading-relaxed font-medium">
                  {activePain.situation}
                </p>
                <div className="mt-2 text-xs text-red-600 bg-red-50 px-2.5 py-1 rounded inline-block">
                  <strong>Impacto:</strong> {activePain.impact}
                </div>
              </div>

              {/* The Strategy */}
              <div className="p-4 rounded-xl bg-[#EBF6FC]/60 border border-[#2CBEBF]/30">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#002B58] mb-1">
                  <span className="w-2 h-2 rounded-full bg-[#002B58]" />
                  A Estratégia MAVITH
                </div>
                <p className="text-sm text-[#002B58] leading-relaxed font-medium">
                  {activePain.strategy}
                </p>
              </div>

              {/* Technology + Concrete Result */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-white border border-slate-200">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#169495] block mb-1">
                    Solução Técnica
                  </span>
                  <p className="text-xs text-slate-700 font-semibold leading-normal">
                    {activePain.techSolution}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#FFF2E7] border border-[#FE7001]/30">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#C45500] flex items-center gap-1 mb-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#FE7001]" />
                    Resultado Mensurável
                  </span>
                  <p className="text-xs text-slate-800 font-bold leading-normal">
                    {activePain.result}
                  </p>
                </div>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-100">
                <span className="text-xs text-slate-500">
                  Não empurramos ferramentas prontas. Desenhamos a solução para o seu gargalo.
                </span>
                <Button
                  variant="primary-orange"
                  size="sm"
                  onClick={onConsultClick}
                  rightIcon={<ArrowRight className="w-4 h-4" />}
                >
                  Diagnosticar meu caso
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
