import React, { useState } from 'react';
import { Container } from '../../design-system/components/Container';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import { Card } from '../../design-system/components/Card';
import {
  Search,
  Clock,
  Calendar,
  ArrowRight,
  Sparkles,
  BookOpen,
  Filter,
  MonitorPlay,
  CheckCircle2,
  Share2,
} from 'lucide-react';
import {
  INSIGHT_ARTICLES,
  INSIGHT_CATEGORIES,
} from '../../data/insightsData';
import { InsightCategory } from '../../types/insights';
import { AuthoritySection } from '../authority/AuthoritySection';
import { SEOHead } from '../seo/SEOHead';

interface InsightsHubPageProps {
  onSelectArticle: (slug: string) => void;
  onOpenDemos: () => void;
  onOpenContactModal?: (interest?: string) => void;
}

export const InsightsHubPage: React.FC<InsightsHubPageProps> = ({
  onSelectArticle,
  onOpenDemos,
  onOpenContactModal,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<InsightCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const featuredArticle = INSIGHT_ARTICLES[0]; // "Quando uma planilha deixa de ser suficiente?"

  const filteredArticles = INSIGHT_ARTICLES.filter((article) => {
    const matchesCategory =
      selectedCategory === 'all' || article.category === selectedCategory;
    const matchesSearch =
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="py-10 bg-white">
      <SEOHead
        title="Insights & Artigos Estratégicos | MAVITH"
        description="Conteúdo de alta autoridade sobre Tecnologia, Negócios, IA, Automação e Dados para líderes e empresários que buscam eficiência operacional real."
        canonicalUrl="https://mavith.com.br/#/insights"
      />

      <Container size="xl">
        {/* Header Hero */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="teal" size="md" className="mb-3">
            Conhecimento com Propósito
          </Badge>

          <h1
            className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#002B58] tracking-tight leading-tight"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Insights práticos para negócios que querem crescer com tecnologia.
          </h1>

          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Sem promessas futuristas vazias ou jargões de desenvolvedor. Artigos aprofundados sobre processos reais, automação, IA e sistemas sob medida.
          </p>
        </div>

        {/* Featured Hero Article */}
        {selectedCategory === 'all' && searchQuery === '' && (
          <div className="mb-14">
            <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-[#002B58] via-[#002447] to-[#001833] text-white p-8 sm:p-10 lg:p-12 shadow-xl border border-slate-800">
              <div className="absolute top-0 right-0 w-96 h-96 bg-[#2CBEBF]/15 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10 max-w-3xl">
                <div className="flex flex-wrap items-center gap-3 mb-4">
                  <Badge variant="orange" size="sm">
                    Destaque Editorial
                  </Badge>
                  <span className="text-xs font-mono text-[#2CBEBF] font-semibold">
                    {featuredArticle.category}
                  </span>
                  <span className="text-xs text-slate-400">•</span>
                  <span className="text-xs text-slate-300 flex items-center gap-1 font-mono">
                    <Clock className="w-3.5 h-3.5" />
                    {featuredArticle.readTime}
                  </span>
                </div>

                <h2
                  className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white leading-tight mb-4 hover:text-[#2CBEBF] transition-colors cursor-pointer"
                  onClick={() => onSelectArticle(featuredArticle.slug)}
                  style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                >
                  {featuredArticle.title}
                </h2>

                <p className="text-sm sm:text-base text-slate-200 leading-relaxed mb-6">
                  {featuredArticle.subtitle}
                </p>

                <div className="flex flex-wrap items-center gap-4">
                  <Button
                    variant="primary-teal"
                    size="md"
                    onClick={() => onSelectArticle(featuredArticle.slug)}
                    rightIcon={<ArrowRight className="w-4 h-4" />}
                  >
                    Ler Artigo Completo
                  </Button>
                  <span className="text-xs text-slate-400">
                    Publicado em {featuredArticle.date} por {featuredArticle.author.name}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Search & Category Filter Toolbar */}
        <div className="mb-10 space-y-4">
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
            {/* Category Pills */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  selectedCategory === 'all'
                    ? 'bg-[#002B58] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Todas as Categorias ({INSIGHT_ARTICLES.length})
              </button>

              {INSIGHT_CATEGORIES.map((cat) => {
                const count = INSIGHT_ARTICLES.filter((a) => a.category === cat.id).length;
                const isActive = selectedCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                      isActive
                        ? 'bg-[#002B58] text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {cat.label} ({count})
                  </button>
                );
              })}
            </div>

            {/* Search Box */}
            <div className="relative w-full md:w-72 shrink-0">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Buscar por tema ou palavra..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-[#2CBEBF] transition-colors"
              />
            </div>
          </div>
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {filteredArticles.map((article) => (
            <Card
              key={article.slug}
              variant="outline"
              padding="lg"
              className="bg-white hover:border-[#2CBEBF]/80 transition-all duration-300 shadow-xs hover:shadow-md flex flex-col justify-between group cursor-pointer"
              onClick={() => onSelectArticle(article.slug)}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#2CBEBF] font-mono">
                    {article.category}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{article.readTime}</span>
                  </div>
                </div>

                <h3
                  className="text-lg sm:text-xl font-bold text-[#002B58] mb-2.5 group-hover:text-[#2CBEBF] transition-colors leading-snug"
                  style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                >
                  {article.title}
                </h3>

                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6 line-clamp-3">
                  {article.subtitle}
                </p>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs text-slate-400 font-mono">
                  {article.date}
                </span>

                <span className="text-xs font-bold text-[#002B58] group-hover:text-[#2CBEBF] flex items-center gap-1 transition-colors">
                  Ler artigo
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </span>
              </div>
            </Card>
          ))}
        </div>

        {filteredArticles.length === 0 && (
          <div className="text-center py-16 bg-slate-50 border border-dashed border-slate-200 rounded-3xl">
            <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <h4 className="text-lg font-bold text-[#002B58] mb-1">
              Nenhum artigo encontrado
            </h4>
            <p className="text-xs text-slate-500 mb-4">
              Tente buscar por outros termos ou selecione outra categoria.
            </p>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
              }}
            >
              Limpar Filtros
            </Button>
          </div>
        )}

        {/* Authority Section Integration */}
        <div className="mt-20 pt-16 border-t border-slate-200">
          <AuthoritySection
            onOpenDemos={onOpenDemos}
            onOpenContactModal={onOpenContactModal}
          />
        </div>
      </Container>
    </div>
  );
};
