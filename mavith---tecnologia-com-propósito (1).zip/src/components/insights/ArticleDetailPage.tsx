import React, { useState } from 'react';
import { Container } from '../../design-system/components/Container';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import { Card } from '../../design-system/components/Card';
import {
  Clock,
  Calendar,
  ArrowLeft,
  ArrowRight,
  Share2,
  Check,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  Quote,
  Sparkles,
  BookOpen,
  User,
  Layers,
  ChevronRight,
} from 'lucide-react';
import { InsightArticle } from '../../types/insights';
import { getArticleBySlug, INSIGHT_ARTICLES } from '../../data/insightsData';
import { SEOHead } from '../seo/SEOHead';

interface ArticleDetailPageProps {
  article: InsightArticle;
  onBackToInsights: () => void;
  onSelectArticle: (slug: string) => void;
  onOpenContactModal?: (interest?: string) => void;
  onNavigateToSolution?: (slug: string) => void;
}

export const ArticleDetailPage: React.FC<ArticleDetailPageProps> = ({
  article,
  onBackToInsights,
  onSelectArticle,
  onOpenContactModal,
  onNavigateToSolution,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const relatedArticles = article.relatedArticleSlugs
    .map((slug) => getArticleBySlug(slug))
    .filter(Boolean) as InsightArticle[];

  const articleJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': `https://mavith.com.br/#/insights/${article.slug}`,
    },
    headline: article.title,
    description: article.subtitle,
    datePublished: article.isoDate,
    dateModified: article.isoDate,
    author: {
      '@type': 'Person',
      name: article.author.name,
      jobTitle: article.author.role,
    },
    publisher: {
      '@type': 'Organization',
      name: 'MAVITH',
      logo: {
        '@type': 'ImageObject',
        url: 'https://mavith.com.br/logo.png',
      },
    },
    articleSection: article.category,
    keywords: article.seo.keywords.join(', '),
  };

  return (
    <article className="py-10 bg-white" itemScope itemType="https://schema.org/Article">
      <SEOHead
        title={article.seo.metaTitle}
        description={article.seo.metaDescription}
        canonicalUrl={`https://mavith.com.br/#/insights/${article.slug}`}
        ogType="article"
        publishedTime={article.isoDate}
        authorName={article.author.name}
        category={article.category}
        jsonLdSchema={articleJsonLd}
      />

      <Container size="lg">
        {/* Navigation Breadcrumbs & Back */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8 pb-4 border-b border-slate-100">
          <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <button
              onClick={onBackToInsights}
              className="hover:text-[#002B58] transition-colors flex items-center gap-1 font-semibold"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Voltar para Insights</span>
            </button>
            <span>/</span>
            <span className="text-[#2CBEBF] font-mono font-bold uppercase">{article.category}</span>
          </nav>

          <Button
            variant="secondary"
            size="sm"
            onClick={handleCopyLink}
            leftIcon={copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
          >
            {copied ? 'Link Copiado!' : 'Compartilhar Artigo'}
          </Button>
        </div>

        {/* Article Header */}
        <header className="mb-12">
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <Badge variant="teal" size="md">
              {article.category}
            </Badge>
            <span className="text-xs font-mono bg-slate-100 text-slate-700 px-3 py-1 rounded-full font-semibold">
              {article.coverBadge}
            </span>
            <span className="text-xs text-slate-400 font-mono flex items-center gap-1.5 ml-auto">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <time dateTime={article.isoDate}>{article.readTime}</time>
            </span>
          </div>

          <h1
            className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#002B58] tracking-tight leading-tight mb-6"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            itemProp="headline"
          >
            {article.title}
          </h1>

          <p
            className="text-lg sm:text-xl text-slate-600 leading-relaxed font-normal"
            itemProp="description"
          >
            {article.subtitle}
          </p>

          {/* Author Card Meta */}
          <div className="mt-8 pt-6 border-t border-slate-100 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-[#002B58] text-white flex items-center justify-center font-bold text-sm">
                M
              </div>
              <div>
                <div className="text-xs sm:text-sm font-bold text-[#002B58]">
                  {article.author.name}
                </div>
                <div className="text-xs text-slate-500 font-mono">
                  {article.author.role} • {article.date}
                </div>
              </div>
            </div>

            <span className="text-xs font-mono text-slate-400 hidden sm:inline-block">
              Leitura recomendada para diretores e gestores
            </span>
          </div>
        </header>

        {/* Visual Cover Banner Accent */}
        <div className="mb-12 p-8 rounded-3xl bg-gradient-to-r from-[#002B58] to-[#001D3D] text-white relative overflow-hidden shadow-lg border border-slate-800">
          <div className="absolute right-0 top-0 w-80 h-80 bg-[#2CBEBF]/15 rounded-full blur-3xl pointer-events-none" />
          <div className="relative z-10 max-w-xl">
            <span className="text-xs font-mono font-bold text-[#2CBEBF] uppercase tracking-wider block mb-1">
              Princípio Editorial MAVITH
            </span>
            <h2 className="text-lg font-bold text-white mb-2">
              "Tecnologia só tem valor quando simplifica a operação e protege a margem da empresa."
            </h2>
            <p className="text-xs text-slate-300">
              Cada conceito apresentado neste artigo foi testado em operações corporativas reais.
            </p>
          </div>
        </div>

        {/* Article Body Content */}
        <div className="prose prose-slate max-w-none space-y-10 text-slate-700 leading-relaxed text-base">
          {/* Introduction Block */}
          <div className="space-y-4 text-base sm:text-lg text-slate-800 font-normal leading-relaxed border-l-4 border-[#2CBEBF] pl-5 py-1 bg-slate-50/50 rounded-r-2xl">
            {article.introduction.map((p, idx) => (
              <p key={idx}>{p}</p>
            ))}
          </div>

          {/* Structured Sections */}
          {article.sections.map((section, idx) => (
            <section key={idx} className="space-y-4 pt-4">
              <h2
                className="text-2xl font-bold text-[#002B58] tracking-tight"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
              >
                {section.title}
              </h2>

              {section.paragraphs.map((p, pIdx) => (
                <p key={pIdx} className="leading-relaxed">
                  {p}
                </p>
              ))}

              {/* Callout Box */}
              {section.callout && (
                <div
                  className={`p-5 rounded-2xl border flex items-start gap-4 my-6 ${
                    section.callout.type === 'warning'
                      ? 'bg-amber-50/70 border-amber-200 text-amber-900'
                      : section.callout.type === 'tip'
                      ? 'bg-teal-50/70 border-teal-200 text-teal-950'
                      : 'bg-slate-50 border-slate-200 text-slate-800'
                  }`}
                >
                  {section.callout.type === 'warning' && (
                    <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  )}
                  {section.callout.type === 'tip' && (
                    <Lightbulb className="w-5 h-5 text-[#2CBEBF] shrink-0 mt-0.5" />
                  )}
                  {section.callout.type === 'quote' && (
                    <Quote className="w-5 h-5 text-[#002B58] shrink-0 mt-0.5" />
                  )}

                  <div>
                    {section.callout.title && (
                      <h4 className="text-xs font-bold uppercase tracking-wider mb-1">
                        {section.callout.title}
                      </h4>
                    )}
                    <p className="text-xs sm:text-sm leading-relaxed">
                      {section.callout.text}
                    </p>
                  </div>
                </div>
              )}

              {/* Checklist Box */}
              {section.checklist && (
                <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl my-6 space-y-3">
                  <h4 className="text-sm font-bold text-[#002B58] uppercase tracking-wider">
                    {section.checklist.title}
                  </h4>
                  <div className="space-y-2">
                    {section.checklist.items.map((item, itemIdx) => (
                      <div key={itemIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Comparison Table */}
              {section.comparison && (
                <div className="my-6 border border-slate-200 rounded-2xl overflow-hidden shadow-2xs">
                  <div className="p-4 bg-slate-50 border-b border-slate-200">
                    <h4 className="text-xs font-bold text-[#002B58] uppercase tracking-wider">
                      {section.comparison.title}
                    </h4>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 bg-slate-100/60 font-semibold text-slate-600">
                          <th className="p-3.5">Critério</th>
                          <th className="p-3.5 text-rose-700 bg-rose-50/50">
                            {section.comparison.colLeft}
                          </th>
                          <th className="p-3.5 text-emerald-800 bg-emerald-50/50">
                            {section.comparison.colRight}
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {section.comparison.rows.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-slate-50/80 transition-colors">
                            <td className="p-3.5 font-bold text-[#002B58]">
                              {row.aspect}
                            </td>
                            <td className="p-3.5 text-slate-600 bg-rose-50/20">
                              {row.left}
                            </td>
                            <td className="p-3.5 text-slate-800 font-medium bg-emerald-50/20">
                              {row.right}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </section>
          ))}

          {/* Key Takeaways */}
          <div className="p-6 sm:p-8 bg-[#002B58]/5 border border-[#002B58]/15 rounded-3xl my-10">
            <h3 className="text-base sm:text-lg font-bold text-[#002B58] mb-4 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#FE7001]" />
              Pontos Principais para Lembrar (Key Takeaways)
            </h3>
            <ul className="space-y-2.5 text-xs sm:text-sm text-slate-700">
              {article.keyTakeaways.map((takeaway, idx) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <span className="w-2 h-2 rounded-full bg-[#FE7001] mt-2 shrink-0" />
                  <span>{takeaway}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Conclusion */}
          <div className="space-y-4 pt-4 border-t border-slate-100">
            <h2 className="text-2xl font-bold text-[#002B58]">Conclusão</h2>
            {article.conclusion.map((p, idx) => (
              <p key={idx} className="leading-relaxed">
                {p}
              </p>
            ))}
          </div>
        </div>

        {/* High Conversion CTA */}
        <div className="mt-16 p-8 sm:p-10 rounded-3xl bg-gradient-to-br from-[#002B58] via-[#002242] to-[#00172E] text-white shadow-xl relative overflow-hidden">
          <div className="relative z-10 max-w-2xl">
            <Badge variant="orange" size="md" className="mb-3">
              Próximo Passo
            </Badge>
            <h3
              className="text-2xl sm:text-3xl font-extrabold text-white leading-tight"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Identificou esse gargalo na sua empresa?
            </h3>
            <p className="mt-3 text-xs sm:text-sm text-slate-200 leading-relaxed mb-6">
              Nossa equipe pode conduzir um diagnóstico operacional de 30 minutos, mapear suas rotinas e apresentar um plano prático com tecnologia sob medida.
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <Button
                variant="primary-orange"
                size="md"
                onClick={() => onOpenContactModal?.(article.slug)}
                rightIcon={<ArrowRight className="w-4 h-4" />}
              >
                Agendar Diagnóstico Gratuito
              </Button>

              {article.targetSolutionSlug && onNavigateToSolution && (
                <Button
                  variant="secondary"
                  size="md"
                  onClick={() => onNavigateToSolution(article.targetSolutionSlug!)}
                >
                  Conhecer Solução Relacionada
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Related Articles */}
        {relatedArticles.length > 0 && (
          <div className="mt-16 pt-12 border-t border-slate-200">
            <div className="flex items-center justify-between mb-8">
              <div>
                <span className="text-xs font-mono font-bold text-[#2CBEBF] uppercase tracking-wider block">
                  Continue Aprendendo
                </span>
                <h3 className="text-xl sm:text-2xl font-bold text-[#002B58]">
                  Artigos Relacionados
                </h3>
              </div>
              <Button variant="ghost" size="sm" onClick={onBackToInsights}>
                Ver todos os insights
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {relatedArticles.map((rel) => (
                <Card
                  key={rel.slug}
                  variant="outline"
                  padding="md"
                  className="bg-white hover:border-[#2CBEBF] transition-all cursor-pointer flex flex-col justify-between group"
                  onClick={() => onSelectArticle(rel.slug)}
                >
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase text-[#2CBEBF] mb-2 block">
                      {rel.category}
                    </span>
                    <h4 className="text-sm font-bold text-[#002B58] group-hover:text-[#2CBEBF] transition-colors leading-snug mb-2">
                      {rel.title}
                    </h4>
                    <p className="text-xs text-slate-500 line-clamp-2">
                      {rel.subtitle}
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] font-mono text-slate-400 flex items-center justify-between">
                    <span>{rel.readTime}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#002B58] group-hover:translate-x-1 transition-transform" />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}
      </Container>
    </article>
  );
};
