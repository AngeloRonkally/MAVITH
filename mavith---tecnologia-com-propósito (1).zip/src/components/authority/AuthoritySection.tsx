import React from 'react';
import { Container } from '../../design-system/components/Container';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import { Card } from '../../design-system/components/Card';
import {
  ShieldCheck,
  Compass,
  Layers,
  Sparkles,
  GitBranch,
  MonitorPlay,
  ArrowRight,
  CheckCircle2,
  Cpu,
  Target,
  FileCode2,
  Users2,
} from 'lucide-react';

interface AuthoritySectionProps {
  onOpenDemos?: () => void;
  onOpenContactModal?: (interest?: string) => void;
  className?: string;
  variant?: 'full' | 'compact';
}

export const AuthoritySection: React.FC<AuthoritySectionProps> = ({
  onOpenDemos,
  onOpenContactModal,
  className = '',
  variant = 'full',
}) => {
  const pillars = [
    {
      id: 'metodologia',
      number: '01',
      title: 'Metodologia sem Achismos',
      badge: 'Engenharia de Valor',
      icon: Compass,
      color: 'text-[#002B58]',
      description:
        'Não começamos escrevendo código sem entender a fundo o fluxo financeiro e operacional do seu negócio. Mapeamos os gargalos reais antes de projetar qualquer tela.',
      points: [
        'Diagnóstico operacional de 30 minutos',
        'Arquitetura orientada ao fluxo de receita',
        'Ciclos curtos de entrega com validação contínua',
      ],
    },
    {
      id: 'conhecimento',
      number: '02',
      title: 'Conhecimento Pragmático',
      badge: 'Zero Hype',
      icon: ShieldCheck,
      color: 'text-[#FE7001]',
      description:
        'Rejeitamos o uso de novidades técnicas apenas para parecer moderno. Se uma automação simples resolve o problema melhor do que um modelo caro de IA, é ela que vamos recomendar.',
      points: [
        'Foco absoluto no Retorno sobre Investimento (ROI)',
        'Tecnologias maduras, velozes e sustentáveis',
        'Linguagem executiva sem jargões de desenvolvedor',
      ],
    },
    {
      id: 'solucoes',
      number: '03',
      title: 'Soluções Integradas',
      badge: 'Ecossistema Coeso',
      icon: Layers,
      color: 'text-[#2CBEBF]',
      description:
        'Seu site, seu sistema de gestão, seu WhatsApp e seus relatórios executivos devem conversar entre si. Construímos pontes tecnológicas que unificam a empresa inteira.',
      points: [
        'APIs seguras e webhooks em tempo real',
        'Bancos de dados centralizados na nuvem',
        'Compatibilidade com ferramentas legadas do cliente',
      ],
    },
    {
      id: 'processos',
      number: '04',
      title: 'Processos Auditáveis',
      badge: 'Transparência Total',
      icon: GitBranch,
      color: 'text-[#002B58]',
      description:
        'Você nunca fica no escuro sobre o andamento do seu projeto. Etapas claras, código documentado e transferência total de propriedade para a sua empresa.',
      points: [
        'Cronograma e escopo definidos com precisão',
        'Código limpo de sua total propriedade',
        'Treinamento e suporte assistido pós-lançamento',
      ],
    },
  ];

  return (
    <section className={`py-16 ${className}`}>
      <Container size="xl">
        {/* Header Block */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <Badge variant="orange" size="md" className="mb-3">
            Autoridade & Princípios
          </Badge>

          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#002B58] tracking-tight leading-tight"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Tecnologia pensada para negócios reais.
          </h2>

          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Combinamos rigor técnico de engenharia de software com visão estratégica de negócios. Sem promessas irrealistas, sem ferramentas genéricas engessadas e sem burocracia.
          </p>
        </div>

        {/* 4 Authority Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {pillars.map((item) => {
            const Icon = item.icon;
            return (
              <Card
                key={item.id}
                variant="outline"
                padding="lg"
                className="bg-white hover:border-[#2CBEBF]/70 transition-all duration-300 shadow-xs hover:shadow-md flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-4 mb-4">
                    <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center">
                      <Icon className={`w-6 h-6 ${item.color}`} />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-slate-400">
                        Pilar {item.number}
                      </span>
                      <span className="text-xs font-mono bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-full font-semibold">
                        {item.badge}
                      </span>
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-[#002B58] mb-2">
                    {item.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6">
                    {item.description}
                  </p>

                  <div className="pt-4 border-t border-slate-100 space-y-2">
                    {item.points.map((point) => (
                      <div key={point} className="flex items-start gap-2 text-xs text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-[#2CBEBF] shrink-0 mt-0.5" />
                        <span>{point}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* 5th Pillar: Demonstrações Visuais / Interativas Highlight */}
        {variant === 'full' && (
          <div className="mt-10 p-8 sm:p-10 rounded-3xl bg-gradient-to-br from-[#002B58] via-[#002447] to-[#001C3B] text-white shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-80 h-80 bg-[#2CBEBF]/15 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#FE7001]/15 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8">
              <div className="max-w-2xl text-center lg:text-left">
                <span className="text-xs font-mono font-bold text-[#FE7001] uppercase tracking-wider block mb-2">
                  Demonstrações Interativas MAVITH
                </span>
                <h3
                  className="text-2xl sm:text-3xl font-extrabold text-white leading-tight"
                  style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                >
                  Veja a tecnologia funcionando antes de decidir.
                </h3>
                <p className="mt-3 text-xs sm:text-sm text-slate-200 leading-relaxed">
                  Criamos simulações completas de Dashboard, CRM de Vendas, Sistema de Ordens de Serviço, Agente de IA Conversacional e Automações de Fluxo com dados reais de teste.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3 shrink-0">
                {onOpenDemos && (
                  <Button
                    variant="primary-orange"
                    size="md"
                    onClick={onOpenDemos}
                    rightIcon={<MonitorPlay className="w-4 h-4" />}
                  >
                    Acessar Demonstrações Interativas
                  </Button>
                )}
                {onOpenContactModal && (
                  <Button
                    variant="secondary"
                    size="md"
                    onClick={() => onOpenContactModal('autoridade-metodologia')}
                  >
                    Falar com um Arquiteto
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}
      </Container>
    </section>
  );
};
