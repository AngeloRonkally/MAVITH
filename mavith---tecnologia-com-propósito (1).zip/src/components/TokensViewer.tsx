import React, { useState } from 'react';
import { MAVITH_TOKENS } from '../design-system/tokens';
import { Card } from '../design-system/components/Card';
import { Badge } from '../design-system/components/Badge';
import { Copy, Check, Terminal } from 'lucide-react';

export const TokensViewer: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [activeCategory, setActiveCategory] = useState<keyof typeof MAVITH_TOKENS>('colors');

  const copyTokens = () => {
    try {
      if (navigator?.clipboard?.writeText) {
        navigator.clipboard.writeText(JSON.stringify(MAVITH_TOKENS, null, 2)).catch(() => {});
      }
    } catch {
      // Ignore clipboard error
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const categories: { id: keyof typeof MAVITH_TOKENS; label: string }[] = [
    { id: 'colors', label: 'Cores (Colors)' },
    { id: 'typography', label: 'Tipografia (Typography)' },
    { id: 'spacing', label: 'Espaçamento (Spacing)' },
    { id: 'borderRadius', label: 'Bordas (Border Radius)' },
    { id: 'shadows', label: 'Sombras (Shadows)' },
    { id: 'transitions', label: 'Transições (Transitions)' },
    { id: 'breakpoints', label: 'Breakpoints' },
  ];

  return (
    <div className="w-full">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-[#002B58]">
            Arquitetura de Design Tokens
          </span>
          <h3
            className="text-2xl font-bold text-[#002B58] mt-1"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Tokens Centralizados da Fundação
          </h3>
          <p className="text-sm text-slate-500 mt-1">
            Decisões visuais únicas compartilhadas para todas as próximas fases do projeto.
          </p>
        </div>

        <button
          type="button"
          onClick={copyTokens}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#002B58] hover:bg-[#003873] text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
        >
          {copied ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span>Tokens Copiados (JSON)</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              <span>Copiar Todos os Tokens</span>
            </>
          )}
        </button>
      </div>

      {/* Category selector pills */}
      <div className="flex flex-wrap items-center gap-2 mb-6">
        {categories.map((cat) => {
          const isSelected = cat.id === activeCategory;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#002B58] text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Code Inspector Block */}
      <Card variant="dark" padding="none" className="bg-[#001C3B] border-slate-800">
        <div className="flex items-center justify-between px-6 py-3 border-b border-slate-800 bg-[#001833]">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-[#2CBEBF]" />
            <span className="text-xs font-mono text-slate-300">
              tokens.{activeCategory}
            </span>
          </div>
          <Badge variant="turquoise" size="sm">
            Fase 1 Frozen
          </Badge>
        </div>

        <pre className="p-6 text-xs font-mono text-emerald-300 overflow-x-auto max-h-96 leading-relaxed selection:bg-[#2CBEBF]/40">
          <code>{JSON.stringify(MAVITH_TOKENS[activeCategory], null, 2)}</code>
        </pre>
      </Card>
    </div>
  );
};
