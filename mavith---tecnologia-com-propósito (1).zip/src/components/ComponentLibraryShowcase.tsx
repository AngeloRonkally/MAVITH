import React, { useState } from 'react';
import { Button } from '../design-system/components/Button';
import { Card } from '../design-system/components/Card';
import { Badge, Tag } from '../design-system/components/Badge';
import { Input, Textarea, Select } from '../design-system/components/Input';
import { Modal } from '../design-system/components/Modal';
import { Divider } from '../design-system/components/Divider';
import {
  ArrowRight,
  Send,
  Building2,
  Mail,
  User,
  Sparkles,
  CheckCircle,
  HelpCircle,
  Laptop,
} from 'lucide-react';

export const ComponentLibraryShowcase: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [buttonLoading, setButtonLoading] = useState(false);
  
  // Interactive form state
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    empresa: '',
    setor: 'comercio',
    desafio: '',
  });

  const [activeTags, setActiveTags] = useState<string[]>([
    'Planilhas',
    'Automação',
    'WhatsApp',
    'Dashboards',
  ]);

  const handleRemoveTag = (tagToRemove: string) => {
    setActiveTags(activeTags.filter((t) => t !== tagToRemove));
  };

  const handleSimulateLoading = () => {
    setButtonLoading(true);
    setTimeout(() => {
      setButtonLoading(false);
    }, 1500);
  };

  const [submittedMessage, setSubmittedMessage] = useState(false);

  return (
    <div className="w-full space-y-16">
      {/* 1. Botões & Microinterações */}
      <div>
        <div className="mb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#FE7001]">
            Componentes Interativos
          </span>
          <h3
            className="text-2xl font-bold text-[#002B58] mt-1"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Sistema de Botões (Button System)
          </h3>
          <p className="text-sm text-slate-500 mt-1">
            Hierarquia direta: Primary Blue (institucional), Primary Orange (ação de conversão),
            Secondary (neutro) e Ghost. Padding calculado com proporção horizontal 2x vertical.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Variantes Principais */}
          <Card variant="outline" padding="lg" className="space-y-6 bg-white">
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-500">
              Variantes Principais & Propósitos
            </h4>

            <div className="flex flex-wrap items-center gap-3">
              <Button variant="primary-blue" size="md">
                Primary Blue (Institucional)
              </Button>
              <Button variant="primary-orange" size="md" rightIcon={<ArrowRight className="w-4 h-4" />}>
                Primary Orange (Ação / CTA)
              </Button>
              <Button variant="secondary" size="md">
                Secondary (Outline)
              </Button>
              <Button variant="ghost" size="md">
                Ghost
              </Button>
            </div>

            {/* Sizes */}
            <div className="pt-4 border-t border-slate-100">
              <span className="text-xs font-semibold text-slate-400 block mb-3 uppercase">
                Escala de Tamanhos (sm, md, lg)
              </span>
              <div className="flex flex-wrap items-center gap-3">
                <Button variant="primary-blue" size="sm">
                  Small (sm)
                </Button>
                <Button variant="primary-blue" size="md">
                  Medium (md)
                </Button>
                <Button variant="primary-blue" size="lg">
                  Large (lg)
                </Button>
              </div>
            </div>
          </Card>

          {/* Estados: Loading, Disabled, Dark Variant */}
          <Card variant="outline" padding="lg" className="space-y-6 bg-white flex flex-col justify-between">
            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-4">
                Estados de Feedback & Contexto
              </h4>

              <div className="flex flex-wrap items-center gap-3">
                <Button
                  variant="primary-orange"
                  size="md"
                  isLoading={buttonLoading}
                  onClick={handleSimulateLoading}
                >
                  {buttonLoading ? 'Processando...' : 'Clique p/ Testar Loading'}
                </Button>

                <Button variant="secondary" size="md" disabled>
                  Desabilitado
                </Button>

                <Button
                  variant="primary-blue"
                  size="md"
                  leftIcon={<Send className="w-4 h-4" />}
                >
                  Com Ícone à Esquerda
                </Button>
              </div>
            </div>

            {/* Dark Surface Context */}
            <div className="p-4 rounded-xl bg-[#001C3B] text-white flex items-center justify-between gap-4 mt-4">
              <div>
                <span className="text-xs text-slate-300 font-semibold block">
                  Contexto Fundo Escuro
                </span>
                <span className="text-[11px] text-[#2CBEBF]">
                  Outline contrastante
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="primary-orange" size="sm">
                  Fale com a MAVITH
                </Button>
                <Button variant="outline-white" size="sm">
                  Saiba Mais
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* 2. Cartões Corporativos Premium (Cards) */}
      <div>
        <div className="mb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#2CBEBF]">
            Estrutura de Conteúdo
          </span>
          <h3
            className="text-2xl font-bold text-[#002B58] mt-1"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Cartões Corporativos Premium (Cards)
          </h3>
          <p className="text-sm text-slate-500 mt-1">
            Design limpo, sem sombras exageradas, com borda sutil de 1px e acentos funcionais de topo.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card variant="elevated" accent="blue" padding="md">
            <div className="flex items-center justify-between mb-3">
              <Badge variant="blue">Estratégia</Badge>
              <Building2 className="w-4 h-4 text-slate-400" />
            </div>
            <h4 className="text-base font-bold text-[#002B58]">
              Diagnóstico do Negócio
            </h4>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Mapeamos os gargalos operacionais antes de propor qualquer ferramenta tecnológica.
            </p>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Etapa 01</span>
              <span className="font-semibold text-[#002B58]">Consistente</span>
            </div>
          </Card>

          <Card variant="elevated" accent="turquoise" padding="md">
            <div className="flex items-center justify-between mb-3">
              <Badge variant="turquoise">Inteligência</Badge>
              <Sparkles className="w-4 h-4 text-[#2CBEBF]" />
            </div>
            <h4 className="text-base font-bold text-[#002B58]">
              Soluções Conectadas
            </h4>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Integração entre sistemas legados, APIs e agentes cognitivos sob medida para o gestor.
            </p>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Etapa 02</span>
              <span className="font-semibold text-[#169495]">Fluido</span>
            </div>
          </Card>

          <Card variant="elevated" accent="orange" padding="md">
            <div className="flex items-center justify-between mb-3">
              <Badge variant="orange">Resultado</Badge>
              <CheckCircle className="w-4 h-4 text-[#FE7001]" />
            </div>
            <h4 className="text-base font-bold text-[#002B58]">
              Retorno Concreto
            </h4>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Menos horas gastas em retrabalho manual e mais clareza para expandir faturamento.
            </p>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Etapa 03</span>
              <span className="font-semibold text-[#FE7001]">Mensurável</span>
            </div>
          </Card>
        </div>
      </div>

      {/* 3. Formulários Acessíveis (Inputs, Select, Textarea) */}
      <div>
        <div className="mb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#002B58]">
            Entrada de Dados & Acessibilidade
          </span>
          <h3
            className="text-2xl font-bold text-[#002B58] mt-1"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Formulários & Campos de Entrada (Form Controls)
          </h3>
          <p className="text-sm text-slate-500 mt-1">
            Labels claros com asterisco em campos obrigatórios, estados de foco acessíveis, ícones e feedback.
          </p>
        </div>

        <Card variant="outline" padding="lg" className="bg-white">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <Input
              id="showcase-nome"
              label="Nome do Gestor"
              placeholder="Ex: Carlos Silva"
              required
              leftIcon={<User className="w-4 h-4" />}
              value={formData.nome}
              onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
              helperText="Como prefere ser chamado"
            />

            <Input
              id="showcase-email"
              label="E-mail Corporativo"
              type="email"
              placeholder="carlos@empresa.com.br"
              required
              leftIcon={<Mail className="w-4 h-4" />}
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              helperText="Não enviamos spam comercial"
            />

            <Select
              id="showcase-setor"
              label="Segmento da Empresa"
              required
              value={formData.setor}
              onChange={(e) => setFormData({ ...formData, setor: e.target.value })}
              options={[
                { value: 'comercio', label: 'Comércio / Varejo' },
                { value: 'servicos', label: 'Prestação de Serviços' },
                { value: 'industria', label: 'Indústria / Manufatura' },
                { value: 'saude', label: 'Clínica / Saúde' },
                { value: 'tecnologia', label: 'Tecnologia / Consultoria' },
              ]}
              helperText="Ajuda a contextualizar a solução"
            />
          </div>

          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-6">
            <Textarea
              id="showcase-desafio"
              label="Principal Gargalo da Empresa Hoje"
              placeholder="Ex: Nossa equipe perde horas preenchendo planilhas de estoque e os pedidos demoram a ser faturados..."
              rows={3}
              value={formData.desafio}
              onChange={(e) => setFormData({ ...formData, desafio: e.target.value })}
              helperText="Descreva o problema com suas próprias palavras"
            />

            <div className="flex flex-col justify-between">
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-[#002B58] block mb-2">
                  Dores Frequentes Selecionadas (Tags Interativas)
                </label>
                <div className="flex flex-wrap gap-2">
                  {activeTags.map((tag) => (
                    <Tag
                      key={tag}
                      label={tag}
                      active
                      color="blue"
                      onRemove={() => handleRemoveTag(tag)}
                    />
                  ))}
                </div>
                <p className="text-xs text-slate-400 mt-2">
                  Clique no &apos;×&apos; para remover uma tag.
                </p>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <Button
                  variant="primary-blue"
                  size="md"
                  onClick={() => setIsModalOpen(true)}
                  leftIcon={<Laptop className="w-4 h-4" />}
                >
                  Abrir em Modal de Diagnóstico
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* 4. Badges, Tags & Divisores */}
      <div>
        <div className="mb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#FE7001]">
            Microelementos & Divisores
          </span>
          <h3
            className="text-2xl font-bold text-[#002B58] mt-1"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Badges, Tags & Conexões
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          <Card variant="flat" padding="md" className="space-y-4">
            <span className="text-xs font-bold uppercase text-slate-500 block">
              Badges de Status & Categoria
            </span>
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="turquoise" icon={<Sparkles className="w-3 h-3" />}>
                Inteligência Analítica
              </Badge>
              <Badge variant="blue">
                Sistemas Sob Medida
              </Badge>
              <Badge variant="orange">
                Ação Prioritária
              </Badge>
              <Badge variant="neutral">
                Fase 1: Fundação
              </Badge>
            </div>
          </Card>

          <Card variant="flat" padding="md" className="space-y-4">
            <span className="text-xs font-bold uppercase text-slate-500 block">
              Divisores com Nós de Circuito
            </span>
            <Divider withNode />
            <Divider label="Ou continue explorando" />
          </Card>
        </div>
      </div>

      {/* Interactive Modal Component Demonstration */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Diagnóstico Estratégico MAVITH"
        description="Entendemos primeiro a realidade do seu negócio para desenhar a solução exata."
        footer={
          <>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setIsModalOpen(false)}
            >
              Cancelar
            </Button>
            <Button
              variant="primary-orange"
              size="sm"
              onClick={() => {
                setSubmittedMessage(true);
                setTimeout(() => {
                  setSubmittedMessage(false);
                  setIsModalOpen(false);
                }, 2000);
              }}
              rightIcon={<Send className="w-4 h-4" />}
            >
              {submittedMessage ? 'Enviado!' : 'Enviar Diagnóstico'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {submittedMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-semibold flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Diagnóstico simulado recebido com sucesso! Nossa equipe entrará em contato.</span>
            </div>
          )}
          <div className="p-3 bg-[#EBF6FC] rounded-lg text-xs text-[#002B58] flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-[#2CBEBF] shrink-0" />
            <span>
              Não presuma conhecimento técnico. Falamos a língua da sua operação diária.
            </span>
          </div>

          <Input
            id="modal-nome"
            label="Seu Nome ou da sua Empresa"
            placeholder="Ex: Padaria Central / Dr. Roberto"
            defaultValue={formData.nome || formData.empresa}
          />

          <Input
            id="modal-email"
            label="WhatsApp ou E-mail para contato"
            placeholder="(11) 99999-9999 ou email@empresa.com"
            defaultValue={formData.email}
          />

          <Textarea
            id="modal-dor"
            label="Qual tarefa manual mais consome tempo na sua equipe?"
            rows={3}
            defaultValue={formData.desafio}
            placeholder="Conte-nos brevemente onde está o maior gargalo..."
          />
        </div>
      </Modal>
    </div>
  );
};
