import React, { useState } from 'react';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import {
  X,
  FileCode,
  Download,
  ExternalLink,
  Check,
  Search,
  Globe,
  Share2,
} from 'lucide-react';
import { INSIGHT_ARTICLES } from '../../data/insightsData';
import { SOLUTIONS_DATA } from '../../data/solutionsData';
import { PORTFOLIO_PROJECTS } from '../../data/portfolioData';

interface SitemapModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTo: (url: string) => void;
}

export const SitemapModal: React.FC<SitemapModalProps> = ({
  isOpen,
  onClose,
  onNavigateTo,
}) => {
  const [copied, setCopied] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  const baseUrl = 'https://mavith.com.br';

  const sitemapRoutes = [
    { url: '/', title: 'Página Inicial (Home)', priority: '1.0', changefreq: 'weekly', category: 'Institucional' },
    { url: '/solucoes', title: 'Hub de Soluções & Especialidades', priority: '0.9', changefreq: 'weekly', category: 'Soluções' },
    ...Object.values(SOLUTIONS_DATA).map((s) => ({
      url: `/solucoes/${s.slug}`,
      title: `Solução: ${s.title}`,
      priority: '0.85',
      changefreq: 'monthly',
      category: 'Soluções',
    })),
    { url: '/portfolio', title: 'Portfólio & Casos de Transformação', priority: '0.9', changefreq: 'weekly', category: 'Portfólio' },
    ...PORTFOLIO_PROJECTS.map((p) => ({
      url: `/portfolio/${p.slug}`,
      title: `Case: ${p.title} (${p.segment})`,
      priority: '0.8',
      changefreq: 'monthly',
      category: 'Portfólio',
    })),
    { url: '/insights', title: 'Insights & Artigos Estratégicos', priority: '0.9', changefreq: 'daily', category: 'Conteúdo & Autoridade' },
    ...INSIGHT_ARTICLES.map((a) => ({
      url: `/insights/${a.slug}`,
      title: `Artigo: ${a.title}`,
      priority: '0.8',
      changefreq: 'monthly',
      category: 'Conteúdo & Autoridade',
    })),
    { url: '/demonstracoes', title: 'Demonstrações Interativas (Dashboard, CRM, IA)', priority: '0.85', changefreq: 'weekly', category: 'Demonstrações' },
  ];

  const filteredRoutes = sitemapRoutes.filter(
    (r) =>
      r.url.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const generateXml = () => {
    let xml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
    xml += `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n`;
    sitemapRoutes.forEach((route) => {
      xml += `  <url>\n`;
      xml += `    <loc>${baseUrl}${route.url}</loc>\n`;
      xml += `    <changefreq>${route.changefreq}</changefreq>\n`;
      xml += `    <priority>${route.priority}</priority>\n`;
      xml += `  </url>\n`;
    });
    xml += `</urlset>`;
    return xml;
  };

  const handleDownloadXml = () => {
    const xml = generateXml();
    const blob = new Blob([xml], { type: 'application/xml' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'sitemap.xml';
    link.click();
  };

  const handleCopyXml = () => {
    const xml = generateXml();
    navigator.clipboard.writeText(xml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center text-[#2CBEBF]">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-[#002B58]">
                  Estrutura de URLs & SEO Sitemap
                </h3>
                <Badge variant="teal" size="sm">
                  {sitemapRoutes.length} Rotas Indexáveis
                </Badge>
              </div>
              <p className="text-xs text-slate-500">
                Mapeamento canônico pronto para rastreamento de mecanismos de busca (Google, Bing).
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Toolbar */}
        <div className="p-4 bg-slate-50 border-b border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar rota ou página..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-[#2CBEBF]"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <Button
              variant="secondary"
              size="sm"
              onClick={handleCopyXml}
              leftIcon={copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
            >
              {copied ? 'XML Copiado!' : 'Copiar XML'}
            </Button>
            <Button
              variant="primary-teal"
              size="sm"
              onClick={handleDownloadXml}
              leftIcon={<Download className="w-3.5 h-3.5" />}
            >
              Baixar sitemap.xml
            </Button>
          </div>
        </div>

        {/* Routes List */}
        <div className="flex-1 overflow-y-auto p-4 divide-y divide-slate-100">
          {filteredRoutes.map((route, idx) => (
            <div
              key={idx}
              className="py-3 px-2 hover:bg-slate-50/80 rounded-xl flex items-center justify-between gap-4 group transition-colors"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                    {route.category}
                  </span>
                  <span className="text-xs font-bold text-[#002B58] truncate">
                    {route.title}
                  </span>
                </div>
                <div className="text-xs font-mono text-[#2CBEBF]">
                  {baseUrl}
                  <strong className="text-slate-800">{route.url}</strong>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <div className="text-right text-[10px] font-mono text-slate-400 hidden sm:block">
                  <div>Prioridade: {route.priority}</div>
                  <div>Frequência: {route.changefreq}</div>
                </div>
                <button
                  onClick={() => {
                    onClose();
                    onNavigateTo(route.url);
                  }}
                  className="p-1.5 rounded-lg border border-slate-200 hover:border-[#2CBEBF] hover:bg-teal-50 text-slate-400 hover:text-[#002B58] transition-colors"
                  title="Visitar página"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Footer info */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 text-center text-xs text-slate-500 flex items-center justify-center gap-4">
          <span>Schema: Sitemaps.org 0.9</span>
          <span>•</span>
          <span>OpenGraph & JSON-LD integrados</span>
        </div>
      </div>
    </div>
  );
};
