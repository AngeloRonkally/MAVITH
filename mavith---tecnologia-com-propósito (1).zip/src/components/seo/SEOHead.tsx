import React, { useEffect } from 'react';

export interface SEOHeadProps {
  title?: string;
  description?: string;
  canonicalUrl?: string;
  ogType?: 'website' | 'article';
  publishedTime?: string;
  modifiedTime?: string;
  authorName?: string;
  category?: string;
  jsonLdSchema?: Record<string, any>;
}

export const SEOHead: React.FC<SEOHeadProps> = ({
  title = 'MAVITH - Tecnologia com Propósito',
  description = 'MAVITH — Soluções sob medida em Sites, Sistemas, IA, Automação e Dashboards para empresas em crescimento.',
  canonicalUrl = window.location.href,
  ogType = 'website',
  publishedTime,
  modifiedTime,
  authorName = 'MAVITH Tecnologia',
  category,
  jsonLdSchema,
}) => {
  useEffect(() => {
    // 1. Update Title
    document.title = title;

    // 2. Update Meta Description
    let metaDesc = document.querySelector('meta[name="description"]');
    if (!metaDesc) {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      document.head.appendChild(metaDesc);
    }
    metaDesc.setAttribute('content', description);

    // 3. Update Canonical Tag
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', canonicalUrl);

    // 4. Update OG Tags
    const updateOrCreateMeta = (property: string, content: string) => {
      let el = document.querySelector(`meta[property="${property}"]`);
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute('property', property);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    updateOrCreateMeta('og:title', title);
    updateOrCreateMeta('og:description', description);
    updateOrCreateMeta('og:url', canonicalUrl);
    updateOrCreateMeta('og:type', ogType);

    if (publishedTime) {
      updateOrCreateMeta('article:published_time', publishedTime);
    }
    if (category) {
      updateOrCreateMeta('article:section', category);
    }

    // 5. Inject JSON-LD Structured Data Schema
    const scriptId = 'mavith-structured-data-jsonld';
    let scriptTag = document.getElementById(scriptId) as HTMLScriptElement | null;

    if (!scriptTag) {
      scriptTag = document.createElement('script');
      scriptTag.id = scriptId;
      scriptTag.type = 'application/ld+json';
      document.head.appendChild(scriptTag);
    }

    const defaultSchema = {
      '@context': 'https://schema.org',
      '@graph': [
        {
          '@type': 'Organization',
          '@id': 'https://mavith.com.br/#organization',
          name: 'MAVITH',
          legalName: 'MAVITH Soluções Tecnológicas',
          url: 'https://mavith.com.br',
          logo: 'https://mavith.com.br/logo.png',
          description:
            'Tecnologia com propósito. Transformamos processos, ideias e desafios em soluções digitais inteligentes.',
          contactPoint: {
            '@type': 'ContactPoint',
            telephone: '+55-11-99999-9999',
            contactType: 'customer service',
            areaServed: 'BR',
            availableLanguage: ['Portuguese', 'English'],
          },
          sameAs: [
            'https://linkedin.com/company/mavith',
            'https://instagram.com/mavith.tech',
            'https://github.com/mavith',
          ],
        },
        jsonLdSchema,
      ].filter(Boolean),
    };

    scriptTag.textContent = JSON.stringify(defaultSchema);
  }, [title, description, canonicalUrl, ogType, publishedTime, modifiedTime, authorName, category, jsonLdSchema]);

  return null;
};
