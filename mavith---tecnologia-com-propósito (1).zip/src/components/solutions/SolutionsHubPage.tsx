import React from 'react';
import { SOLUTIONS_LIST } from '../../data/solutionsData';
import { SolutionSlug } from '../../types/solutions';
import { Container } from '../../design-system/components/Container';
import { SectionTitle } from '../../design-system/components/Section';
import { Card } from '../../design-system/components/Card';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import {
  Globe,
  Layers,
  Sparkles,
  Zap,
  BarChart3,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Clock,
  ShieldCheck,
  Building2,
  TrendingUp,
  Cpu,
} from 'lucide-react';

interface SolutionsHubPageProps {
  onSelectSolution: (slug: SolutionSlug) => void;
  onOpenContactModal: (interest?: string) => void;
}

export const SolutionsHubPage: React.FC<SolutionsHubPageProps> = ({
  onSelectSolution,
  onOpenContactModal,
}) => {
  const getIcon = (slug: SolutionSlug) => {
    switch (slug) {
      case 'sites':
        return <Globe className="w-6 h-6 text-[#002B58]" />;
      case 'sistemas':
        return <Layers className="w-6 h-6 text-[#2CBEBF]" />;
      case 'ia':
        return <Sparkles className="w-6 h-6 text-[#FE7001]" />;
      case 'automacao':
        return <Zap className="w-6 h-6 text-[#FE7001]" />;
      case 'dashboards':
        return <BarChart3 className="w-6 h-6 text-[#002B58]" />;
      default:
        return <Cpu className="w-6 h-6 text-[#002B58]" />;
    }
  };

  const getAccentBadge = (accent: 'blue' | 'turquoise' | 'orange') => {
    switch (accent) {
      case 'turquoise':
        return 'turquoise' as const;
      case 'orange':
        return 'orange' as const;
      case 'blue':
      default:
        return 'blue' as const;
    }
  };

  return (
    <div className="bg-white min-h-screen py-10">
      {/* 1. Hero & Philosophy */}
      <Container size="xl">
        <div className="text-center max-w-3xl mx-auto pb-12 border-b border-slate-200">
          <Badge variant="blue" size="md" className="mb-3">
            Soluções Sob Medida MAVITH
          </Badge>

          <h1
            className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#002B58] tracking-tight leading-tight"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Tecnologia que resolve problemas concretos da sua operação.
          </h1>

          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Não vendemos ferramentas prontas e engessadas. Construímos a solução exata que o seu negócio precisa para crescer com previsibilidade, organização e menos esforço manual.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button
              variant="primary-orange"
              size="md"
              onClick={() => onOpenContactModal('diagnostico-solucoes')}
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Agendar Diagnóstico Gratuito
            </Button>
            <Button
              variant="secondary"
              size="md"
              onClick={() => {
                const el = document.getElementById('catalogo-solucoes');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Conhecer as 5 frentes
            </Button>
          </div>
        </div>

        {/* 2. Core Pillars Grid */}
        <section id="catalogo-solucoes" className="py-16 border-b border-slate-200">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-mono font-bold text-[#FE7001] uppercase tracking-wider block mb-1">
              Frentes de Atuação
            </span>
            <h2
              className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              As 5 Soluções Estratégicas
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-600">
              Escolha a área onde sua empresa mais sente gargalos operacionais hoje.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SOLUTIONS_LIST.map((sol) => (
              <Card
                key={sol.id}
                variant="outline"
                padding="none"
                className="bg-white hover:border-[#2CBEBF]/60 transition-all duration-300 flex flex-col justify-between overflow-hidden group shadow-xs hover:shadow-lg"
              >
                {/* Header with Icon and Pillar */}
                <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 shadow-2xs flex items-center justify-center group-hover:scale-105 transition-transform">
                      {getIcon(sol.slug)}
                    </div>
                    <div>
                      <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400 block">
                        Pilar {sol.pillarNumber}
                      </span>
                      <h3 className="text-lg font-bold text-[#002B58]">
                        {sol.title}
                      </h3>
                    </div>
                  </div>
                  <Badge variant={getAccentBadge(sol.accent)} size="sm">
                    {sol.badge}
                  </Badge>
                </div>

                {/* Body Content */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    {/* The signature prompt message */}
                    <p className="text-sm font-extrabold text-[#002B58] italic border-l-2 border-[#FE7001] pl-3 py-0.5">
                      "{sol.headline}"
                    </p>

                    <p className="mt-3 text-xs sm:text-sm text-slate-600 leading-relaxed">
                      {sol.tagline}
                    </p>

                    {/* What can be built pills */}
                    <div className="mt-4 pt-4 border-t border-slate-100">
                      <span className="text-[11px] font-bold text-slate-500 uppercase block mb-2">
                        O que construímos nesta frente:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {sol.offerings.map((item) => (
                          <span
                            key={item.title}
                            className="text-[11px] font-medium text-slate-700 bg-slate-100 px-2.5 py-1 rounded-md"
                          >
                            {item.title}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Button Action */}
                  <div className="pt-4 border-t border-slate-100">
                    <Button
                      variant="secondary"
                      size="sm"
                      className="w-full justify-between group-hover:border-[#002B58]"
                      onClick={() => onSelectSolution(sol.slug)}
                      rightIcon={<ArrowRight className="w-4 h-4 text-[#FE7001] group-hover:translate-x-0.5 transition-transform" />}
                    >
                      Explorar Solução Completa
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* 3. Guia de Diagnóstico Rápido: Qual solução sua empresa precisa? */}
        <section className="py-16 border-b border-slate-200">
          <div className="p-8 sm:p-12 rounded-3xl bg-slate-50 border border-slate-200 shadow-xs">
            <div className="max-w-2xl mb-8">
              <span className="text-xs font-mono font-bold text-[#2CBEBF] uppercase tracking-wider block mb-1">
                Matriz de Orientação
              </span>
              <h2
                className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
              >
                Qual é a dor mais urgente no seu negócio hoje?
              </h2>
              <p className="mt-2 text-xs sm:text-sm text-slate-600">
                Se você não tem certeza por onde começar, localize a situação que melhor descreve o momento da sua empresa:
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div
                onClick={() => onSelectSolution('sites')}
                className="p-5 rounded-xl bg-white border border-slate-200 hover:border-[#002B58] transition-all cursor-pointer shadow-2xs hover:shadow-sm"
              >
                <div className="flex items-center gap-2 mb-2 text-[#002B58] font-bold text-sm">
                  <Globe className="w-4 h-4 text-[#FE7001]" />
                  <span>"Nossa imagem não passa credibilidade"</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed mb-3">
                  Clientes duvidam da capacidade da sua empresa ou seu site atual é antigo, feio e não gera contatos comerciais.
                </p>
                <span className="text-[11px] font-bold text-[#002B58] flex items-center gap-1">
                  Solução recomendada: Sites & Plataformas <ArrowRight className="w-3 h-3 text-[#FE7001]" />
                </span>
              </div>

              <div
                onClick={() => onSelectSolution('sistemas')}
                className="p-5 rounded-xl bg-white border border-slate-200 hover:border-[#002B58] transition-all cursor-pointer shadow-2xs hover:shadow-sm"
              >
                <div className="flex items-center gap-2 mb-2 text-[#002B58] font-bold text-sm">
                  <Layers className="w-4 h-4 text-[#2CBEBF]" />
                  <span>"Estamos afundados em planilhas"</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed mb-3">
                  Processos críticos dependem de cadernos, arquivos Excel com fórmulas quebradas ou softwares caros que ninguém usa.
                </p>
                <span className="text-[11px] font-bold text-[#002B58] flex items-center gap-1">
                  Solução recomendada: Sistemas Sob Medida <ArrowRight className="w-3 h-3 text-[#FE7001]" />
                </span>
              </div>

              <div
                onClick={() => onSelectSolution('ia')}
                className="p-5 rounded-xl bg-white border border-slate-200 hover:border-[#002B58] transition-all cursor-pointer shadow-2xs hover:shadow-sm"
              >
                <div className="flex items-center gap-2 mb-2 text-[#002B58] font-bold text-sm">
                  <Sparkles className="w-4 h-4 text-[#FE7001]" />
                  <span>"Equipe sobrecarregada com dúvidas repetitivas"</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed mb-3">
                  Profissionais seniores gastando horas lendo documentos, atendendo dúvidas triviais ou pesquisando regras em manuais.
                </p>
                <span className="text-[11px] font-bold text-[#002B58] flex items-center gap-1">
                  Solução recomendada: Inteligência Artificial <ArrowRight className="w-3 h-3 text-[#FE7001]" />
                </span>
              </div>

              <div
                onClick={() => onSelectSolution('automacao')}
                className="p-5 rounded-xl bg-white border border-slate-200 hover:border-[#002B58] transition-all cursor-pointer shadow-2xs hover:shadow-sm"
              >
                <div className="flex items-center gap-2 mb-2 text-[#002B58] font-bold text-sm">
                  <Zap className="w-4 h-4 text-[#FE7001]" />
                  <span>"Copiamos dados de uma tela para outra"</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed mb-3">
                  Esquecimento de avisos de clientes, digitação duplicada de dados entre financeiro e comercial e atrasos manuais.
                </p>
                <span className="text-[11px] font-bold text-[#002B58] flex items-center gap-1">
                  Solução recomendada: Automações <ArrowRight className="w-3 h-3 text-[#FE7001]" />
                </span>
              </div>

              <div
                onClick={() => onSelectSolution('dashboards')}
                className="p-5 rounded-xl bg-white border border-slate-200 hover:border-[#002B58] transition-all cursor-pointer shadow-2xs hover:shadow-sm"
              >
                <div className="flex items-center gap-2 mb-2 text-[#002B58] font-bold text-sm">
                  <BarChart3 className="w-4 h-4 text-[#002B58]" />
                  <span>"Não sabemos os números em tempo real"</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed mb-3">
                  Relatórios demoram semanas para fechar, números de setores divergem e a diretoria decide no escuro ou no feeling.
                </p>
                <span className="text-[11px] font-bold text-[#002B58] flex items-center gap-1">
                  Solução recomendada: Dashboards & BI <ArrowRight className="w-3 h-3 text-[#FE7001]" />
                </span>
              </div>

              <div
                onClick={() => onOpenContactModal('diagnostico-integrado')}
                className="p-5 rounded-xl bg-gradient-to-br from-[#002B58] to-[#001C3B] text-white transition-all cursor-pointer shadow-sm hover:shadow-md flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-2 mb-2 text-white font-bold text-sm">
                    <Sparkles className="w-4 h-4 text-[#2CBEBF]" />
                    <span>"Preciso de uma combinação de soluções"</span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed mb-3">
                    Muitas vezes a transformação ideal envolve conectar um site institucional a um CRM e um dashboard gerencial.
                  </p>
                </div>
                <span className="text-[11px] font-bold text-[#2CBEBF] flex items-center gap-1">
                  Conversar com especialista <ArrowRight className="w-3 h-3 text-[#FE7001]" />
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* 4. Mandatory CTA Section:
            "Tem esse problema na sua empresa?"
            "Vamos encontrar uma solução."
        */}
        <section className="py-16">
          <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-[#002B58] via-[#002447] to-[#001C3B] text-white text-center max-w-3xl mx-auto shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#2CBEBF]/15 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#FE7001]/15 rounded-full blur-2xl pointer-events-none" />

            <div className="relative z-10">
              <Badge variant="orange" size="md" className="mb-4">
                Próximo Passo
              </Badge>

              <h2
                className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white leading-tight"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
              >
                Tem esse problema na sua empresa?
              </h2>

              <p className="mt-3 text-lg sm:text-xl text-[#2CBEBF] font-semibold">
                Vamos encontrar uma solução.
              </p>

              <p className="mt-4 text-xs sm:text-sm text-slate-200 max-w-xl mx-auto leading-relaxed">
                Agende uma conversa de 30 minutos com nossos arquitetos de software. Analisamos seus fluxos atuais sem custo e apresentamos uma proposta transparente.
              </p>

              <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
                <Button
                  variant="primary-orange"
                  size="md"
                  onClick={() => onOpenContactModal('diagnostico-solucoes')}
                  rightIcon={<ArrowRight className="w-4 h-4" />}
                  className="font-bold shadow-md"
                >
                  Fale com a MAVITH
                </Button>
              </div>
            </div>
          </div>
        </section>
      </Container>
    </div>
  );
};
