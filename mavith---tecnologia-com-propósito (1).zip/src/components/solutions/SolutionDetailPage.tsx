import React, { useState } from 'react';
import { SolutionData, SolutionSlug } from '../../types/solutions';
import { Container } from '../../design-system/components/Container';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import { Card } from '../../design-system/components/Card';
import { getProjectBySlug } from '../../data/portfolioData';
import { MockupRenderer } from '../portfolio/MockupRenderer';
import {
  ArrowLeft,
  ArrowRight,
  AlertTriangle,
  Users2,
  CheckCircle2,
  Layers,
  Sparkles,
  TrendingUp,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Send,
  Building2,
  Check,
  Zap,
  Globe,
  BarChart3,
  ExternalLink,
} from 'lucide-react';

interface SolutionDetailPageProps {
  solution: SolutionData;
  onBackToSolutions: () => void;
  onSelectAnotherSolution: (slug: SolutionSlug) => void;
  onSelectProject: (slug: string) => void;
  onOpenContactModal: (interest?: string) => void;
}

export const SolutionDetailPage: React.FC<SolutionDetailPageProps> = ({
  solution,
  onBackToSolutions,
  onSelectAnotherSolution,
  onSelectProject,
  onOpenContactModal,
}) => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  const getSolutionIcon = (slug: SolutionSlug) => {
    switch (slug) {
      case 'sites':
        return <Globe className="w-5 h-5 text-[#002B58]" />;
      case 'sistemas':
        return <Layers className="w-5 h-5 text-[#2CBEBF]" />;
      case 'ia':
        return <Sparkles className="w-5 h-5 text-[#FE7001]" />;
      case 'automacao':
        return <Zap className="w-5 h-5 text-[#FE7001]" />;
      case 'dashboards':
        return <BarChart3 className="w-5 h-5 text-[#002B58]" />;
    }
  };

  const otherSolutions: { slug: SolutionSlug; label: string }[] = [
    { slug: 'sites', label: 'Sites' },
    { slug: 'sistemas', label: 'Sistemas' },
    { slug: 'ia', label: 'Inteligência Artificial' },
    { slug: 'automacao', label: 'Automação' },
    { slug: 'dashboards', label: 'Dashboards' },
  ];

  // Retrieve related project data if available
  const relatedProjects = solution.relatedCaseSlugs
    .map((slug) => getProjectBySlug(slug))
    .filter(Boolean);

  return (
    <div className="bg-white min-h-screen py-8">
      {/* 1. Breadcrumb & Quick Switcher */}
      <div className="border-b border-slate-200 pb-4 mb-8 bg-slate-50/70">
        <Container size="xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <button
              type="button"
              onClick={onBackToSolutions}
              className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#002B58] hover:text-[#FE7001] transition-colors cursor-pointer py-1"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar ao Hub de Soluções</span>
            </button>

            {/* Quick solution navigator pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
              <span className="text-[11px] font-mono text-slate-400 mr-1 hidden md:inline">
                Ver outras:
              </span>
              {otherSolutions.map((item) => (
                <button
                  key={item.slug}
                  type="button"
                  onClick={() => onSelectAnotherSolution(item.slug)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                    solution.slug === item.slug
                      ? 'bg-[#002B58] text-white'
                      : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </Container>
      </div>

      <Container size="xl">
        {/* =========================================================
            1. HERO SECTION
            - Strong value message
            - Persona & Context
        ========================================================= */}
        <section className="pb-14 border-b border-slate-200">
          <div className="max-w-4xl">
            <div className="flex flex-wrap items-center gap-2 mb-4">
              <span className="text-xs font-mono font-bold text-[#FE7001] uppercase tracking-wider">
                Pilar {solution.pillarNumber} • {solution.badge}
              </span>
              <span className="text-xs text-slate-400">/</span>
              <span className="text-xs font-mono font-semibold text-[#002B58]">
                /solucoes/{solution.slug}
              </span>
            </div>

            <h1
              className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#002B58] tracking-tight leading-tight"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              {solution.headline}
            </h1>

            <p className="mt-5 text-base sm:text-lg text-slate-600 leading-relaxed font-medium">
              {solution.tagline}
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <Button
                variant="primary-orange"
                size="md"
                onClick={() => onOpenContactModal(solution.title)}
                rightIcon={<ArrowRight className="w-4 h-4" />}
              >
                Quero essa solução na minha empresa
              </Button>
              <Button
                variant="secondary"
                size="md"
                onClick={() => {
                  const el = document.getElementById('secao-problema');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Entender como resolvemos
              </Button>
            </div>
          </div>
        </section>

        {/* =========================================================
            2. PROBLEMA: "Qual problema isso resolve?"
            - Real business pain
            - 4 Symptoms/consequences
        ========================================================= */}
        <section id="secao-problema" className="py-14 border-b border-slate-200">
          <div className="max-w-3xl mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-900 text-xs font-bold mb-3">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              <span>O Diagnóstico Inicial</span>
            </div>

            <h2
              className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              {solution.problemHeadline}
            </h2>

            <p className="mt-3 text-sm sm:text-base text-slate-600 leading-relaxed">
              {solution.problemDescription}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {solution.symptoms.map((symptom, idx) => (
              <div
                key={symptom.title}
                className="p-6 rounded-2xl bg-amber-50/40 border border-amber-200/70 shadow-2xs"
              >
                <div className="flex items-start gap-3">
                  <div className="w-7 h-7 rounded-lg bg-amber-500 text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                    !
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-[#002B58]">
                      {symptom.title}
                    </h3>
                    <p className="mt-1 text-xs sm:text-sm text-slate-600 leading-relaxed">
                      {symptom.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* =========================================================
            3. COMO PODEMOS AJUDAR: "Para quem serve?"
            - Target segments
            - Strategic philosophy
        ========================================================= */}
        <section className="py-14 border-b border-slate-200">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-5 space-y-4">
              <Badge variant="blue" size="sm">
                Aderência & Perfil
              </Badge>
              <h2
                className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
              >
                Para quem esta solução foi projetada?
              </h2>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                Nossas entregas são pensadas para negócios em crescimento que já ultrapassaram o estágio inicial e não podem mais perder tempo com processos manuais ou improvisados.
              </p>

              <div className="p-5 rounded-2xl bg-[#EBF6FC] border border-[#002B58]/20 text-[#002B58] text-xs sm:text-sm leading-relaxed">
                <span className="font-bold block text-xs uppercase tracking-wider text-[#FE7001] mb-1 font-mono">
                  Princípio MAVITH
                </span>
                {solution.approachPhilosophy}
              </div>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {solution.targetAudience.map((target) => (
                <div
                  key={target.segment}
                  className="p-5 rounded-xl bg-white border border-slate-200 shadow-2xs hover:border-[#2CBEBF]/60 transition-colors"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle2 className="w-4 h-4 text-[#2CBEBF] shrink-0" />
                    <h3 className="text-sm font-bold text-[#002B58]">
                      {target.segment}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {target.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* =========================================================
            4. SOLUÇÕES: "O que pode ser construído?"
            - Concrete offerings
            - Deliverables & suitability
        ========================================================= */}
        <section className="py-14 border-b border-slate-200">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <Badge variant="orange" size="sm" className="mb-2">
              Arquitetura sob Demanda
            </Badge>
            <h2
              className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              O Que Podemos Construir Para a Sua Empresa
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-600">
              Formatos flexíveis adaptados ao tamanho e à urgência operacional do seu negócio.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {solution.offerings.map((item, idx) => (
              <Card
                key={item.title}
                variant="outline"
                padding="md"
                className="bg-white hover:border-[#2CBEBF]/60 transition-all shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-xs font-mono font-bold text-[#FE7001]">
                      Módulo 0{idx + 1}
                    </span>
                    <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                      Sob Medida
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-[#002B58]">
                    {item.title}
                  </h3>

                  <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed">
                    {item.description}
                  </p>

                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <span className="text-[11px] font-bold text-slate-400 uppercase block mb-2">
                      O que está incluído:
                    </span>
                    <ul className="space-y-1.5">
                      {item.deliverables.map((del) => (
                        <li
                          key={del}
                          className="flex items-center gap-2 text-xs text-slate-700"
                        >
                          <Check className="w-3.5 h-3.5 text-[#2CBEBF] shrink-0" />
                          <span>{del}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 bg-slate-50/70 p-3 rounded-lg text-[11px] text-slate-600">
                  <span className="font-bold text-[#002B58]">Ideal para:</span> {item.idealFor}
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* =========================================================
            5. EXEMPLOS PRÁTICOS: Antes x Depois
            - Practical real-world transformations
        ========================================================= */}
        <section className="py-14 border-b border-slate-200">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-mono font-bold text-[#2CBEBF] uppercase tracking-wider block mb-1">
              Casos Práticos
            </span>
            <h2
              className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Como a Transformação Acontece na Prática
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-600">
              Veja a diferença entre a rotina anterior e o novo patamar após a implementação da solução.
            </p>
          </div>

          <div className="space-y-8 max-w-4xl mx-auto">
            {solution.examples.map((ex, i) => (
              <div
                key={ex.scenario}
                className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 shadow-xs"
              >
                <div className="flex items-center gap-2 mb-4">
                  <span className="w-6 h-6 rounded-full bg-[#002B58] text-white flex items-center justify-center text-xs font-bold font-mono">
                    {i + 1}
                  </span>
                  <h3 className="text-base sm:text-lg font-bold text-[#002B58]">
                    Cenário: {ex.scenario}
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-amber-50/60 border border-amber-200/70">
                    <span className="text-[10px] font-mono font-bold uppercase text-amber-800 block mb-1">
                      Antes da MAVITH
                    </span>
                    <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                      {ex.before}
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200/70">
                    <span className="text-[10px] font-mono font-bold uppercase text-emerald-800 block mb-1">
                      Depois da MAVITH
                    </span>
                    <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                      {ex.after}
                    </p>
                  </div>
                </div>

                <div className="mt-4 p-3 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                  <span className="font-bold text-[#002B58]">Impacto Concreto:</span>
                  <span className="text-emerald-700 font-semibold">{ex.impact}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* =========================================================
            6. BENEFÍCIOS TANGÍVEIS: "Qual benefício?"
        ========================================================= */}
        <section className="py-14 border-b border-slate-200">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <h2
              className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Benefícios Que Vão Direto Para o Resultado
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-600">
              Menos desperdício de tempo da equipe, mais previsibilidade e processos blindados contra falhas.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {solution.benefits.map((ben) => (
              <div
                key={ben.title}
                className="p-6 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-[#002B58] transition-colors flex flex-col justify-between"
              >
                <div>
                  {ben.metricHighlight && (
                    <span className="text-xs font-mono font-bold text-[#FE7001] bg-orange-50 border border-orange-200/60 px-2.5 py-0.5 rounded-full inline-block mb-3">
                      {ben.metricHighlight}
                    </span>
                  )}
                  <h3 className="text-base font-bold text-[#002B58]">
                    {ben.title}
                  </h3>
                  <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed">
                    {ben.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* =========================================================
            7. PROCESSO: "Como funciona? / Como começar?"
        ========================================================= */}
        <section className="py-14 border-b border-slate-200">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <Badge variant="blue" size="sm" className="mb-2">
              Passo a Passo
            </Badge>
            <h2
              className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Como Funciona a Nossa Entrega
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-600">
              Processo estruturado e previsível, do alinhamento inicial ao suporte pós-lançamento.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 max-w-5xl mx-auto">
            {solution.processSteps.map((step) => (
              <div
                key={step.step}
                className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between"
              >
                <div>
                  <span className="text-lg font-mono font-extrabold text-[#FE7001] block mb-2">
                    {step.step}
                  </span>
                  <h3 className="text-sm font-bold text-[#002B58] mb-2 leading-snug">
                    {step.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* =========================================================
            8. CASES RELACIONADOS
            - Seamless integration with Phase 3 portfolio
        ========================================================= */}
        {relatedProjects.length > 0 && (
          <section className="py-14 border-b border-slate-200">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
              <div>
                <span className="text-xs font-mono font-bold text-[#2CBEBF] uppercase tracking-wider block mb-1">
                  Estudo de Caso Prático
                </span>
                <h2
                  className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
                  style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                >
                  Veja Essa Solução em Ação
                </h2>
              </div>

              <button
                type="button"
                onClick={() => {
                  window.location.hash = '#/portfolio';
                }}
                className="text-xs font-bold text-[#002B58] hover:text-[#FE7001] inline-flex items-center gap-1 cursor-pointer"
              >
                <span>Ver todos os cases</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl">
              {relatedProjects.map((proj) => {
                if (!proj) return null;
                return (
                  <Card
                    key={proj.id}
                    variant="outline"
                    padding="none"
                    className="bg-white hover:border-[#2CBEBF]/60 transition-all duration-300 flex flex-col justify-between overflow-hidden group shadow-xs hover:shadow-md"
                  >
                    <div className="p-4 bg-slate-900 border-b border-slate-200">
                      <MockupRenderer
                        device={proj.mockupData.device}
                        screenType={proj.mockupData.screenType}
                        isDemo={false}
                        className="max-h-[180px] overflow-hidden"
                      />
                    </div>

                    <div className="p-5 flex-1 flex flex-col justify-between">
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                          {proj.segment}
                        </span>
                        <h3 className="text-base font-bold text-[#002B58] group-hover:text-[#2CBEBF] transition-colors">
                          {proj.title}
                        </h3>
                        <p className="mt-2 text-xs text-slate-600 line-clamp-2 leading-relaxed">
                          {proj.description}
                        </p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-700">
                          {proj.results[0]?.metric || 'Impacto Validado'}
                        </span>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => onSelectProject(proj.slug)}
                          rightIcon={<ArrowRight className="w-3.5 h-3.5 text-[#FE7001]" />}
                        >
                          Ver Estudo Completo
                        </Button>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </section>
        )}

        {/* =========================================================
            9. FAQ: Dúvidas Frequentes
            - Clarifying common doubts of managers & decision makers
        ========================================================= */}
        <section className="py-14 border-b border-slate-200">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-mono font-bold text-[#FE7001] uppercase tracking-wider block mb-1">
              Esclarecimentos
            </span>
            <h2
              className="text-2xl sm:text-3xl font-extrabold text-[#002B58]"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Perguntas Frequentes
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-600">
              Respostas diretas e transparentes para as dúvidas mais comuns antes de iniciar.
            </p>
          </div>

          <div className="max-w-3xl mx-auto space-y-3">
            {solution.faqs.map((faq, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div
                  key={faq.question}
                  className="rounded-xl border border-slate-200 bg-white overflow-hidden transition-all shadow-2xs"
                >
                  <button
                    type="button"
                    onClick={() => toggleFaq(index)}
                    className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-50 transition-colors"
                  >
                    <span className="text-sm sm:text-base font-bold text-[#002B58]">
                      {faq.question}
                    </span>
                    <span className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center shrink-0 text-slate-500">
                      {isOpen ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="px-4 sm:px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/40">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* =========================================================
            10. MANDATORY CTA:
            "Tem esse problema na sua empresa?"
            "Vamos encontrar uma solução."
        ========================================================= */}
        <section className="py-16">
          <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-[#002B58] via-[#002447] to-[#001C3B] text-white text-center max-w-3xl mx-auto shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#2CBEBF]/15 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#FE7001]/15 rounded-full blur-2xl pointer-events-none" />

            <div className="relative z-10">
              <Badge variant="orange" size="md" className="mb-4">
                Próximo Passo
              </Badge>

              <h2
                className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white leading-tight"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
              >
                Tem esse problema na sua empresa?
              </h2>

              <p className="mt-3 text-lg sm:text-xl text-[#2CBEBF] font-semibold">
                Vamos encontrar uma solução.
              </p>

              <p className="mt-4 text-xs sm:text-sm text-slate-200 max-w-xl mx-auto leading-relaxed">
                Podemos analisar seu cenário atual sem compromisso, apontar o caminho técnico ideal e planejar uma entrega que realmente faça sentido para a sua rotina.
              </p>

              <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
                <Button
                  variant="primary-orange"
                  size="md"
                  onClick={() => onOpenContactModal(solution.title)}
                  rightIcon={<Send className="w-4 h-4" />}
                  className="font-bold shadow-md"
                >
                  Fale com a MAVITH
                </Button>

                <Button
                  variant="secondary"
                  size="md"
                  onClick={onBackToSolutions}
                >
                  Conhecer outras soluções
                </Button>
              </div>
            </div>
          </div>
        </section>
      </Container>
    </div>
  );
};
