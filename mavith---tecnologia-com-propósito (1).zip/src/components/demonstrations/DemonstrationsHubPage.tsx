import React, { useState } from 'react';
import { Container } from '../../design-system/components/Container';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import { Card } from '../../design-system/components/Card';
import {
  LayoutDashboard,
  Users,
  Cpu,
  Bot,
  GitMerge,
  ArrowRight,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertTriangle,
  Send,
  Play,
  RotateCcw,
  Sparkles,
  ChevronRight,
  Search,
  Filter,
  DollarSign,
  Activity,
  FileCheck2,
  Calendar,
  Layers,
  MessageSquare,
  ShieldAlert,
} from 'lucide-react';

type DemoTab = 'dashboard' | 'crm' | 'sistema' | 'ia' | 'automacao';

interface DemonstrationsHubPageProps {
  onBackToHome?: () => void;
  onOpenContactModal?: (interest?: string) => void;
  initialTab?: DemoTab;
}

export const DemonstrationsHubPage: React.FC<DemonstrationsHubPageProps> = ({
  onBackToHome,
  onOpenContactModal,
  initialTab = 'dashboard',
}) => {
  const [activeTab, setActiveTab] = useState<DemoTab>(initialTab);

  // 1. Dashboard State
  const [period, setPeriod] = useState<'hoje' | 'semana' | 'mes'>('mes');

  // 2. CRM State
  const [crmStageFilter, setCrmStageFilter] = useState<string>('all');
  const [crmDeals, setCrmDeals] = useState([
    {
      id: 'deal-1',
      client: 'Indústria MetalSul',
      stage: 'proposta',
      value: 'R$ 48.000',
      service: 'Sistema de O.S. & Estoque',
      contact: 'Roberto Silveira (Diretor)',
      days: 2,
    },
    {
      id: 'deal-2',
      client: 'LogFácil Distribuição',
      stage: 'qualificacao',
      value: 'R$ 28.500',
      service: 'Automação de Rastreio WhatsApp',
      contact: 'Marina Duarte (Operações)',
      days: 1,
    },
    {
      id: 'deal-3',
      client: 'Clínica BellaVita',
      stage: 'fechado',
      value: 'R$ 19.800',
      service: 'Agente de IA para Agendamentos',
      contact: 'Dra. Fernanda Lemos',
      days: 5,
    },
    {
      id: 'deal-4',
      client: 'Vanguard Engenharia',
      stage: 'lead',
      value: 'R$ 62.000',
      service: 'Dashboard Executivo & BI Central',
      contact: 'Carlos Menezes',
      days: 0,
    },
  ]);

  // 3. Sistema / O.S. State
  const [osSearch, setOsSearch] = useState('');
  const [osStatusFilter, setOsStatusFilter] = useState<'all' | 'execucao' | 'aprovado' | 'concluido'>('all');
  const osList = [
    {
      id: 'OS-2025-084',
      cliente: 'Construtora Horizonte',
      tipo: 'Calibração de Sensores Industriais',
      status: 'execucao',
      statusLabel: 'Em Execução',
      tecnico: 'Felipe Rocha',
      prazo: 'Hoje, 17:30',
      prioridade: 'Alta',
    },
    {
      id: 'OS-2025-083',
      cliente: 'Hospital São Lucas',
      tipo: 'Manutenção Preventiva de No-Breaks',
      status: 'aprovado',
      statusLabel: 'Aguardando Início',
      tecnico: 'Diego Albuquerque',
      prazo: 'Amanhã, 10:00',
      prioridade: 'Média',
    },
    {
      id: 'OS-2025-082',
      cliente: 'Supermercados União',
      tipo: 'Integração de PDV com SEFAZ',
      status: 'concluido',
      statusLabel: 'Concluído com Sucesso',
      tecnico: 'Camila Santos',
      prazo: 'Ontem',
      prioridade: 'Alta',
    },
    {
      id: 'OS-2025-081',
      cliente: 'Agropecuária Vale Verde',
      tipo: 'Instalação de Telemetria de Silos',
      status: 'execucao',
      statusLabel: 'Em Execução',
      tecnico: 'Felipe Rocha',
      prazo: '14/03/2025',
      prioridade: 'Baixa',
    },
  ];

  // 4. Agente IA State
  const [chatMessages, setChatMessages] = useState<
    { sender: 'user' | 'bot'; text: string; time: string }[]
  >([
    {
      sender: 'bot',
      text: 'Olá! Sou o assistente inteligente da MAVITH. Como posso ajudar sua empresa hoje? Você pode testar clicando nos atalhos abaixo ou digitando sua dúvida.',
      time: '14:30',
    },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || chatInput;
    if (!text.trim()) return;

    const userTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setChatMessages((prev) => [...prev, { sender: 'user', text, time: userTime }]);
    if (!textToSend) setChatInput('');
    setIsTyping(true);

    setTimeout(() => {
      let reply =
        'Entendido! Analisei sua solicitação com base nas diretrizes operacionais. Nossas soluções sob medida conectam sistemas e reduzem tarefas repetitivas. Deseja agendar um diagnóstico gratuito de 30 minutos com nossa equipe?';

      const lower = text.toLowerCase();
      if (lower.includes('planilha') || lower.includes('excel')) {
        reply =
          'Excelente pergunta. Muitas empresas chegam até nós porque o Excel começou a travar ou gerar divergência entre setores. Substituímos planilhas por sistemas web seguros com perfis de permissão e integração direta aos seus bancos de dados.';
      } else if (lower.includes('prazo') || lower.includes('tempo')) {
        reply =
          'Trabalhamos com metodologia ágil incremental: entregamos o núcleo funcional do sistema (MVP validado) geralmente entre 3 e 6 semanas, para que sua empresa comece a colher retorno antes da entrega final.';
      } else if (lower.includes('whatsapp') || lower.includes('atendimento')) {
        reply =
          'Nossos agentes de IA para WhatsApp entendem áudio, texto e documentos. Eles realizam a triagem inicial, respondem dúvidas frequentes e só transferem o lead para um atendente humano quando a oportunidade está qualificada.';
      } else if (lower.includes('valor') || lower.includes('preço') || lower.includes('custo')) {
        reply =
          'Como cada projeto é sob medida para o seu processo, o investimento varia conforme a complexidade. Não cobramos mensalidades abusivas por usuário: o sistema é de propriedade da sua empresa!';
      }

      const botTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setChatMessages((prev) => [...prev, { sender: 'bot', text: reply, time: botTime }]);
      setIsTyping(false);
    }, 900);
  };

  // 5. Automação State
  const [automationRunning, setAutomationRunning] = useState(false);
  const [automationStep, setAutomationStep] = useState(0);
  const [automationLogs, setAutomationLogs] = useState<string[]>([]);

  const handleRunAutomation = () => {
    if (automationRunning) return;
    setAutomationRunning(true);
    setAutomationStep(1);
    setAutomationLogs([
      `[${new Date().toLocaleTimeString()}] 🟢 Trigger acionado: Novo lead via formulário institucional (Lead #9182 - "Engenharia Atlas").`,
    ]);

    setTimeout(() => {
      setAutomationStep(2);
      setAutomationLogs((prev) => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] 🔍 Validação na Receita Federal: CNPJ 38.412.991/0001-20 ativo e regularizado.`,
      ]);
    }, 1200);

    setTimeout(() => {
      setAutomationStep(3);
      setAutomationLogs((prev) => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] 📊 Oportunidade inserida no CRM na etapa "Qualificação" (Prioridade: Alta).`,
      ]);
    }, 2400);

    setTimeout(() => {
      setAutomationStep(4);
      setAutomationLogs((prev) => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] 📱 Alerta disparado via WhatsApp para o executivo de contas responsável.`,
        `[${new Date().toLocaleTimeString()}] ✉️ E-mail de confirmação e apresentação enviado para o cliente.`,
        `[${new Date().toLocaleTimeString()}] ✅ Fluxo concluído com sucesso em 1.4s (Zero intervenção manual).`,
      ]);
      setAutomationRunning(false);
    }, 3600);
  };

  return (
    <div className="py-12 bg-slate-50 min-h-screen">
      <Container size="xl">
        {/* Top Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <Badge variant="teal" size="md" className="mb-3">
            Ambiente de Demonstração Interativo
          </Badge>
          <h1
            className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#002B58] tracking-tight leading-tight"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Tecnologia em ação com dados reais de teste.
          </h1>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Experimente como as soluções MAVITH organizam rotinas, automatizam processos e empoderam decisões antes de iniciar o seu projeto.
          </p>
        </div>

        {/* Tabs Bar */}
        <div className="flex flex-wrap items-center justify-center gap-2 p-1.5 bg-white border border-slate-200 rounded-2xl shadow-xs max-w-4xl mx-auto mb-10">
          {[
            { id: 'dashboard', label: 'Dashboard & BI', icon: LayoutDashboard },
            { id: 'crm', label: 'CRM & Pipeline', icon: Users },
            { id: 'sistema', label: 'Sistema & O.S.', icon: Cpu },
            { id: 'ia', label: 'Agente de IA', icon: Bot },
            { id: 'automacao', label: 'Fluxo de Automação', icon: GitMerge },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as DemoTab)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 ${
                  isActive
                    ? 'bg-[#002B58] text-white shadow-xs'
                    : 'text-slate-600 hover:text-[#002B58] hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#2CBEBF]' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Active Demo Canvas */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 lg:p-10 shadow-sm relative">
          {/* DEMO 1: DASHBOARD & BI */}
          {activeTab === 'dashboard' && (
            <div className="space-y-8 animate-fadeIn">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider">
                      Painel Executivo em Tempo Real (Simulação)
                    </span>
                  </div>
                  <h2 className="text-2xl font-bold text-[#002B58]">
                    Visão Geral de Desempenho Operacional
                  </h2>
                </div>

                <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg text-xs font-semibold text-slate-600">
                  <button
                    onClick={() => setPeriod('hoje')}
                    className={`px-3 py-1.5 rounded-md transition-colors ${
                      period === 'hoje' ? 'bg-white text-[#002B58] shadow-xs' : 'hover:text-slate-900'
                    }`}
                  >
                    Hoje
                  </button>
                  <button
                    onClick={() => setPeriod('semana')}
                    className={`px-3 py-1.5 rounded-md transition-colors ${
                      period === 'semana' ? 'bg-white text-[#002B58] shadow-xs' : 'hover:text-slate-900'
                    }`}
                  >
                    Últimos 7 dias
                  </button>
                  <button
                    onClick={() => setPeriod('mes')}
                    className={`px-3 py-1.5 rounded-md transition-colors ${
                      period === 'mes' ? 'bg-white text-[#002B58] shadow-xs' : 'hover:text-slate-900'
                    }`}
                  >
                    Mês Atual
                  </button>
                </div>
              </div>

              {/* KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card variant="outline" padding="md" className="bg-slate-50/50">
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                    <span>Faturamento Consolidado</span>
                    <TrendingUp className="w-4 h-4 text-emerald-600" />
                  </div>
                  <div className="text-2xl font-extrabold text-[#002B58]">
                    {period === 'hoje'
                      ? 'R$ 8.420,00'
                      : period === 'semana'
                      ? 'R$ 54.180,00'
                      : 'R$ 184.500,00'}
                  </div>
                  <span className="text-xs text-emerald-600 font-semibold mt-1 inline-block">
                    +14.8% vs. período anterior
                  </span>
                </Card>

                <Card variant="outline" padding="md" className="bg-slate-50/50">
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                    <span>O.S. Concluídas</span>
                    <FileCheck2 className="w-4 h-4 text-[#2CBEBF]" />
                  </div>
                  <div className="text-2xl font-extrabold text-[#002B58]">
                    {period === 'hoje' ? '12' : period === 'semana' ? '68' : '142'}
                  </div>
                  <span className="text-xs text-slate-500 font-semibold mt-1 inline-block">
                    Meta de 130 atingida
                  </span>
                </Card>

                <Card variant="outline" padding="md" className="bg-slate-50/50">
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                    <span>Eficiência de Processo</span>
                    <Activity className="w-4 h-4 text-[#FE7001]" />
                  </div>
                  <div className="text-2xl font-extrabold text-[#002B58]">94.2%</div>
                  <span className="text-xs text-emerald-600 font-semibold mt-1 inline-block">
                    Apenas 1.4% de retrabalho
                  </span>
                </Card>

                <Card variant="outline" padding="md" className="bg-slate-50/50">
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                    <span>Tempo Médio Resposta</span>
                    <Clock className="w-4 h-4 text-[#002B58]" />
                  </div>
                  <div className="text-2xl font-extrabold text-[#002B58]">
                    {period === 'hoje' ? '14 min' : '18 min'}
                  </div>
                  <span className="text-xs text-emerald-600 font-semibold mt-1 inline-block">
                    -62% após agentes de IA
                  </span>
                </Card>
              </div>

              {/* Graphical Visualizer */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 p-6 bg-slate-50 rounded-2xl border border-slate-200">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h3 className="text-sm font-bold text-[#002B58]">
                        Distribuição de Receita por Solução (R$)
                      </h3>
                      <p className="text-xs text-slate-500">
                        Dados consolidados automaticamente dos contratos ativos.
                      </p>
                    </div>
                    <span className="text-xs font-mono font-bold text-[#2CBEBF]">
                      Auditado
                    </span>
                  </div>

                  <div className="space-y-4">
                    {[
                      { name: 'Sistemas Sob Medida', value: 42, amount: 'R$ 77.490' },
                      { name: 'Automações de Processo', value: 28, amount: 'R$ 51.660' },
                      { name: 'Agentes de IA e Atendimento', value: 18, amount: 'R$ 33.210' },
                      { name: 'Dashboards Executivos', value: 12, amount: 'R$ 22.140' },
                    ].map((item) => (
                      <div key={item.name} className="space-y-1.5">
                        <div className="flex justify-between text-xs font-semibold">
                          <span className="text-slate-700">{item.name}</span>
                          <span className="text-[#002B58] font-mono">{item.amount} ({item.value}%)</span>
                        </div>
                        <div className="h-3 bg-slate-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-[#002B58] to-[#2CBEBF] rounded-full transition-all duration-500"
                            style={{ width: `${item.value}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-[#002B58] mb-3 flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 text-[#FE7001]" />
                      Alertas de Anomalia
                    </h3>
                    <div className="space-y-3">
                      <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs">
                        <div className="flex items-center justify-between text-slate-400 font-mono text-[10px] mb-1">
                          <span>ALERTA #302</span>
                          <span>Há 12 min</span>
                        </div>
                        <p className="font-semibold text-slate-800">
                          3 ordens de serviço pendentes de aprovação há mais de 48h.
                        </p>
                      </div>

                      <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs">
                        <div className="flex items-center justify-between text-slate-400 font-mono text-[10px] mb-1">
                          <span>NOTIFICAÇÃO</span>
                          <span>Há 1h</span>
                        </div>
                        <p className="font-semibold text-slate-800">
                          Meta semanal de faturamento batida 2 dias antes do prazo.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-slate-200 text-center">
                    <p className="text-xs text-slate-500 mb-2">
                      Quer um dashboard com as métricas do seu negócio?
                    </p>
                    <Button
                      variant="primary-orange"
                      size="sm"
                      className="w-full"
                      onClick={() => onOpenContactModal?.('demonstracao-dashboard')}
                    >
                      Projetar Meu Dashboard
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* DEMO 2: CRM & PIPELINE */}
          {activeTab === 'crm' && (
            <div className="space-y-6 animate-fadeIn">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#FE7001]" />
                    <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider">
                      Funil Comercial B2B Sob Medida
                    </span>
                  </div>
                  <h2 className="text-2xl font-bold text-[#002B58]">
                    Pipeline de Vendas & Negociação
                  </h2>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500 font-semibold">Filtrar por estágio:</span>
                  <select
                    value={crmStageFilter}
                    onChange={(e) => setCrmStageFilter(e.target.value)}
                    className="text-xs font-semibold bg-slate-100 border border-slate-200 rounded-lg px-3 py-1.5 text-slate-700 focus:outline-none"
                  >
                    <option value="all">Todos os estágios</option>
                    <option value="lead">Novos Leads</option>
                    <option value="qualificacao">Qualificação</option>
                    <option value="proposta">Proposta Enviada</option>
                    <option value="fechado">Fechado</option>
                  </select>
                </div>
              </div>

              {/* Kanban Columns */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {[
                  { id: 'lead', title: 'Novos Leads', color: 'border-slate-300' },
                  { id: 'qualificacao', title: 'Diagnóstico & Escopo', color: 'border-[#2CBEBF]' },
                  { id: 'proposta', title: 'Proposta Enviada', color: 'border-[#FE7001]' },
                  { id: 'fechado', title: 'Ganhos / Ativados', color: 'border-emerald-500' },
                ].map((col) => {
                  const dealsInCol = crmDeals.filter(
                    (d) =>
                      (crmStageFilter === 'all' || crmStageFilter === col.id) &&
                      d.stage === col.id
                  );
                  return (
                    <div
                      key={col.id}
                      className="bg-slate-50 rounded-2xl p-4 border border-slate-200 flex flex-col"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                          {col.title}
                        </span>
                        <span className="text-xs font-mono font-bold bg-white text-slate-600 px-2 py-0.5 rounded-md border border-slate-200">
                          {dealsInCol.length}
                        </span>
                      </div>

                      <div className="space-y-3 flex-1">
                        {dealsInCol.map((deal) => (
                          <div
                            key={deal.id}
                            className={`p-4 bg-white rounded-xl border border-slate-200 shadow-2xs hover:shadow-sm transition-all border-l-4 ${col.color}`}
                          >
                            <div className="flex justify-between items-start mb-2">
                              <h4 className="text-xs font-bold text-[#002B58]">
                                {deal.client}
                              </h4>
                              <span className="text-xs font-bold text-[#FE7001] font-mono">
                                {deal.value}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-600 mb-3">
                              {deal.service}
                            </p>
                            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
                              <span>{deal.contact}</span>
                              <span>Há {deal.days}d</span>
                            </div>
                          </div>
                        ))}

                        {dealsInCol.length === 0 && (
                          <div className="text-center py-8 text-xs text-slate-400 border border-dashed border-slate-200 rounded-xl">
                            Nenhum negócio nesta etapa
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="p-4 bg-[#002B58]/5 border border-[#002B58]/10 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
                <p className="text-xs text-slate-700 text-center sm:text-left">
                  <strong>Precisa de um CRM alinhado ao seu modelo de vendas?</strong> Criamos interfaces sob medida sem complexidade excessiva.
                </p>
                <Button
                  variant="primary-teal"
                  size="sm"
                  onClick={() => onOpenContactModal?.('demonstracao-crm')}
                >
                  Solicitar CRM Próprio
                </Button>
              </div>
            </div>
          )}

          {/* DEMO 3: SISTEMA & O.S. */}
          {activeTab === 'sistema' && (
            <div className="space-y-6 animate-fadeIn">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#2CBEBF]" />
                    <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider">
                      Módulo de Ordens de Serviço & Operação
                    </span>
                  </div>
                  <h2 className="text-2xl font-bold text-[#002B58]">
                    Gestão Central de Serviços & Atendimentos
                  </h2>
                </div>

                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <div className="relative flex-1 sm:w-64">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Buscar por cliente ou O.S..."
                      value={osSearch}
                      onChange={(e) => setOsSearch(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-[#2CBEBF]"
                    />
                  </div>
                  <select
                    value={osStatusFilter}
                    onChange={(e) => setOsStatusFilter(e.target.value as any)}
                    className="text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-700 focus:outline-none"
                  >
                    <option value="all">Todos os Status</option>
                    <option value="execucao">Em Execução</option>
                    <option value="aprovado">Aprovado</option>
                    <option value="concluido">Concluído</option>
                  </select>
                </div>
              </div>

              {/* Table / List */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-[11px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200">
                        <th className="p-4">Identificador</th>
                        <th className="p-4">Cliente</th>
                        <th className="p-4">Serviço Solicitado</th>
                        <th className="p-4">Técnico Responsável</th>
                        <th className="p-4">Previsão</th>
                        <th className="p-4">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs">
                      {osList
                        .filter(
                          (item) =>
                            (osStatusFilter === 'all' || item.status === osStatusFilter) &&
                            (item.cliente.toLowerCase().includes(osSearch.toLowerCase()) ||
                              item.id.toLowerCase().includes(osSearch.toLowerCase()))
                        )
                        .map((item) => (
                          <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                            <td className="p-4 font-mono font-bold text-[#002B58]">
                              {item.id}
                            </td>
                            <td className="p-4 font-semibold text-slate-900">
                              {item.cliente}
                            </td>
                            <td className="p-4 text-slate-600">{item.tipo}</td>
                            <td className="p-4 text-slate-600">{item.tecnico}</td>
                            <td className="p-4 font-mono text-slate-500">{item.prazo}</td>
                            <td className="p-4">
                              <span
                                className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                                  item.status === 'concluido'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : item.status === 'execucao'
                                    ? 'bg-amber-100 text-amber-800'
                                    : 'bg-blue-100 text-blue-800'
                                }`}
                              >
                                {item.statusLabel}
                              </span>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h4 className="text-sm font-bold text-[#002B58]">
                    Substitua planilhas e papéis por um fluxo de O.S. 100% digital
                  </h4>
                  <p className="text-xs text-slate-600">
                    Seus técnicos atualizam pelo celular e o cliente acompanha em tempo real.
                  </p>
                </div>
                <Button
                  variant="primary-orange"
                  size="sm"
                  onClick={() => onOpenContactModal?.('demonstracao-sistema-os')}
                >
                  Criar Sistema de O.S.
                </Button>
              </div>
            </div>
          )}

          {/* DEMO 4: AGENTE DE IA */}
          {activeTab === 'ia' && (
            <div className="max-w-2xl mx-auto space-y-4 animate-fadeIn">
              <div className="text-center pb-4 border-b border-slate-100">
                <div className="flex items-center justify-center gap-2 mb-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                  <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider">
                    Agente Cognitivo MAVITH (WhatsApp / Web Demo)
                  </span>
                </div>
                <h3 className="text-xl font-bold text-[#002B58]">
                  Simulação de Atendimento Inteligente 24/7
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Treinado nas políticas e catálogo da sua empresa para qualificar leads e resolver chamados.
                </p>
              </div>

              {/* Chat Window */}
              <div className="border border-slate-200 rounded-2xl bg-slate-50 p-4 h-96 flex flex-col justify-between overflow-y-auto">
                <div className="space-y-3 overflow-y-auto pr-1">
                  {chatMessages.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`flex flex-col ${
                        msg.sender === 'user' ? 'items-end' : 'items-start'
                      }`}
                    >
                      <div
                        className={`max-w-[85%] p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                          msg.sender === 'user'
                            ? 'bg-[#002B58] text-white rounded-br-none'
                            : 'bg-white text-slate-800 border border-slate-200 rounded-bl-none shadow-2xs'
                        }`}
                      >
                        {msg.text}
                      </div>
                      <span className="text-[10px] text-slate-400 mt-1 px-1 font-mono">
                        {msg.time}
                      </span>
                    </div>
                  ))}

                  {isTyping && (
                    <div className="flex items-center gap-1.5 p-3 bg-white border border-slate-200 rounded-2xl rounded-bl-none w-20 text-slate-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#2CBEBF] animate-bounce" />
                      <span className="w-1.5 h-1.5 rounded-full bg-[#2CBEBF] animate-bounce [animation-delay:0.2s]" />
                      <span className="w-1.5 h-1.5 rounded-full bg-[#2CBEBF] animate-bounce [animation-delay:0.4s]" />
                    </div>
                  )}
                </div>

                {/* Quick Prompts */}
                <div className="pt-3 border-t border-slate-200">
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {[
                      'Como saber se preciso de um sistema?',
                      'Qual o prazo de entrega?',
                      'Como o agente atende no WhatsApp?',
                      'Substituir planilhas do Excel',
                    ].map((prompt) => (
                      <button
                        key={prompt}
                        onClick={() => handleSendMessage(prompt)}
                        className="text-[10px] font-semibold bg-white border border-slate-200 hover:border-[#2CBEBF] hover:text-[#002B58] px-2.5 py-1 rounded-full text-slate-600 transition-colors"
                      >
                        {prompt}
                      </button>
                    ))}
                  </div>

                  {/* Input form */}
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleSendMessage();
                    }}
                    className="flex gap-2"
                  >
                    <input
                      type="text"
                      placeholder="Digite sua dúvida para testar a IA..."
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      className="flex-1 px-4 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-[#2CBEBF]"
                    />
                    <Button
                      type="submit"
                      variant="primary-teal"
                      size="sm"
                      disabled={isTyping}
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </form>
                </div>
              </div>
            </div>
          )}

          {/* DEMO 5: AUTOMAÇÃO */}
          {activeTab === 'automacao' && (
            <div className="space-y-6 animate-fadeIn">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#FE7001]" />
                    <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider">
                      Pipeline de Automação de Processos
                    </span>
                  </div>
                  <h2 className="text-2xl font-bold text-[#002B58]">
                    Fluxo Autônomo: Do Formulário ao WhatsApp
                  </h2>
                </div>

                <Button
                  variant="primary-orange"
                  size="md"
                  onClick={handleRunAutomation}
                  disabled={automationRunning}
                  leftIcon={<Play className="w-4 h-4" />}
                >
                  {automationRunning ? 'Executando Pipeline...' : 'Testar Execução ao Vivo'}
                </Button>
              </div>

              {/* Steps Visualizer */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {[
                  {
                    step: 1,
                    title: '1. Gatilho (Trigger)',
                    desc: 'Novo lead capturado no site',
                    icon: Play,
                  },
                  {
                    step: 2,
                    title: '2. Enriquecimento',
                    desc: 'Consulta de CNPJ na Receita',
                    icon: Search,
                  },
                  {
                    step: 3,
                    title: '3. CRM & Negócio',
                    desc: 'Criação de Oportunidade',
                    icon: Layers,
                  },
                  {
                    step: 4,
                    title: '4. Notificação & E-mail',
                    desc: 'Aviso WhatsApp ao vendedor',
                    icon: MessageSquare,
                  },
                ].map((item) => {
                  const isDone = automationStep >= item.step;
                  const isCurrent = automationStep === item.step && automationRunning;
                  return (
                    <div
                      key={item.step}
                      className={`p-4 rounded-2xl border transition-all duration-300 ${
                        isCurrent
                          ? 'bg-amber-50 border-[#FE7001] shadow-xs'
                          : isDone
                          ? 'bg-emerald-50/60 border-emerald-300'
                          : 'bg-slate-50 border-slate-200 opacity-60'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold text-slate-700">
                          {item.title}
                        </span>
                        {isDone ? (
                          <CheckCircle className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <span className="w-4 h-4 rounded-full border border-slate-300 inline-block" />
                        )}
                      </div>
                      <p className="text-xs text-slate-600">{item.desc}</p>
                    </div>
                  );
                })}
              </div>

              {/* Console Logs */}
              <div className="p-4 bg-slate-900 text-slate-200 rounded-2xl font-mono text-xs space-y-1.5 shadow-inner">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-[11px] text-slate-400">
                  <span>LOGS DE EXECUÇÃO EM TEMPO REAL</span>
                  <span>STATUS: {automationRunning ? 'RODANDO...' : 'AGUARDANDO GATILHO'}</span>
                </div>
                {automationLogs.length === 0 ? (
                  <p className="text-slate-500 py-4 text-center">
                    Clique em "Testar Execução ao Vivo" acima para simular a automação.
                  </p>
                ) : (
                  automationLogs.map((log, idx) => (
                    <div key={idx} className="leading-relaxed">
                      {log}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Bottom CTA Banner */}
        <div className="mt-12 text-center max-w-2xl mx-auto">
          <p className="text-xs text-slate-500 uppercase tracking-wider font-bold mb-2">
            Gostou do que viu?
          </p>
          <h3 className="text-xl sm:text-2xl font-bold text-[#002B58] mb-4">
            Vamos desenhar a solução ideal para o fluxo da sua empresa.
          </h3>
          <div className="flex flex-wrap justify-center gap-3">
            <Button
              variant="primary-orange"
              size="md"
              onClick={() => onOpenContactModal?.('diagnostico-demonstracoes')}
            >
              Agendar Diagnóstico Gratuito
            </Button>
            {onBackToHome && (
              <Button variant="secondary" size="md" onClick={onBackToHome}>
                Voltar para Início
              </Button>
            )}
          </div>
        </div>
      </Container>
    </div>
  );
};
