import React, { useState, useEffect } from 'react';
import { Modal } from '../../design-system/components/Modal';
import { Button } from '../../design-system/components/Button';
import { Input, Textarea, Select } from '../../design-system/components/Input';
import { Badge } from '../../design-system/components/Badge';
import {
  Send,
  CheckCircle2,
  MessageSquare,
  Sparkles,
  ShieldCheck,
  Clock,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import { LeadProjectType, LeadPayload } from '../../types/lead';
import {
  analytics,
  crm,
  buildWhatsAppLink,
  MAVITH_DEFAULT_WHATSAPP_MESSAGE,
} from '../../services/analytics';

interface LeadConversionModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialInterest?: string;
  sourceLocation?: string;
}

export const LeadConversionModal: React.FC<LeadConversionModalProps> = ({
  isOpen,
  onClose,
  initialInterest = 'Sistema',
  sourceLocation = 'modal',
}) => {
  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [projectType, setProjectType] = useState<LeadProjectType>('Sistema');
  const [message, setMessage] = useState('');
  const [hasStarted, setHasStarted] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedLead, setSubmittedLead] = useState<LeadPayload | null>(null);

  // Map initialInterest string to valid LeadProjectType
  useEffect(() => {
    if (initialInterest) {
      const lower = initialInterest.toLowerCase();
      if (lower.includes('site') || lower.includes('portal')) setProjectType('Site');
      else if (lower.includes('sistema') || lower.includes('software')) setProjectType('Sistema');
      else if (lower.includes('ia') || lower.includes('inteligencia')) setProjectType('IA');
      else if (lower.includes('automa') || lower.includes('integra')) setProjectType('Automação');
      else if (lower.includes('dash') || lower.includes('bi')) setProjectType('Dashboard');
      else if (lower.includes('integra')) setProjectType('Integração');
      else setProjectType('Outro');
    }
  }, [initialInterest]);

  // Track form opened
  useEffect(() => {
    if (isOpen) {
      setIsSubmitted(false);
      setSubmittedLead(null);
      setHasStarted(false);
    }
  }, [isOpen]);

  const handleFirstInteraction = (field: string) => {
    if (!hasStarted) {
      setHasStarted(true);
      analytics.trackFormStarted('lead_conversion_modal', field);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const saved = crm.saveLead({
      name,
      company,
      whatsapp,
      email,
      projectType,
      message: message || 'Nenhuma mensagem adicional informada.',
      lead_page: typeof window !== 'undefined' ? window.location.hash || '/' : '/',
      lead_service: projectType,
    });

    setSubmittedLead(saved);
    setIsSubmitted(true);
  };

  const handleWhatsAppRedirect = () => {
    const contextualMessage = company
      ? `Olá, MAVITH! Meu nome é ${name || 'um cliente'} da empresa ${company}. Gostaria de conversar sobre uma solução digital (${projectType}).`
      : MAVITH_DEFAULT_WHATSAPP_MESSAGE;

    analytics.trackWhatsAppClick(sourceLocation, contextualMessage);
    window.open(buildWhatsAppLink(contextualMessage), '_blank', 'noopener,noreferrer');
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={isSubmitted ? 'Recebemos sua mensagem' : 'Fale com a MAVITH'}
      description={
        isSubmitted
          ? 'Analisaremos o contexto da sua operação antes de entrar em contato.'
          : 'Sem abordagens agressivas. Conte-nos o momento da sua empresa e como podemos ajudar.'
      }
      maxWidth="max-w-2xl"
    >
      {isSubmitted && submittedLead ? (
        <div className="py-4 space-y-6">
          <div className="p-5 bg-emerald-50/80 border border-emerald-200/80 rounded-2xl flex items-start gap-4">
            <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-bold text-emerald-950 mb-1">
                Solicitação registrada com sucesso!
              </h4>
              <p className="text-xs sm:text-sm text-emerald-800 leading-relaxed">
                Olá, <strong>{submittedLead.name}</strong>. Nossa equipe técnica avaliará as necessidades da <strong>{submittedLead.company}</strong> e entrará em contato pelo WhatsApp <strong>{submittedLead.whatsapp}</strong> ou e-mail <strong>{submittedLead.email}</strong>.
              </p>
            </div>
          </div>

          {/* Next Steps Timeline */}
          <div className="p-5 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
            <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-[#002B58]">
              Próximos Passos
            </span>
            <div className="space-y-2.5 text-xs text-slate-700">
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-[#002B58] text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                  1
                </span>
                <span>
                  <strong>Análise Operacional Prévia:</strong> Um especialista da MAVITH revisa seu segmento e possíveis integrações.
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-[#002B58] text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                  2
                </span>
                <span>
                  <strong>Conversa Prática de 30 minutos:</strong> Alinhamento de escopo sem jargões e sem compromisso.
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-[#002B58] text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                  3
                </span>
                <span>
                  <strong>Plano de Solução com ROI:</strong> Proposta clara de cronograma, custos e retorno operacional.
                </span>
              </div>
            </div>
          </div>

          {/* Instant WhatsApp Option */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
            <Button
              variant="outline"
              size="md"
              onClick={handleWhatsAppRedirect}
              className="w-full sm:w-auto border-emerald-600 text-emerald-700 hover:bg-emerald-50"
              leftIcon={<MessageSquare className="w-4 h-4 text-emerald-600" />}
            >
              Iniciar Conversa Imediata no WhatsApp
            </Button>

            <Button variant="primary-teal" size="md" onClick={onClose} className="w-full sm:w-auto">
              Concluir
            </Button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4 pt-1">
          {/* Form Context Header Badge */}
          <div className="flex items-center gap-2 p-3 bg-slate-50 border border-slate-100 rounded-xl text-xs text-slate-600">
            <ShieldCheck className="w-4 h-4 text-[#2CBEBF] shrink-0" />
            <span>
              Suas informações são tratadas com sigilo e usadas exclusivamente para o diagnóstico do seu negócio.
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              id="lead-nome"
              label="Seu Nome Completo"
              placeholder="Ex: Carlos Silva"
              required
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                handleFirstInteraction('nome');
              }}
            />

            <Input
              id="lead-empresa"
              label="Nome da Sua Empresa"
              placeholder="Ex: Alfa Logística / Padaria Central"
              required
              value={company}
              onChange={(e) => {
                setCompany(e.target.value);
                handleFirstInteraction('empresa');
              }}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              id="lead-whatsapp"
              label="WhatsApp com DDD"
              placeholder="(11) 98888-7777"
              required
              value={whatsapp}
              onChange={(e) => {
                setWhatsapp(e.target.value);
                handleFirstInteraction('whatsapp');
              }}
            />

            <Input
              id="lead-email"
              label="E-mail Corporativo ou Pessoal"
              type="email"
              placeholder="carlos@suaempresa.com.br"
              required
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                handleFirstInteraction('email');
              }}
            />
          </div>

          <Select
            id="lead-tipo-projeto"
            label="Tipo de Projeto Desejado"
            value={projectType}
            onChange={(e) => {
              setProjectType(e.target.value as LeadProjectType);
              handleFirstInteraction('tipo-projeto');
            }}
            options={[
              { value: 'Site', label: 'Site / Presença Digital & Plataforma' },
              { value: 'Sistema', label: 'Sistema Sob Medida / Substituição de Planilhas' },
              { value: 'IA', label: 'Inteligência Artificial / Agente Operacional' },
              { value: 'Automação', label: 'Automação de Processos & Rotinas' },
              { value: 'Dashboard', label: 'Dashboard & Business Intelligence (BI)' },
              { value: 'Integração', label: 'Integração de Ferramentas / APIs / ERP' },
              { value: 'Outro', label: 'Outro Desafio Operacional' },
            ]}
          />

          <Textarea
            id="lead-mensagem"
            label="Conte-nos brevemente sobre o seu momento ou dor atual"
            rows={3}
            placeholder="Ex: Estamos perdendo tempo consolidando dados manualmente de duas planilhas e precisamos de uma solução confiável..."
            value={message}
            onChange={(e) => {
              setMessage(e.target.value);
              handleFirstInteraction('mensagem');
            }}
          />

          <div className="pt-2 flex flex-col-reverse sm:flex-row items-center justify-between gap-3 border-t border-slate-100">
            {/* Alternative Direct WhatsApp */}
            <button
              type="button"
              onClick={handleWhatsAppRedirect}
              className="text-xs text-slate-500 hover:text-emerald-700 flex items-center gap-1.5 font-medium transition-colors py-2"
            >
              <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
              <span>Prefere falar direto no WhatsApp?</span>
            </button>

            {/* Primary Action */}
            <Button
              type="submit"
              variant="primary-orange"
              size="md"
              className="w-full sm:w-auto font-bold"
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Fale com a MAVITH
            </Button>
          </div>
        </form>
      )}
    </Modal>
  );
};
