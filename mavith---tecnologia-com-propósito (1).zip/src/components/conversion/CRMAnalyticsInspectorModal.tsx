import React, { useState, useEffect } from 'react';
import { Modal } from '../../design-system/components/Modal';
import { Badge } from '../../design-system/components/Badge';
import { Button } from '../../design-system/components/Button';
import { Card } from '../../design-system/components/Card';
import {
  Activity,
  Users,
  Database,
  CheckCircle2,
  Trash2,
  Download,
  ExternalLink,
  Sparkles,
  Search,
  Clock,
  Send,
  MessageSquare,
} from 'lucide-react';
import { LeadPayload, AnalyticsEvent } from '../../types/lead';
import { analytics, crm } from '../../services/analytics';

interface CRMAnalyticsInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CRMAnalyticsInspectorModal: React.FC<CRMAnalyticsInspectorModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'leads' | 'events' | 'integrations'>('leads');
  const [leads, setLeads] = useState<LeadPayload[]>([]);
  const [events, setEvents] = useState<AnalyticsEvent[]>([]);

  const refreshData = () => {
    setLeads(crm.getStoredLeads());
    setEvents(analytics.getRecentEvents());
  };

  useEffect(() => {
    if (isOpen) {
      refreshData();
    }
  }, [isOpen]);

  const handleClearLeads = () => {
    if (window.confirm('Deseja limpar todos os leads registrados na sessão local?')) {
      crm.clearLeads();
      refreshData();
    }
  };

  const handleClearEvents = () => {
    if (window.confirm('Deseja limpar o histórico de eventos de analytics da sessão local?')) {
      analytics.clearEvents();
      refreshData();
    }
  };

  const handleSimulateLead = () => {
    crm.saveLead({
      name: 'Diretor Operacional (Simulação)',
      company: 'Logística & Varejo Brasil',
      whatsapp: '(11) 99876-5432',
      email: 'operacoes@varejobrasil.com.br',
      projectType: 'Sistema',
      message: 'Precisamos migrar três planilhas financeiras para um painel web com permissões por filial.',
      lead_source: 'google_ads_teste',
      lead_campaign: 'conversao_sistemas_2026',
      lead_page: window.location.hash || '/#solucoes',
      lead_service: 'Sistema',
    });
    refreshData();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Console de Conversão, CRM & Analytics (Fase 6)"
      description="Monitoramento em tempo real dos leads capturados, eventos de conversão e integração pronta para CRM/Pixel/GA4."
      maxWidth="max-w-5xl"
    >
      <div className="space-y-6">
        {/* Navigation Tabs */}
        <div className="flex items-center justify-between border-b border-slate-200 pb-3 gap-2 overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('leads')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'leads'
                  ? 'bg-[#002B58] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Leads Capturados ({leads.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('events')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'events'
                  ? 'bg-[#002B58] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Eventos Disparados ({events.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('integrations')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'integrations'
                  ? 'bg-[#002B58] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>Arquitetura CRM & Tags</span>
            </button>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <Button variant="ghost" size="sm" onClick={handleSimulateLead}>
              + Simular Lead
            </Button>
          </div>
        </div>

        {/* TAB 1: Captured Leads */}
        {activeTab === 'leads' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-600">
              <span>
                Exibindo leads com enriquecimento contextual (origem, campanha, página e serviço).
              </span>
              {leads.length > 0 && (
                <button
                  onClick={handleClearLeads}
                  className="text-rose-600 hover:text-rose-700 flex items-center gap-1 font-semibold"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Limpar Leads
                </button>
              )}
            </div>

            {leads.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 border border-dashed border-slate-200 rounded-2xl">
                <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <h4 className="text-sm font-bold text-slate-700">Nenhum lead capturado ainda</h4>
                <p className="text-xs text-slate-500 mt-1 mb-4">
                  Abra qualquer formulário do site ou clique em "Simular Lead" para testar o pipeline.
                </p>
                <Button variant="secondary" size="sm" onClick={handleSimulateLead}>
                  Simular Envio de Lead
                </Button>
              </div>
            ) : (
              <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1">
                {leads.map((lead) => (
                  <Card key={lead.id} variant="outline" padding="md" className="bg-white border-slate-200">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-[#002B58]">{lead.name}</h4>
                          <span className="text-xs text-slate-400">•</span>
                          <span className="text-xs font-semibold text-slate-700">{lead.company}</span>
                        </div>
                        <span className="text-xs text-slate-500">
                          {lead.email} | {lead.whatsapp}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Badge variant="teal" size="sm">
                          {lead.projectType}
                        </Badge>
                        <span className="text-[11px] font-mono text-slate-400">
                          {new Date(lead.lead_timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-700 mb-3 italic">
                      "{lead.message}"
                    </div>

                    {/* CRM Metadata Tags */}
                    <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono bg-slate-100/70 p-2.5 rounded-lg text-slate-600">
                      <span>
                        <strong>Origem:</strong> {lead.lead_source}
                      </span>
                      <span>•</span>
                      <span>
                        <strong>Campanha:</strong> {lead.lead_campaign}
                      </span>
                      <span>•</span>
                      <span>
                        <strong>Página:</strong> {lead.lead_page}
                      </span>
                      <span>•</span>
                      <span>
                        <strong>Serviço:</strong> {lead.lead_service}
                      </span>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: Real-time Analytics Events */}
        {activeTab === 'events' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-600">
              <span>
                Histórico dos últimos eventos rastreados (disparados para GTM, GA4 e Meta Pixel).
              </span>
              {events.length > 0 && (
                <button
                  onClick={handleClearEvents}
                  className="text-rose-600 hover:text-rose-700 flex items-center gap-1 font-semibold"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Limpar Eventos
                </button>
              )}
            </div>

            {events.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 border border-dashed border-slate-200 rounded-2xl">
                <Activity className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <h4 className="text-sm font-bold text-slate-700">Nenhum evento registrado ainda</h4>
                <p className="text-xs text-slate-500 mt-1">
                  Navegue pelo site, clique em CTAs ou no botão do WhatsApp para gerar eventos.
                </p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[50vh] overflow-y-auto font-mono text-xs pr-1">
                {events.map((evt) => (
                  <div
                    key={evt.id}
                    className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-start justify-between gap-4"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-bold text-[#002B58] uppercase px-2 py-0.5 bg-white border border-slate-200 rounded text-[11px]">
                          {evt.event}
                        </span>
                        <span className="text-slate-400 text-[11px]">{evt.page}</span>
                      </div>
                      <pre className="text-[10px] text-slate-600 overflow-x-auto scrollbar-none">
                        {JSON.stringify(evt.params, null, 2)}
                      </pre>
                    </div>

                    <span className="text-[10px] text-slate-400 shrink-0">
                      {new Date(evt.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: CRM Architecture & Tags Integration */}
        {activeTab === 'integrations' && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <h4 className="text-xs font-bold text-[#002B58]">Google Analytics 4</h4>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Disparo via <code>window.gtag('event', name, params)</code> ativo para conversões, visualização de cases e artigos.
                </p>
              </div>

              <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <h4 className="text-xs font-bold text-[#002B58]">Google Tag Manager</h4>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Estrutura <code>window.dataLayer.push()</code> pronta para acionadores personalizados e tags de conversão.
                </p>
              </div>

              <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <h4 className="text-xs font-bold text-[#002B58]">Meta Pixel</h4>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Disparos nativos de evento padrão <code>Lead</code> e evento personalizado <code>WhatsAppClick</code>.
                </p>
              </div>
            </div>

            {/* CRM Webhook Schema */}
            <div className="p-5 border border-slate-200 rounded-2xl bg-white space-y-3">
              <h4 className="text-xs font-bold text-[#002B58] uppercase tracking-wider">
                Estrutura de Carga Útil para Envio a CRM / Webhook (HubSpot, RD Station, Pipedrive)
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Cada lead registrado inclui todos os parâmetros obrigatórios da Fase 6 para atribuição precisa:
              </p>
              <pre className="p-4 bg-slate-900 text-emerald-400 rounded-xl text-xs overflow-x-auto font-mono">
{`{
  "lead_id": "lead-1726058400-abc12",
  "name": "Carlos Silva",
  "company": "Padaria Central Ltda",
  "whatsapp": "(11) 98888-7777",
  "email": "carlos@padariacentral.com.br",
  "projectType": "Sistema",
  "message": "Substituição de planilhas de pedidos e estoque.",
  "lead_source": "google_cpc",
  "lead_campaign": "sistemas_sp_2026",
  "lead_page": "/#solucoes/sistemas",
  "lead_service": "Sistema",
  "lead_timestamp": "2026-09-11T18:00:00.000Z",
  "status": "novo"
}`}
              </pre>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
