import React, { useState } from 'react';
import { MessageSquare, X } from 'lucide-react';
import {
  analytics,
  buildWhatsAppLink,
  MAVITH_DEFAULT_WHATSAPP_MESSAGE,
} from '../../services/analytics';

interface WhatsAppFloatingButtonProps {
  customMessage?: string;
  sourceLocation?: string;
}

export const WhatsAppFloatingButton: React.FC<WhatsAppFloatingButtonProps> = ({
  customMessage,
  sourceLocation = 'floating_button',
}) => {
  const [showTooltip, setShowTooltip] = useState(true);

  const handleClick = () => {
    const msg = customMessage || MAVITH_DEFAULT_WHATSAPP_MESSAGE;
    analytics.trackWhatsAppClick(sourceLocation, msg);
    window.open(buildWhatsAppLink(msg), '_blank', 'noopener,noreferrer');
  };

  return (
    <aside aria-label="Atendimento rápido WhatsApp" className="fixed bottom-6 right-6 z-50 flex items-center gap-3">
      {/* Friendly Tooltip Bubble */}
      {showTooltip && (
        <div className="hidden sm:flex items-center gap-2 bg-white text-slate-800 text-xs font-semibold px-3.5 py-2 rounded-2xl shadow-lg border border-slate-200/80 animate-fade-in">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>Fale direto no WhatsApp</span>
          <button
            type="button"
            aria-label="Fechar dica do WhatsApp"
            onClick={(e) => {
              e.stopPropagation();
              setShowTooltip(false);
            }}
            className="text-slate-400 hover:text-slate-600 ml-1"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Floating Action Button */}
      <button
        onClick={handleClick}
        aria-label="Conversar no WhatsApp com a MAVITH"
        className="w-13 h-13 sm:w-14 sm:h-14 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 active:scale-95 focus:outline-none focus:ring-4 focus:ring-emerald-200 relative group cursor-pointer"
      >
        <MessageSquare className="w-6 h-6 sm:w-7 sm:h-7 fill-white/20" />
        
        {/* Subtle Online Dot */}
        <span className="absolute top-1 right-1 w-3.5 h-3.5 rounded-full bg-white border-2 border-emerald-500 flex items-center justify-center">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
        </span>
      </button>
    </aside>
  );
};
