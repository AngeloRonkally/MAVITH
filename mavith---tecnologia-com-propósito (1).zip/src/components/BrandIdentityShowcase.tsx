import React, { useState } from 'react';
import { MavithLogo } from '../design-system/components/MavithLogo';
import { Card } from '../design-system/components/Card';
import { Badge } from '../design-system/components/Badge';
import { Button } from '../design-system/components/Button';
import {
  Copy,
  Check,
  Code2,
  Database,
  Bot,
  BarChart3,
  Layers,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';

interface ColorToken {
  name: string;
  role: string;
  hex: string;
  textColor: string;
  contrastNotice: string;
  category: 'principal' | 'apoio' | 'neutro';
}

const COLOR_TOKENS: ColorToken[] = [
  // Principais
  {
    name: 'Azul Profundo',
    role: 'Cor Institucional Primária. Estrutura, solidez e autoridade.',
    hex: '#002B58',
    textColor: '#FFFFFF',
    contrastNotice: 'WCAG AAA com texto branco',
    category: 'principal',
  },
  {
    name: 'Turquesa Conexão',
    role: 'Inteligência, tecnologia e fluxo de dados. Destaque de conectividade.',
    hex: '#2CBEBF',
    textColor: '#002B58',
    contrastNotice: 'Excelente com azul escuro e neutros',
    category: 'principal',
  },
  {
    name: 'Laranja Ação',
    role: 'Cor de Conversão e Decisão. Utilizado exclusivamente em ações e CTAs.',
    hex: '#FE7001',
    textColor: '#FFFFFF',
    contrastNotice: 'Alto impacto ótico; não usar em excesso',
    category: 'principal',
  },
  {
    name: 'Branco Puro',
    role: 'Clareza, respiro e contraste para ambientes limpos.',
    hex: '#FFFFFF',
    textColor: '#002B58',
    contrastNotice: 'Fundo principal da interface',
    category: 'principal',
  },

  // Apoio
  {
    name: 'Azul Noturno',
    role: 'Fundo institucional para Footers e seções de alto foco.',
    hex: '#001C3B',
    textColor: '#FFFFFF',
    contrastNotice: 'Base de contraste dark',
    category: 'apoio',
  },
  {
    name: 'Azul Superfície',
    role: 'Elevação para containers e cartões em modo escuro.',
    hex: '#002447',
    textColor: '#FFFFFF',
    contrastNotice: 'Fundo secundário dark',
    category: 'apoio',
  },
  {
    name: 'Azul Sutil',
    role: 'Fundo suave para cartões de diagnóstico e seções destacadas.',
    hex: '#EBF6FC',
    textColor: '#002B58',
    contrastNotice: 'Excelente leitura para pequenos textos',
    category: 'apoio',
  },
  {
    name: 'Turquesa Claro',
    role: 'Fundos de Badges analíticos e chips de status.',
    hex: '#E2F8F8',
    textColor: '#0D6B6B',
    contrastNotice: 'Suavidade com identidade',
    category: 'apoio',
  },
  {
    name: 'Laranja Suave',
    role: 'Badges de alerta estratégico e diagnósticos.',
    hex: '#FFF2E7',
    textColor: '#C45500',
    contrastNotice: 'Destaque contido',
    category: 'apoio',
  },

  // Neutros
  {
    name: 'Cinza Superfície 50',
    role: 'Background de fundo da página para repouso visual.',
    hex: '#F8FAFC',
    textColor: '#334155',
    contrastNotice: 'Neutro frio 1%',
    category: 'neutro',
  },
  {
    name: 'Cinza Borda 200',
    role: 'Linhas divisórias e bordas sutis de cartões.',
    hex: '#E2E8F0',
    textColor: '#0F172A',
    contrastNotice: 'Divisores 1px',
    category: 'neutro',
  },
  {
    name: 'Cinza Texto 600',
    role: 'Corpo de texto e descrições técnicas.',
    hex: '#475569',
    textColor: '#FFFFFF',
    contrastNotice: 'WCAG AA para corpo de texto',
    category: 'neutro',
  },
];

export const BrandIdentityShowcase: React.FC = () => {
  const [copiedHex, setCopiedHex] = useState<string | null>(null);
  const [logoTheme, setLogoTheme] = useState<'light' | 'dark'>('light');

  const copyToClipboard = (hex: string) => {
    try {
      if (navigator?.clipboard?.writeText) {
        navigator.clipboard.writeText(hex).catch(() => {});
      }
    } catch {
      // Ignore clipboard permission errors in iframe
    }
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 2000);
  };

  return (
    <div className="w-full space-y-16">
      {/* 1. Logomarca Oficial e Aplicações */}
      <div>
        <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
          <div>
            <h3
              className="text-2xl font-bold text-[#002B58]"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Identidade Visual & Logomarca Oficial
            </h3>
            <p className="text-sm text-slate-500 mt-1">
              Preservação rigorosa do símbolo &apos;M&apos;, formas geométricas multifacetadas,
              nós de circuito e tipografia institucional.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-lg border border-slate-200">
            <button
              type="button"
              onClick={() => setLogoTheme('light')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                logoTheme === 'light'
                  ? 'bg-white text-[#002B58] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Fundo Claro
            </button>
            <button
              type="button"
              onClick={() => setLogoTheme('dark')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                logoTheme === 'dark'
                  ? 'bg-[#002B58] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Fundo Escuro
            </button>
          </div>
        </div>

        {/* Logo Display Showcase Canvas */}
        <div
          className={`rounded-2xl p-8 sm:p-12 border transition-colors duration-300 relative overflow-hidden ${
            logoTheme === 'light'
              ? 'bg-white border-slate-200 shadow-xs'
              : 'bg-[#001C3B] border-slate-700 shadow-xl'
          }`}
        >
          {/* Subtle background circuit traces */}
          <div
            className={`absolute inset-0 pointer-events-none opacity-25 ${
              logoTheme === 'light' ? 'bg-circuit-subtle' : 'bg-circuit-dark'
            }`}
          />

          <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
            {/* Main Full Logo */}
            <div className="md:col-span-2 flex flex-col items-start gap-4">
              <span
                className={`text-xs font-mono uppercase tracking-wider ${
                  logoTheme === 'light' ? 'text-slate-400' : 'text-slate-400'
                }`}
              >
                Versão Principal Completa (Símbolo + Wordmark + Slogan)
              </span>
              <MavithLogo
                variant="full"
                theme={logoTheme}
                size="xl"
                className="py-2"
              />
              <div
                className={`text-xs mt-2 leading-relaxed max-w-md ${
                  logoTheme === 'light' ? 'text-slate-500' : 'text-slate-300'
                }`}
              >
                O traço circuitado no vale do &apos;M&apos; simboliza o fluxo de inteligência
                digital, conectando dados dispersos a resultados estratégicos.
              </div>
            </div>

            {/* Compact & Symbol Variations */}
            <div
              className={`flex flex-col gap-6 p-6 rounded-xl border ${
                logoTheme === 'light'
                  ? 'bg-slate-50 border-slate-200'
                  : 'bg-[#002447] border-slate-700'
              }`}
            >
              <div>
                <span
                  className={`text-[11px] font-mono uppercase tracking-wider block mb-2 ${
                    logoTheme === 'light' ? 'text-slate-400' : 'text-slate-400'
                  }`}
                >
                  Versão Compacta
                </span>
                <MavithLogo
                  variant="compact"
                  theme={logoTheme}
                  size="md"
                  showSlogan={false}
                />
              </div>

              <div className="pt-4 border-t border-slate-200/40">
                <span
                  className={`text-[11px] font-mono uppercase tracking-wider block mb-2 ${
                    logoTheme === 'light' ? 'text-slate-400' : 'text-slate-400'
                  }`}
                >
                  Ícone / Favicon (Símbolo M Isolado)
                </span>
                <div className="flex items-center gap-4">
                  <MavithLogo
                    variant="symbol"
                    theme={logoTheme}
                    size="md"
                  />
                  <MavithLogo
                    variant="symbol"
                    theme={logoTheme}
                    size="sm"
                  />
                  <span
                    className={`text-xs ${
                      logoTheme === 'light' ? 'text-slate-500' : 'text-slate-400'
                    }`}
                  >
                    Legível até 24px
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Anatomia dos Nós do Símbolo */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4">
          <div className="p-4 rounded-xl bg-white border border-slate-200 flex items-center gap-3">
            <div className="w-4 h-4 rounded-full border-2 border-[#FE7001] bg-[#FE7001]/10 shrink-0" />
            <div>
              <span className="text-xs font-bold text-[#FE7001] uppercase">Nó Superior (#FE7001)</span>
              <p className="text-xs text-slate-500">Ação, conversão e dinamismo operacional.</p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-white border border-slate-200 flex items-center gap-3">
            <div className="w-4 h-4 rounded-full border-2 border-[#2CBEBF] bg-[#2CBEBF]/10 shrink-0" />
            <div>
              <span className="text-xs font-bold text-[#169495] uppercase">Nó Central (#2CBEBF)</span>
              <p className="text-xs text-slate-500">Conectividade e inteligência analítica de dados.</p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-white border border-slate-200 flex items-center gap-3">
            <div className="w-4 h-4 rounded-full border-2 border-[#002B58] bg-[#002B58]/10 shrink-0" />
            <div>
              <span className="text-xs font-bold text-[#002B58] uppercase">Nó Inferior (#002B58)</span>
              <p className="text-xs text-slate-500">Sólida infraestrutura, segurança e confiabilidade.</p>
            </div>
          </div>
        </div>
      </div>

      {/* 2. As 4 Verticais & Pilares Oficiais */}
      <div>
        <div className="mb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#169495]">
            Arquitetura de Serviços da Marca
          </span>
          <h3
            className="text-2xl font-bold text-[#002B58] mt-1"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Os 4 Módulos de Atuação MAVITH
          </h3>
          <p className="text-sm text-slate-500 mt-1">
            Cada vertical responde a um estágio de maturidade digital da pequena e média empresa.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Sites */}
          <Card variant="elevated" accent="blue" padding="md" className="flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#EBF6FC] text-[#002B58] flex items-center justify-center mb-4">
                <Code2 className="w-6 h-6 text-[#002B58]" />
              </div>
              <span className="text-xs font-mono font-bold text-slate-400">01</span>
              <h4 className="text-lg font-bold text-[#002B58] mt-1">Sites & Portais</h4>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Presença institucional de alta autoridade, páginas de conversão e portais corporativos rápidos e responsivos.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-medium">
              <span>Posicionamento</span>
              <Badge variant="blue" size="sm">Conversão</Badge>
            </div>
          </Card>

          {/* Sistemas */}
          <Card variant="elevated" accent="turquoise" padding="md" className="flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#E2F8F8] text-[#169495] flex items-center justify-center mb-4">
                <Database className="w-6 h-6 text-[#2CBEBF]" />
              </div>
              <span className="text-xs font-mono font-bold text-slate-400">02</span>
              <h4 className="text-lg font-bold text-[#002B58] mt-1">Sistemas & Plataformas</h4>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Gestão operacional sob medida que substitui planilhas confusas por bancos de dados seguros e acessíveis de qualquer lugar.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-medium">
              <span>Operação</span>
              <Badge variant="turquoise" size="sm">Eficiência</Badge>
            </div>
          </Card>

          {/* Agentes de IA */}
          <Card variant="elevated" accent="orange" padding="md" className="flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#FFF2E7] text-[#FE7001] flex items-center justify-center mb-4">
                <Bot className="w-6 h-6 text-[#FE7001]" />
              </div>
              <span className="text-xs font-mono font-bold text-slate-400">03</span>
              <h4 className="text-lg font-bold text-[#002B58] mt-1">Agentes de IA & Automação</h4>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Assistentes virtuais e fluxos automáticos que atendem clientes, qualificam leads e executam rotinas sem intervenção manual.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-medium">
              <span>Inteligência</span>
              <Badge variant="orange" size="sm">Escala</Badge>
            </div>
          </Card>

          {/* Dashboards */}
          <Card variant="elevated" accent="blue" padding="md" className="flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#EBF6FC] text-[#002B58] flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-[#002B58]" />
              </div>
              <span className="text-xs font-mono font-bold text-slate-400">04</span>
              <h4 className="text-lg font-bold text-[#002B58] mt-1">Dashboards & BI</h4>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Painéis analíticos visuais para o gestor visualizar indicadores diários de lucro, vendas e estoque em tempo real.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-medium">
              <span>Decisão</span>
              <Badge variant="blue" size="sm">Visibilidade</Badge>
            </div>
          </Card>
        </div>

        {/* Pilares Institucionais da Base do Logo */}
        <div className="mt-6 p-4 rounded-xl bg-slate-100/70 border border-slate-200 flex flex-wrap items-center justify-around gap-4 text-center">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#2CBEBF]" />
            <span className="text-xs font-bold tracking-widest text-[#002B58] uppercase">
              INOVAÇÃO
            </span>
          </div>
          <span className="w-1.5 h-1.5 rounded-full bg-[#2CBEBF]" />
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#002B58]" />
            <span className="text-xs font-bold tracking-widest text-[#002B58] uppercase">
              INTELIGÊNCIA ANALÍTICA
            </span>
          </div>
          <span className="w-1.5 h-1.5 rounded-full bg-[#2CBEBF]" />
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#FE7001]" />
            <span className="text-xs font-bold tracking-widest text-[#002B58] uppercase">
              CONFIABILIDADE
            </span>
          </div>
        </div>
      </div>

      {/* 3. Paleta Cromática Completa */}
      <div>
        <div className="mb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#FE7001]">
            Sistema Cromático
          </span>
          <h3
            className="text-2xl font-bold text-[#002B58] mt-1"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Paleta de Cores Oficiais & Tokens
          </h3>
          <p className="text-sm text-slate-500 mt-1">
            Cores principais extraídas da logomarca oficial com papéis funcionais rigorosamente definidos.
            Clique para copiar qualquer valor HEX.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {COLOR_TOKENS.map((c) => {
            const isCopied = copiedHex === c.hex;
            return (
              <div
                key={c.name}
                onClick={() => copyToClipboard(c.hex)}
                className="group relative rounded-xl border border-slate-200 bg-white overflow-hidden shadow-xs hover:shadow-md transition-all cursor-pointer select-none"
              >
                {/* Color Swatch */}
                <div
                  className="h-24 w-full p-3 flex flex-col justify-between transition-transform group-hover:scale-[1.02]"
                  style={{ backgroundColor: c.hex, color: c.textColor }}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-black/20 text-white backdrop-blur-xs">
                      {c.category}
                    </span>
                    <button
                      type="button"
                      className="p-1 rounded bg-black/20 text-white hover:bg-black/40 transition-colors"
                      title="Copiar HEX"
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5 text-green-300" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  <span className="text-sm font-mono font-bold tracking-wider">
                    {c.hex}
                  </span>
                </div>

                {/* Details */}
                <div className="p-4">
                  <div className="flex items-center justify-between">
                    <h5 className="text-sm font-bold text-[#002B58]">{c.name}</h5>
                    {isCopied && (
                      <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                        Copiado!
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                    {c.role}
                  </p>
                  <div className="mt-3 pt-2 border-t border-slate-100 text-[11px] text-slate-400 font-medium">
                    {c.contrastNotice}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Tipografia & Escala */}
      <div>
        <div className="mb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#002B58]">
            Hierarquia Tipográfica
          </span>
          <h3
            className="text-2xl font-bold text-[#002B58] mt-1"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Escala Tipográfica Oficial
          </h3>
          <p className="text-sm text-slate-500 mt-1">
            Combinação institucional de Plus Jakarta Sans (títulos modernos com solidez geométrica)
            e Inter (leitura técnica fluida para pequenos empresários).
          </p>
        </div>

        <Card variant="outline" padding="lg" className="space-y-6 bg-white">
          <div className="border-b border-slate-100 pb-4 flex flex-col md:flex-row md:items-baseline justify-between gap-2">
            <span className="text-xs font-mono text-slate-400 uppercase w-28 shrink-0">H1 Display</span>
            <div className="flex-1">
              <h1
                className="text-3xl sm:text-4xl font-extrabold text-[#002B58] tracking-tight"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
              >
                Tecnologia com propósito para pequenos negócios.
              </h1>
            </div>
            <span className="text-xs font-mono text-slate-400 shrink-0">40px / 800</span>
          </div>

          <div className="border-b border-slate-100 pb-4 flex flex-col md:flex-row md:items-baseline justify-between gap-2">
            <span className="text-xs font-mono text-slate-400 uppercase w-28 shrink-0">H2 Seção</span>
            <div className="flex-1">
              <h2
                className="text-2xl sm:text-3xl font-bold text-[#002B58] tracking-tight"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
              >
                Transformamos gargalos manuais em processos digitais automáticos.
              </h2>
            </div>
            <span className="text-xs font-mono text-slate-400 shrink-0">32px / 700</span>
          </div>

          <div className="border-b border-slate-100 pb-4 flex flex-col md:flex-row md:items-baseline justify-between gap-2">
            <span className="text-xs font-mono text-slate-400 uppercase w-28 shrink-0">H3 Bloco</span>
            <div className="flex-1">
              <h3
                className="text-xl font-bold text-[#002B58]"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
              >
                Painéis analíticos e tomada de decisão embasada em dados.
              </h3>
            </div>
            <span className="text-xs font-mono text-slate-400 shrink-0">24px / 600</span>
          </div>

          <div className="border-b border-slate-100 pb-4 flex flex-col md:flex-row md:items-baseline justify-between gap-2">
            <span className="text-xs font-mono text-slate-400 uppercase w-28 shrink-0">Body Principal</span>
            <div className="flex-1">
              <p className="text-base text-slate-700 leading-relaxed max-w-2xl font-normal">
                Nosso trabalho começa na escuta atenta do seu negócio. Não empurramos softwares
                genéricos. Cada linha de código e fluxo de inteligência tem um propósito
                claro: gerar eficiência e lucro real para a sua empresa.
              </p>
            </div>
            <span className="text-xs font-mono text-slate-400 shrink-0">16px / 400</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-baseline justify-between gap-2">
            <span className="text-xs font-mono text-slate-400 uppercase w-28 shrink-0">Caption & Botão</span>
            <div className="flex-1 flex flex-wrap items-center gap-4">
              <span className="text-xs font-bold uppercase tracking-wider text-[#2CBEBF]">
                DIAGNÓSTICO INICIAL DISPONÍVEL
              </span>
              <Button variant="primary-orange" size="sm">
                Fale com a MAVITH
              </Button>
              <Button variant="secondary" size="sm">
                Conhecer Soluções
              </Button>
            </div>
            <span className="text-xs font-mono text-slate-400 shrink-0">12px / 14px</span>
          </div>
        </Card>
      </div>
    </div>
  );
};
