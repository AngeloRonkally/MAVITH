import React, { useState, useEffect } from 'react';
import { Header } from './design-system/components/Header';
import { Footer } from './design-system/components/Footer';
import { Modal } from './design-system/components/Modal';
import { Button } from './design-system/components/Button';
import { Input, Textarea, Select } from './design-system/components/Input';
import { Badge } from './design-system/components/Badge';

// Home Sections (Phase 2)
import { HomeHero } from './components/home/HomeHero';
import { EvolutionSection } from './components/home/EvolutionSection';
import { BrandTransitionSection } from './components/home/BrandTransitionSection';
import { ProblemsSection } from './components/home/ProblemsSection';
import { SolutionsSection } from './components/home/SolutionsSection';
import { PortfolioPreviewSection } from './components/home/PortfolioPreviewSection';
import { ProcessSection } from './components/home/ProcessSection';
import { DifferentialsSection } from './components/home/DifferentialsSection';
import { AboutSection } from './components/home/AboutSection';
import { FinalCTASection } from './components/home/FinalCTASection';

// Portfolio & Cases (Phase 3)
import { PortfolioPage } from './components/portfolio/PortfolioPage';
import { ProjectDetailPage } from './components/portfolio/ProjectDetailPage';
import { getProjectBySlug } from './data/portfolioData';

// Solutions (Phase 4)
import { SolutionsHubPage } from './components/solutions/SolutionsHubPage';
import { SolutionDetailPage } from './components/solutions/SolutionDetailPage';
import { getSolutionBySlug } from './data/solutionsData';
import { SolutionSlug } from './types/solutions';

// Authority, Insights & Demos (Phase 5)
import { InsightsHubPage } from './components/insights/InsightsHubPage';
import { ArticleDetailPage } from './components/insights/ArticleDetailPage';
import { getArticleBySlug } from './data/insightsData';
import { DemonstrationsHubPage } from './components/demonstrations/DemonstrationsHubPage';
import { AuthoritySection } from './components/authority/AuthoritySection';
import { InsightsPreviewSection } from './components/home/InsightsPreviewSection';
import { SitemapModal } from './components/seo/SitemapModal';
import { SEOHead } from './components/seo/SEOHead';

// Design System Inspector (Phase 1 Assets)
import { StrategicNarrative } from './components/StrategicNarrative';
import { BrandIdentityShowcase } from './components/BrandIdentityShowcase';
import { ComponentLibraryShowcase } from './components/ComponentLibraryShowcase';
import { TokensViewer } from './components/TokensViewer';

// Conversion & Leads (Phase 6)
import { LeadConversionModal } from './components/conversion/LeadConversionModal';
import { WhatsAppFloatingButton } from './components/conversion/WhatsAppFloatingButton';
import { CRMAnalyticsInspectorModal } from './components/conversion/CRMAnalyticsInspectorModal';
import { analytics } from './services/analytics';

import {
  Send,
  CheckCircle,
  Building,
  Palette,
  Component,
  FileCode,
  Layers,
  X,
  Activity,
} from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<
    | 'home'
    | 'portfolio'
    | 'project-detail'
    | 'solutions'
    | 'solution-detail'
    | 'insights'
    | 'article-detail'
    | 'demonstracoes'
  >('home');
  const [currentProjectSlug, setCurrentProjectSlug] = useState<string | null>(null);
  const [currentSolutionSlug, setCurrentSolutionSlug] = useState<SolutionSlug | null>(null);
  const [currentArticleSlug, setCurrentArticleSlug] = useState<string | null>(null);

  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [isDesignSystemModalOpen, setIsDesignSystemModalOpen] = useState(false);
  const [isSitemapModalOpen, setIsSitemapModalOpen] = useState(false);
  const [isCrmModalOpen, setIsCrmModalOpen] = useState(false);
  const [selectedSolutionInterest, setSelectedSolutionInterest] = useState('diagnostico');
  const [contactSourceLocation, setContactSourceLocation] = useState('home');
  const [contactSubmitted, setContactSubmitted] = useState(false);
  const [activeDesignSystemTab, setActiveDesignSystemTab] = useState<
    'estrategia' | 'identidade' | 'componentes' | 'tokens'
  >('identidade');

  // Track page views and content views for conversion analytics
  useEffect(() => {
    if (currentView === 'portfolio') {
      analytics.trackPortfolioViewed('hub');
    } else if (currentView === 'project-detail' && currentProjectSlug) {
      analytics.trackPortfolioViewed(currentProjectSlug);
    } else if (currentView === 'solutions') {
      analytics.trackServiceViewed('hub');
    } else if (currentView === 'solution-detail' && currentSolutionSlug) {
      analytics.trackServiceViewed(currentSolutionSlug);
    } else if (currentView === 'insights') {
      analytics.trackArticleViewed('hub');
    } else if (currentView === 'article-detail' && currentArticleSlug) {
      analytics.trackArticleViewed(currentArticleSlug);
    }
  }, [currentView, currentProjectSlug, currentSolutionSlug, currentArticleSlug]);

  // Parse URL hash for seamless deep-linking (#/insights, #/insights/:slug, #/demonstracoes, #/solucoes, #/portfolio)
  useEffect(() => {
    const handleLocationChange = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#/insights/') && hash.length > '#/insights/'.length) {
        const slug = hash.replace('#/insights/', '').trim();
        setCurrentArticleSlug(slug);
        setCurrentView('article-detail');
      } else if (hash === '#/insights' || hash === '#insights') {
        setCurrentView('insights');
        setCurrentArticleSlug(null);
      } else if (hash === '#/demonstracoes' || hash === '#demonstracoes') {
        setCurrentView('demonstracoes');
      } else if (hash.startsWith('#/solucoes/') && hash.length > '#/solucoes/'.length) {
        const slug = hash.replace('#/solucoes/', '').trim() as SolutionSlug;
        setCurrentSolutionSlug(slug);
        setCurrentView('solution-detail');
      } else if (hash === '#/solucoes' || hash === '#solucoes') {
        setCurrentView('solutions');
        setCurrentSolutionSlug(null);
      } else if (hash.startsWith('#/portfolio/') && hash.length > '#/portfolio/'.length) {
        const slug = hash.replace('#/portfolio/', '').trim();
        setCurrentProjectSlug(slug);
        setCurrentView('project-detail');
      } else if (hash === '#/portfolio' || hash === '#portfolio') {
        setCurrentView('portfolio');
        setCurrentProjectSlug(null);
      } else if (hash === '#/sitemap' || hash === '#sitemap') {
        setIsSitemapModalOpen(true);
      } else {
        setCurrentView('home');
        setCurrentProjectSlug(null);
        setCurrentSolutionSlug(null);
        setCurrentArticleSlug(null);
      }
    };

    handleLocationChange();
    window.addEventListener('hashchange', handleLocationChange);
    return () => window.removeEventListener('hashchange', handleLocationChange);
  }, []);

  const handleOpenContact = (interest = 'diagnostico', source = 'global') => {
    setSelectedSolutionInterest(interest);
    setContactSourceLocation(source);
    analytics.trackCtaClick(interest, source);
    setIsContactModalOpen(true);
  };

  const handleSelectProject = (slug: string) => {
    setCurrentProjectSlug(slug);
    setCurrentView('project-detail');
    window.location.hash = `#/portfolio/${slug}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGoToPortfolio = () => {
    setCurrentView('portfolio');
    setCurrentProjectSlug(null);
    window.location.hash = '#/portfolio';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGoToSolutions = () => {
    setCurrentView('solutions');
    setCurrentSolutionSlug(null);
    window.location.hash = '#/solucoes';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectSolution = (slug: SolutionSlug) => {
    setCurrentSolutionSlug(slug);
    setCurrentView('solution-detail');
    window.location.hash = `#/solucoes/${slug}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGoToInsights = () => {
    setCurrentView('insights');
    setCurrentArticleSlug(null);
    window.location.hash = '#/insights';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectArticle = (slug: string) => {
    setCurrentArticleSlug(slug);
    setCurrentView('article-detail');
    window.location.hash = `#/insights/${slug}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGoToDemos = () => {
    setCurrentView('demonstracoes');
    window.location.hash = '#/demonstracoes';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGoToHome = () => {
    setCurrentView('home');
    setCurrentProjectSlug(null);
    setCurrentSolutionSlug(null);
    setCurrentArticleSlug(null);
    window.location.hash = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateByUrl = (url: string) => {
    if (url === '/') {
      handleGoToHome();
    } else if (url === '/solucoes') {
      handleGoToSolutions();
    } else if (url.startsWith('/solucoes/')) {
      const slug = url.replace('/solucoes/', '') as SolutionSlug;
      handleSelectSolution(slug);
    } else if (url === '/portfolio') {
      handleGoToPortfolio();
    } else if (url.startsWith('/portfolio/')) {
      const slug = url.replace('/portfolio/', '');
      handleSelectProject(slug);
    } else if (url === '/insights') {
      handleGoToInsights();
    } else if (url.startsWith('/insights/')) {
      const slug = url.replace('/insights/', '');
      handleSelectArticle(slug);
    } else if (url === '/demonstracoes') {
      handleGoToDemos();
    }
  };

  const handleNavigate = (item: string) => {
    if (item === 'Início') {
      handleGoToHome();
      return;
    }
    if (item === 'Portfólio') {
      handleGoToPortfolio();
      return;
    }
    if (item === 'Soluções') {
      handleGoToSolutions();
      return;
    }
    if (item.startsWith('solucoes/')) {
      const slug = item.replace('solucoes/', '') as SolutionSlug;
      handleSelectSolution(slug);
      return;
    }
    if (item === 'Como fazemos') {
      if (currentView !== 'home') {
        handleGoToHome();
        setTimeout(() => {
          const el = document.getElementById('processo');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        const el = document.getElementById('processo');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }
      return;
    }
    if (item === 'Sobre') {
      if (currentView !== 'home') {
        handleGoToHome();
        setTimeout(() => {
          const el = document.getElementById('sobre');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        const el = document.getElementById('sobre');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }
      return;
    }
    if (item === 'Insights') {
      handleGoToInsights();
      return;
    }
    if (item === 'Demonstrações') {
      handleGoToDemos();
      return;
    }
    if (item === 'Sitemap') {
      setIsSitemapModalOpen(true);
      return;
    }
    if (item === 'Contato') {
      handleOpenContact();
      return;
    }
  };

  const activeProject = currentProjectSlug ? getProjectBySlug(currentProjectSlug) : undefined;
  const activeSolution = currentSolutionSlug ? getSolutionBySlug(currentSolutionSlug) : undefined;
  const activeArticle = currentArticleSlug ? getArticleBySlug(currentArticleSlug) : undefined;

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900 selection:bg-[#2CBEBF]/30 selection:text-[#002B58]">
      {/* Top Phase Notice Bar with Quick Access to Design System Inspector & Demonstrations */}
      <aside
        aria-label="Status do Projeto"
        className="bg-[#001C3B] text-white py-2 px-4 border-b border-slate-800 text-xs select-none sticky top-0 z-40"
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#FE7001] animate-pulse" />
            <span className="font-bold text-[#FE7001] tracking-wider uppercase text-[11px]">
              MAVITH
            </span>
            <span className="text-slate-400">•</span>
            <span className="text-slate-200 text-[11px] sm:text-xs">
              Tecnologia com propósito.
            </span>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 overflow-x-auto scrollbar-none">
            <button
              type="button"
              onClick={() => setIsCrmModalOpen(true)}
              className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400 hover:text-white bg-emerald-500/10 hover:bg-emerald-500/20 px-2.5 py-1 rounded-md transition-colors cursor-pointer border border-emerald-500/30 whitespace-nowrap"
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Console CRM & Leads</span>
            </button>
            <button
              type="button"
              onClick={handleGoToDemos}
              className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#FE7001] hover:text-white bg-white/5 hover:bg-white/10 px-2.5 py-1 rounded-md transition-colors cursor-pointer border border-[#FE7001]/30 whitespace-nowrap"
            >
              <span>Demonstrações Interativas</span>
            </button>
            <button
              type="button"
              onClick={handleGoToInsights}
              className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#2CBEBF] hover:text-white bg-white/5 hover:bg-white/10 px-2.5 py-1 rounded-md transition-colors cursor-pointer border border-[#2CBEBF]/30 whitespace-nowrap"
            >
              <span>Insights & Artigos</span>
            </button>
            <button
              type="button"
              onClick={() => setIsDesignSystemModalOpen(true)}
              className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 px-2.5 py-1 rounded-md transition-colors cursor-pointer border border-slate-700 whitespace-nowrap"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Design System</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Official Institutional Header */}
      <Header
        activeItem={
          currentView === 'home'
            ? 'Início'
            : currentView === 'portfolio' || currentView === 'project-detail'
            ? 'Portfólio'
            : currentView === 'solutions' || currentView === 'solution-detail'
            ? 'Soluções'
            : currentView === 'insights' || currentView === 'article-detail' || currentView === 'demonstracoes'
            ? 'Insights'
            : 'Início'
        }
        onNavigate={handleNavigate}
        onCtaClick={() => handleOpenContact('diagnostico')}
      />

      {/* Dynamic View Rendering */}
      <main className="flex-1">
        {currentView === 'portfolio' ? (
          <PortfolioPage
            onSelectProject={handleSelectProject}
            onOpenContactModal={handleOpenContact}
          />
        ) : currentView === 'project-detail' && activeProject ? (
          <ProjectDetailPage
            project={activeProject}
            onBackToPortfolio={handleGoToPortfolio}
            onSelectAnotherProject={handleSelectProject}
            onOpenContactModal={handleOpenContact}
          />
        ) : currentView === 'solutions' ? (
          <SolutionsHubPage
            onSelectSolution={handleSelectSolution}
            onOpenContactModal={handleOpenContact}
          />
        ) : currentView === 'solution-detail' && activeSolution ? (
          <SolutionDetailPage
            solution={activeSolution}
            onBackToSolutions={handleGoToSolutions}
            onSelectAnotherSolution={handleSelectSolution}
            onSelectProject={handleSelectProject}
            onOpenContactModal={handleOpenContact}
          />
        ) : currentView === 'insights' ? (
          <InsightsHubPage
            onSelectArticle={handleSelectArticle}
            onOpenDemos={handleGoToDemos}
            onOpenContactModal={handleOpenContact}
          />
        ) : currentView === 'article-detail' && activeArticle ? (
          <ArticleDetailPage
            article={activeArticle}
            onBackToInsights={handleGoToInsights}
            onSelectArticle={handleSelectArticle}
            onOpenContactModal={handleOpenContact}
            onNavigateToSolution={(slug) => handleSelectSolution(slug as SolutionSlug)}
          />
        ) : currentView === 'demonstracoes' ? (
          <DemonstrationsHubPage
            onBackToHome={handleGoToHome}
            onOpenContactModal={handleOpenContact}
          />
        ) : (
          /* Main Home Narrative Flow (Phase 2) */
          <>
            {/* 1. Hero */}
            <HomeHero
              onPrimaryCta={() => handleOpenContact('diagnostico', 'home_hero')}
              onSecondaryCta={() => {
                const el = document.getElementById('solucoes');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
            />

            {/* 2. Seção de Evolução */}
            <EvolutionSection />

            {/* 3. Momento de Transição */}
            <BrandTransitionSection />

            {/* 4. Problemas & Reconhecimento */}
            <ProblemsSection
              onCtaClick={() => handleOpenContact('gargalos-operacionais', 'home_problems')}
            />

            {/* 5. Soluções Conectadas aos Problemas */}
            <SolutionsSection
              onSelectSolution={(sol) => handleOpenContact(sol, 'home_solutions_cards')}
              onExploreSolutionPage={handleSelectSolution}
              onGoToSolutionsHub={handleGoToSolutions}
              onConsultClick={(sol) => handleOpenContact(sol || 'solucoes', 'home_solutions_banner')}
            />

            {/* 6. Portfólio Preview: Casos de Transformação */}
            <div id="portfolio">
              <PortfolioPreviewSection
                onContactClick={() => handleOpenContact('diagnostico', 'home_portfolio')}
                onViewAllProjects={handleGoToPortfolio}
                onSelectProject={handleSelectProject}
              />
            </div>

            {/* 7. Seção de Autoridade & Princípios Tecnológicos */}
            <section className="py-16 bg-white border-t border-slate-200">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <AuthoritySection
                  onOpenDemos={handleGoToDemos}
                  onOpenContactModal={(interest) => handleOpenContact(interest || 'autoridade', 'home_authority')}
                />
              </div>
            </section>

            {/* 8. Metodologia / Processo */}
            <ProcessSection />

            {/* 9. Diferenciais */}
            <DifferentialsSection />

            {/* 10. Filosofia da Empresa */}
            <AboutSection />

            {/* 11. Insights & Conhecimento Estratégico Preview */}
            <InsightsPreviewSection
              onViewAllInsights={handleGoToInsights}
              onSelectArticle={handleSelectArticle}
              onOpenDemos={handleGoToDemos}
            />

            {/* 12. CTA Final */}
            <FinalCTASection
              onContactClick={() => handleOpenContact('diagnostico', 'home_final_cta')}
            />
          </>
        )}
      </main>

      {/* Official Institutional Footer */}
      <Footer
        onLinkClick={(link) => {
          if (link === 'Design System') {
            setIsDesignSystemModalOpen(true);
          } else if (link === 'Início') {
            handleGoToHome();
          } else if (link === 'Soluções') {
            handleGoToSolutions();
          } else if (link === 'Sites') {
            handleSelectSolution('sites');
          } else if (link === 'Sistemas') {
            handleSelectSolution('sistemas');
          } else if (link === 'Agentes de IA') {
            handleSelectSolution('ia');
          } else if (link === 'Automação' || link === 'Integrações') {
            handleSelectSolution('automacao');
          } else if (link === 'Dashboards') {
            handleSelectSolution('dashboards');
          } else if (link === 'Portfólio') {
            handleGoToPortfolio();
          } else if (link === 'Insights' || link === 'Insights & Artigos') {
            handleGoToInsights();
          } else if (link === 'Demonstrações' || link === 'Demonstrações Interativas') {
            handleGoToDemos();
          } else if (link === 'Sitemap' || link === 'Mapa do Site & SEO XML') {
            setIsSitemapModalOpen(true);
          } else if (link === 'Como fazemos') {
            handleNavigate('Como fazemos');
          } else if (link === 'CRM' || link === 'Leads' || link.includes('CRM') || link.includes('Console')) {
            setIsCrmModalOpen(true);
          } else if (link === 'Sobre a MAVITH' || link === 'Sobre') {
            handleNavigate('Sobre');
          } else {
            handleOpenContact(link, 'footer');
          }
        }}
      />

      {/* Official Lead Conversion Modal (Fase 6) */}
      <LeadConversionModal
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
        initialInterest={selectedSolutionInterest}
        sourceLocation={contactSourceLocation}
      />

      {/* Internal CRM & Analytics Inspector (Fase 6 Live Debugger) */}
      <CRMAnalyticsInspectorModal
        isOpen={isCrmModalOpen}
        onClose={() => setIsCrmModalOpen(false)}
      />

      {/* Global WhatsApp Floating Action Button (Fase 6) */}
      <WhatsAppFloatingButton sourceLocation={currentView} />

      {/* Design System Foundation Modal (Fase 1 Reference) */}
      <Modal
        isOpen={isDesignSystemModalOpen}
        onClose={() => setIsDesignSystemModalOpen(false)}
        title="Fundação da Marca & Design System MAVITH (Fase 1)"
        description="Consulta técnica dos tokens, componentes, cores e narrativa estabelecidos."
        maxWidth="max-w-5xl"
        footer={
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setIsDesignSystemModalOpen(false)}
          >
            Fechar Inspetor
          </Button>
        }
      >
        <div className="space-y-6">
          {/* Sub Navigation */}
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3 overflow-x-auto">
            <button
              type="button"
              onClick={() => setActiveDesignSystemTab('identidade')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeDesignSystemTab === 'identidade'
                  ? 'bg-[#002B58] text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              <span>Identidade & Cores</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveDesignSystemTab('estrategia')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeDesignSystemTab === 'estrategia'
                  ? 'bg-[#002B58] text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Building className="w-3.5 h-3.5" />
              <span>Narrativa da Marca</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveDesignSystemTab('componentes')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeDesignSystemTab === 'componentes'
                  ? 'bg-[#002B58] text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Component className="w-3.5 h-3.5" />
              <span>Biblioteca de Componentes</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveDesignSystemTab('tokens')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeDesignSystemTab === 'tokens'
                  ? 'bg-[#002B58] text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Design Tokens (JSON)</span>
            </button>
          </div>

          {/* Sub Content */}
          <div className="max-h-[60vh] overflow-y-auto pr-1">
            {activeDesignSystemTab === 'identidade' && <BrandIdentityShowcase />}
            {activeDesignSystemTab === 'estrategia' && (
              <StrategicNarrative onConsultClick={() => handleOpenContact('diagnostico')} />
            )}
            {activeDesignSystemTab === 'componentes' && <ComponentLibraryShowcase />}
            {activeDesignSystemTab === 'tokens' && <TokensViewer />}
          </div>
        </div>
      </Modal>

      {/* SEO Sitemap & Canonical URL Explorer Modal */}
      <SitemapModal
        isOpen={isSitemapModalOpen}
        onClose={() => setIsSitemapModalOpen(false)}
        onNavigateTo={handleNavigateByUrl}
      />
    </div>
  );
}
