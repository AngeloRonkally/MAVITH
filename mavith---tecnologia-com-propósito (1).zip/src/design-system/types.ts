/**
 * MAVITH Design System Component Types
 */

import { ReactNode, ButtonHTMLAttributes, InputHTMLAttributes, TextareaHTMLAttributes, SelectHTMLAttributes } from 'react';

export type ButtonVariant = 'primary-blue' | 'primary-orange' | 'secondary' | 'ghost' | 'outline-white';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  isLoading?: boolean;
  fullWidth?: boolean;
  children: ReactNode;
}

export type BadgeVariant = 'turquoise' | 'blue' | 'orange' | 'neutral' | 'outline';
export type BadgeSize = 'sm' | 'md';

export interface BadgeProps {
  variant?: BadgeVariant;
  size?: BadgeSize;
  icon?: ReactNode;
  children: ReactNode;
  className?: string;
}

export interface TagProps {
  label: string;
  active?: boolean;
  onClick?: () => void;
  onRemove?: () => void;
  color?: 'blue' | 'turquoise' | 'orange' | 'neutral';
  className?: string;
}

export interface CardProps {
  children: ReactNode;
  className?: string;
  variant?: 'elevated' | 'outline' | 'flat' | 'dark' | 'circuit';
  padding?: 'none' | 'sm' | 'md' | 'lg';
  hoverable?: boolean;
  accent?: 'none' | 'blue' | 'turquoise' | 'orange';
  id?: string;
  onClick?: () => void;
}

export interface SectionProps {
  children: ReactNode;
  className?: string;
  id?: string;
  background?: 'white' | 'neutral' | 'blue' | 'dark' | 'circuit';
  spacing?: 'compact' | 'normal' | 'generous';
}

export interface SectionTitleProps {
  badge?: string;
  title: string;
  highlightText?: string;
  description?: string;
  align?: 'left' | 'center';
  dark?: boolean;
  className?: string;
}

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  id: string;
}

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  helperText?: string;
  id: string;
}

export interface SelectOption {
  value: string;
  label: string;
}

export interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  options: SelectOption[];
  error?: string;
  helperText?: string;
  id: string;
}

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  maxWidth?: string;
}

export interface LogoProps {
  variant?: 'full' | 'compact' | 'symbol';
  theme?: 'light' | 'dark';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showSlogan?: boolean;
}
