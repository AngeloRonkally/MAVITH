import React from 'react';
import { MavithLogo } from './MavithLogo';
import { Mail, Phone, MapPin, Linkedin, Instagram, Github, ArrowUpRight } from 'lucide-react';

interface FooterProps {
  onLinkClick?: (link: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onLinkClick }) => {
  const handleClick = (e: React.MouseEvent, label: string) => {
    e.preventDefault();
    if (onLinkClick) {
      onLinkClick(label);
    }
  };

  return (
    <footer className="bg-[#001C3B] text-white border-t border-slate-800 relative overflow-hidden">
      {/* Decorative top gradient border */}
      <div className="h-1 w-full bg-gradient-to-r from-[#002B58] via-[#2CBEBF] to-[#FE7001]" />

      {/* Subtle circuit pattern overlay */}
      <div className="absolute inset-0 bg-circuit-dark opacity-30 pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-8 pb-12 border-b border-slate-800">
          {/* Column 1: Brand & Slogan (2 cols wide on LG) */}
          <div className="lg:col-span-2 flex flex-col items-start pr-4">
            <MavithLogo variant="full" theme="dark" size="lg" />

            <p className="mt-5 text-sm text-slate-300 leading-relaxed max-w-sm">
              Transformamos problemas reais de negócios em soluções digitais inteligentes.
              Estratégia, inteligência e tecnologia focadas em pequenas e médias empresas.
            </p>

            <div className="mt-6 flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-[#2CBEBF]" />
              <span className="text-xs font-semibold uppercase tracking-wider text-[#2CBEBF]">
                Tecnologia com propósito.
              </span>
            </div>

            {/* Social Links */}
            <div className="mt-6 flex items-center gap-3">
              <a
                href="#linkedin"
                onClick={(e) => handleClick(e, 'LinkedIn')}
                className="w-9 h-9 rounded-lg bg-[#002B58] hover:bg-[#2CBEBF] hover:text-[#002B58] text-slate-300 flex items-center justify-center transition-colors duration-200"
                aria-label="LinkedIn MAVITH"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href="#instagram"
                onClick={(e) => handleClick(e, 'Instagram')}
                className="w-9 h-9 rounded-lg bg-[#002B58] hover:bg-[#FE7001] text-slate-300 flex items-center justify-center transition-colors duration-200"
                aria-label="Instagram MAVITH"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="#github"
                onClick={(e) => handleClick(e, 'GitHub')}
                className="w-9 h-9 rounded-lg bg-[#002B58] hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors duration-200"
                aria-label="GitHub MAVITH"
              >
                <Github className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: Soluções */}
          <div>
            <h4
              className="text-xs font-bold uppercase tracking-wider text-[#2CBEBF] mb-4"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Soluções
            </h4>
            <ul className="space-y-2.5 text-sm text-slate-300">
              <li>
                <a
                  href="#sites"
                  onClick={(e) => handleClick(e, 'Sites')}
                  className="hover:text-white transition-colors flex items-center gap-1 group"
                >
                  <span>Sites & Portais</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-[#2CBEBF]" />
                </a>
              </li>
              <li>
                <a
                  href="#sistemas"
                  onClick={(e) => handleClick(e, 'Sistemas')}
                  className="hover:text-white transition-colors flex items-center gap-1 group"
                >
                  <span>Sistemas & Plataformas</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-[#2CBEBF]" />
                </a>
              </li>
              <li>
                <a
                  href="#agentes-ia"
                  onClick={(e) => handleClick(e, 'Agentes de IA')}
                  className="hover:text-white transition-colors flex items-center gap-1 group"
                >
                  <span>Agentes de IA & Automação</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-[#2CBEBF]" />
                </a>
              </li>
              <li>
                <a
                  href="#dashboards"
                  onClick={(e) => handleClick(e, 'Dashboards')}
                  className="hover:text-white transition-colors flex items-center gap-1 group"
                >
                  <span>Dashboards & BI</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-[#2CBEBF]" />
                </a>
              </li>
              <li>
                <a
                  href="#integracoes"
                  onClick={(e) => handleClick(e, 'Integrações')}
                  className="hover:text-white transition-colors flex items-center gap-1 group"
                >
                  <span>Integrações de Software</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-[#2CBEBF]" />
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Empresa */}
          <div>
            <h4
              className="text-xs font-bold uppercase tracking-wider text-[#2CBEBF] mb-4"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Institucional
            </h4>
            <ul className="space-y-2.5 text-sm text-slate-300">
              <li>
                <a
                  href="#sobre"
                  onClick={(e) => handleClick(e, 'Sobre')}
                  className="hover:text-white transition-colors"
                >
                  Sobre a MAVITH
                </a>
              </li>
              <li>
                <a
                  href="#como-fazemos"
                  onClick={(e) => handleClick(e, 'Como fazemos')}
                  className="hover:text-white transition-colors"
                >
                  Como Fazemos (Método)
                </a>
              </li>
              <li>
                <a
                  href="#portfolio"
                  onClick={(e) => handleClick(e, 'Portfólio')}
                  className="hover:text-white transition-colors"
                >
                  Portfólio & Cases
                </a>
              </li>
              <li>
                <a
                  href="#insights"
                  onClick={(e) => handleClick(e, 'Insights')}
                  className="hover:text-white transition-colors"
                >
                  Insights & Artigos
                </a>
              </li>
              <li>
                <a
                  href="#demonstracoes"
                  onClick={(e) => handleClick(e, 'Demonstrações')}
                  className="hover:text-white transition-colors text-[#FE7001]"
                >
                  Demonstrações Interativas
                </a>
              </li>
              <li>
                <a
                  href="#crm"
                  onClick={(e) => handleClick(e, 'CRM')}
                  className="hover:text-white transition-colors text-emerald-400 font-semibold"
                >
                  Console CRM & Leads (Fase 6)
                </a>
              </li>
              <li>
                <a
                  href="#sitemap"
                  onClick={(e) => handleClick(e, 'Sitemap')}
                  className="hover:text-white transition-colors text-slate-400"
                >
                  Mapa do Site & SEO XML
                </a>
              </li>
              <li>
                <a
                  href="#design-system"
                  onClick={(e) => handleClick(e, 'Design System')}
                  className="hover:text-white transition-colors text-[#2CBEBF]"
                >
                  Design System (Fase 1)
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: Contato */}
          <div>
            <h4
              className="text-xs font-bold uppercase tracking-wider text-[#2CBEBF] mb-4"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Contato
            </h4>
            <ul className="space-y-3 text-sm text-slate-300">
              <li className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-[#2CBEBF] shrink-0 mt-0.5" />
                <span className="hover:text-white transition-colors select-all">
                  contato@mavith.com.br
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <Phone className="w-4 h-4 text-[#FE7001] shrink-0 mt-0.5" />
                <span className="hover:text-white transition-colors">
                  +55 (11) 98765-4321
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#2CBEBF] shrink-0 mt-0.5" />
                <span className="text-slate-400">
                  Atendimento digital para todo o Brasil
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Legal bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            © {new Date().getFullYear()} MAVITH Soluções Digitais. Todos os direitos reservados.
          </div>

          <div className="flex items-center gap-6">
            <a
              href="#privacidade"
              onClick={(e) => handleClick(e, 'Privacidade')}
              className="hover:text-slate-200 transition-colors"
            >
              Política de Privacidade
            </a>
            <a
              href="#termos"
              onClick={(e) => handleClick(e, 'Termos')}
              className="hover:text-slate-200 transition-colors"
            >
              Termos de Uso
            </a>
            <span className="text-slate-600 hidden md:inline">|</span>
            <span className="text-slate-400 hidden md:inline">
              Fase 1: Fundação da Marca
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
