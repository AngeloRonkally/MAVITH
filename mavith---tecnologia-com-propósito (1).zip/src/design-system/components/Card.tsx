import React from 'react';
import { CardProps } from '../types';

/**
 * MAVITH Corporate Premium Card
 * Modern, solid, subtle borders, controlled elevation, optional circuit-connected trim.
 */
export const Card: React.FC<CardProps> = ({
  children,
  className = '',
  variant = 'elevated',
  padding = 'md',
  hoverable = true,
  accent = 'none',
  id,
  onClick,
}) => {
  // Padding math: outer padding >= inner spacing (minimum 16px)
  const paddingClasses = {
    none: 'p-0',
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8',
  };

  const variantClasses = {
    elevated: 'bg-white border border-slate-200/80 shadow-[0_2px_8px_-1px_rgba(0,43,88,0.06)] text-slate-800',
    outline: 'bg-white border border-slate-300 shadow-none text-slate-800',
    flat: 'bg-slate-50/80 border border-slate-200 text-slate-800',
    dark: 'bg-[#002447] border border-slate-700/60 shadow-lg text-white',
    circuit: 'bg-white border border-[#2CBEBF]/30 relative text-slate-800 shadow-sm',
  };

  const accentTopBorders = {
    none: '',
    blue: 'border-t-4 border-t-[#002B58]',
    turquoise: 'border-t-4 border-t-[#2CBEBF]',
    orange: 'border-t-4 border-t-[#FE7001]',
  };

  const hoverClasses = hoverable
    ? 'transition-all duration-200 hover:-translate-y-1 hover:shadow-[0_12px_24px_-8px_rgba(0,43,88,0.12)] hover:border-slate-300'
    : '';

  const clickableClass = onClick ? 'cursor-pointer' : '';

  return (
    <div
      id={id}
      onClick={onClick}
      className={`rounded-xl overflow-hidden ${variantClasses[variant]} ${accentTopBorders[accent]} ${paddingClasses[padding]} ${hoverClasses} ${clickableClass} ${className}`}
    >
      {children}
    </div>
  );
};
