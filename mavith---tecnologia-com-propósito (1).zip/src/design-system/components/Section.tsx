import React from 'react';
import { SectionProps, SectionTitleProps } from '../types';

export const Section: React.FC<SectionProps> = ({
  children,
  className = '',
  id,
  background = 'white',
  spacing = 'normal',
}) => {
  const bgClasses = {
    white: 'bg-white text-slate-900',
    neutral: 'bg-slate-50 text-slate-900 border-y border-slate-200/70',
    blue: 'bg-[#002B58] text-white',
    dark: 'bg-[#001C3B] text-white',
    circuit: 'bg-slate-50 bg-circuit-subtle text-slate-900 border-y border-slate-200',
  };

  const spacingClasses = {
    compact: 'py-10 md:py-14',
    normal: 'py-16 md:py-24',
    generous: 'py-20 md:py-32',
  };

  return (
    <section
      id={id}
      className={`relative w-full ${bgClasses[background]} ${spacingClasses[spacing]} ${className}`}
    >
      {children}
    </section>
  );
};

export const SectionTitle: React.FC<SectionTitleProps> = ({
  badge,
  title,
  highlightText,
  description,
  align = 'left',
  dark = false,
  className = '',
}) => {
  const alignClasses = align === 'center' ? 'text-center mx-auto items-center' : 'text-left items-start';

  return (
    <div className={`flex flex-col max-w-3xl mb-12 ${alignClasses} ${className}`}>
      {badge && (
        <span
          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold tracking-wider uppercase mb-3 ${
            dark
              ? 'bg-[#2CBEBF]/15 text-[#2CBEBF] border border-[#2CBEBF]/30'
              : 'bg-[#EBF6FC] text-[#002B58] border border-[#2CBEBF]/40'
          }`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#FE7001]" />
          {badge}
        </span>
      )}

      <h2
        className={`text-3xl md:text-4xl lg:text-4xl font-extrabold tracking-tight leading-tight ${
          dark ? 'text-white' : 'text-[#002B58]'
        }`}
        style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
      >
        {title}{' '}
        {highlightText && (
          <span className={dark ? 'text-[#2CBEBF]' : 'text-[#002B58] border-b-2 border-[#2CBEBF]'}>
            {highlightText}
          </span>
        )}
      </h2>

      {description && (
        <p
          className={`mt-4 text-base md:text-lg leading-relaxed ${
            dark ? 'text-slate-300' : 'text-slate-600'
          }`}
        >
          {description}
        </p>
      )}
    </div>
  );
};
