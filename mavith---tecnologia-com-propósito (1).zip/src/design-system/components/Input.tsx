import React from 'react';
import { InputProps, TextareaProps, SelectProps } from '../types';

export const Input: React.FC<InputProps> = ({
  label,
  error,
  helperText,
  leftIcon,
  rightIcon,
  id,
  className = '',
  disabled,
  ...props
}) => {
  return (
    <div className="w-full flex flex-col gap-1.5 text-left">
      {label && (
        <label
          htmlFor={id}
          className="text-xs font-semibold uppercase tracking-wider text-[#002B58] flex items-center justify-between"
        >
          <span>{label}</span>
          {props.required && <span className="text-[#FE7001]">*</span>}
        </label>
      )}

      <div className="relative flex items-center">
        {leftIcon && (
          <div className="absolute left-3.5 pointer-events-none text-slate-400">
            {leftIcon}
          </div>
        )}

        <input
          id={id}
          disabled={disabled}
          className={`w-full text-sm rounded-lg bg-white border px-3.5 py-2.5 text-slate-900 placeholder:text-slate-400 transition-colors duration-150 outline-none
            ${leftIcon ? 'pl-10' : ''}
            ${rightIcon ? 'pr-10' : ''}
            ${
              error
                ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-200'
                : 'border-slate-300 focus:border-[#002B58] focus:ring-2 focus:ring-[#002B58]/15'
            }
            ${disabled ? 'bg-slate-100 text-slate-400 cursor-not-allowed' : ''}
            ${className}
          `}
          {...props}
        />

        {rightIcon && (
          <div className="absolute right-3.5 pointer-events-none text-slate-400">
            {rightIcon}
          </div>
        )}
      </div>

      {error ? (
        <span className="text-xs font-medium text-red-600 flex items-center gap-1">
          {error}
        </span>
      ) : helperText ? (
        <span className="text-xs text-slate-500">{helperText}</span>
      ) : null}
    </div>
  );
};

export const Textarea: React.FC<TextareaProps> = ({
  label,
  error,
  helperText,
  id,
  className = '',
  rows = 4,
  disabled,
  ...props
}) => {
  return (
    <div className="w-full flex flex-col gap-1.5 text-left">
      {label && (
        <label
          htmlFor={id}
          className="text-xs font-semibold uppercase tracking-wider text-[#002B58] flex items-center justify-between"
        >
          <span>{label}</span>
          {props.required && <span className="text-[#FE7001]">*</span>}
        </label>
      )}

      <textarea
        id={id}
        rows={rows}
        disabled={disabled}
        className={`w-full text-sm rounded-lg bg-white border p-3 text-slate-900 placeholder:text-slate-400 transition-colors duration-150 outline-none resize-y
          ${
            error
              ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-200'
              : 'border-slate-300 focus:border-[#002B58] focus:ring-2 focus:ring-[#002B58]/15'
          }
          ${disabled ? 'bg-slate-100 text-slate-400 cursor-not-allowed' : ''}
          ${className}
        `}
        {...props}
      />

      {error ? (
        <span className="text-xs font-medium text-red-600">{error}</span>
      ) : helperText ? (
        <span className="text-xs text-slate-500">{helperText}</span>
      ) : null}
    </div>
  );
};

export const Select: React.FC<SelectProps> = ({
  label,
  options,
  error,
  helperText,
  id,
  className = '',
  disabled,
  ...props
}) => {
  return (
    <div className="w-full flex flex-col gap-1.5 text-left">
      {label && (
        <label
          htmlFor={id}
          className="text-xs font-semibold uppercase tracking-wider text-[#002B58] flex items-center justify-between"
        >
          <span>{label}</span>
          {props.required && <span className="text-[#FE7001]">*</span>}
        </label>
      )}

      <div className="relative">
        <select
          id={id}
          disabled={disabled}
          className={`w-full text-sm rounded-lg bg-white border px-3.5 py-2.5 text-slate-900 transition-colors duration-150 outline-none appearance-none pr-10
            ${
              error
                ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-200'
                : 'border-slate-300 focus:border-[#002B58] focus:ring-2 focus:ring-[#002B58]/15'
            }
            ${disabled ? 'bg-slate-100 text-slate-400 cursor-not-allowed' : ''}
            ${className}
          `}
          {...props}
        >
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>

        <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-500">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </div>

      {error ? (
        <span className="text-xs font-medium text-red-600">{error}</span>
      ) : helperText ? (
        <span className="text-xs text-slate-500">{helperText}</span>
      ) : null}
    </div>
  );
};
