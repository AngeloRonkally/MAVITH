import React from 'react';
import { BadgeProps, TagProps } from '../types';

export const Badge: React.FC<BadgeProps> = ({
  variant = 'turquoise',
  size = 'md',
  icon,
  children,
  className = '',
}) => {
  const variantClasses = {
    turquoise: 'bg-[#E2F8F8] text-[#0D6B6B] border border-[#2CBEBF]/40',
    blue: 'bg-[#EBF6FC] text-[#002B58] border border-[#002B58]/20',
    orange: 'bg-[#FFF2E7] text-[#C45500] border border-[#FE7001]/30',
    neutral: 'bg-slate-100 text-slate-700 border border-slate-200',
    outline: 'bg-transparent text-slate-700 border border-slate-300',
  };

  const sizeClasses = {
    sm: 'text-[11px] font-semibold py-0.5 px-2 gap-1 rounded-md',
    md: 'text-xs font-semibold py-1 px-2.5 gap-1.5 rounded-md',
  };

  return (
    <span
      className={`inline-flex items-center select-none whitespace-nowrap leading-none ${sizeClasses[size]} ${variantClasses[variant]} ${className}`}
    >
      {icon && <span className="shrink-0">{icon}</span>}
      <span>{children}</span>
    </span>
  );
};

export const Tag: React.FC<TagProps> = ({
  label,
  active = false,
  onClick,
  onRemove,
  color = 'blue',
  className = '',
}) => {
  const colorMap = {
    blue: active
      ? 'bg-[#002B58] text-white border-[#002B58]'
      : 'bg-white text-slate-700 border-slate-200 hover:border-[#002B58] hover:text-[#002B58]',
    turquoise: active
      ? 'bg-[#2CBEBF] text-[#002B58] border-[#2CBEBF] font-semibold'
      : 'bg-white text-slate-700 border-slate-200 hover:border-[#2CBEBF] hover:text-[#169495]',
    orange: active
      ? 'bg-[#FE7001] text-white border-[#FE7001]'
      : 'bg-white text-slate-700 border-slate-200 hover:border-[#FE7001] hover:text-[#FE7001]',
    neutral: active
      ? 'bg-slate-800 text-white border-slate-800'
      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50',
  };

  return (
    <span
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border transition-all duration-150 select-none ${
        onClick ? 'cursor-pointer' : ''
      } ${colorMap[color]} ${className}`}
    >
      <span>{label}</span>
      {onRemove && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="hover:opacity-70 focus:outline-none"
          aria-label={`Remover ${label}`}
        >
          ×
        </button>
      )}
    </span>
  );
};
