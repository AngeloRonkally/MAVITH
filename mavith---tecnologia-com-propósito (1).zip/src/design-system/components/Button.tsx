import React from 'react';
import { ButtonProps } from '../types';

/**
 * MAVITH Design System - Button
 * Consistent, accessible interactive button with precise brand colors and microinteractions.
 */
export const Button: React.FC<ButtonProps> = ({
  variant = 'primary-blue',
  size = 'md',
  leftIcon,
  rightIcon,
  isLoading = false,
  fullWidth = false,
  children,
  className = '',
  disabled,
  ...props
}) => {
  // Base classes: typography, padding math (horizontal = 2x vertical), focus ring, transitions
  const baseClasses =
    'relative inline-flex items-center justify-center font-semibold rounded-lg transition-all duration-200 cursor-pointer select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:pointer-events-none active:scale-[0.98]';

  // Size mapping (horizontal padding = exactly 2x vertical padding)
  const sizeClasses = {
    sm: 'text-xs py-2 px-4 gap-1.5 focus-visible:ring-offset-1',
    md: 'text-sm py-2.5 px-5 gap-2',
    lg: 'text-base py-3.5 px-7 gap-2.5',
  };

  // Variant mapping
  const variantClasses = {
    // Primary Blue: Solid Navy #002B58, hover slight brightness/elevation
    'primary-blue':
      'bg-[#002B58] text-white hover:bg-[#003873] shadow-sm hover:shadow focus-visible:ring-[#002B58] border border-transparent',
    
    // Primary Orange: Action CTA #FE7001, high focus and conversion
    'primary-orange':
      'bg-[#FE7001] text-white hover:bg-[#E56300] shadow-sm hover:shadow-[0_4px_14px_rgba(254,112,1,0.35)] focus-visible:ring-[#FE7001] border border-transparent',
    
    // Secondary: Clean corporate neutral outline/subtle border
    'secondary':
      'bg-white text-[#002B58] border border-slate-300 hover:bg-slate-50 hover:border-slate-400 shadow-sm focus-visible:ring-[#2CBEBF]',
    
    // Ghost: Transparent with subtle hover
    'ghost':
      'bg-transparent text-slate-700 hover:bg-slate-100 hover:text-[#002B58] focus-visible:ring-slate-400',
    
    // Outline White (for dark navy sections)
    'outline-white':
      'bg-transparent text-white border border-white/30 hover:bg-white/10 hover:border-white focus-visible:ring-white',
  };

  const widthClass = fullWidth ? 'w-full' : '';

  return (
    <button
      className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]} ${widthClass} ${className}`}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading ? (
        <svg
          className="animate-spin -ml-1 mr-2 h-4 w-4 text-current"
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
        >
          <circle
            className="opacity-25"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="4"
          />
          <path
            className="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
          />
        </svg>
      ) : (
        leftIcon && <span className="shrink-0">{leftIcon}</span>
      )}
      <span className="whitespace-nowrap">{children}</span>
      {!isLoading && rightIcon && <span className="shrink-0">{rightIcon}</span>}
    </button>
  );
};

/**
 * ButtonPrimary helper component (defaults to Deep Blue or Orange)
 */
export const ButtonPrimary: React.FC<ButtonProps & { action?: boolean }> = ({
  action = false,
  ...props
}) => {
  return <Button variant={action ? 'primary-orange' : 'primary-blue'} {...props} />;
};

/**
 * ButtonSecondary helper component
 */
export const ButtonSecondary: React.FC<ButtonProps> = (props) => {
  return <Button variant="secondary" {...props} />;
};
