import React from 'react';
import { LogoProps } from '../types';

/**
 * MAVITH Official Brand Logo
 * Replicates the multifaceted geometric 'M' symbol with circuit nodes
 * (Orange #FE7001, Turquoise #2CBEBF, Deep Navy #002B58) and typography.
 */
export const MavithLogo: React.FC<LogoProps> = ({
  variant = 'full',
  theme = 'light',
  size = 'md',
  className = '',
  showSlogan = true,
}) => {
  const isDark = theme === 'dark';

  // Size scalers
  const sizeMap = {
    sm: { symbolSize: 28, textClass: 'text-lg', sloganClass: 'text-[10px]' },
    md: { symbolSize: 36, textClass: 'text-2xl', sloganClass: 'text-xs' },
    lg: { symbolSize: 48, textClass: 'text-3xl', sloganClass: 'text-sm' },
    xl: { symbolSize: 64, textClass: 'text-4xl', sloganClass: 'text-base' },
  };

  const { symbolSize, textClass, sloganClass } = sizeMap[size];

  // Colors
  const textColor = isDark ? '#FFFFFF' : '#002B58';
  const sloganColor = isDark ? '#94A3B8' : '#334155';
  const dividerColor = isDark ? '#334155' : '#2CBEBF';

  return (
    <div
      className={`inline-flex items-center gap-3 select-none ${className}`}
      id="mavith-brand-logo"
      aria-label="MAVITH - Tecnologia com propósito."
    >
      {/* Geometric 'M' Symbol with Circuit Traces */}
      <svg
        width={symbolSize}
        height={symbolSize}
        viewBox="0 0 160 160"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 transition-transform duration-300 hover:scale-105"
        role="img"
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="m-grad-left" x1="40" y1="40" x2="80" y2="120" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#2CBEBF" />
            <stop offset="50%" stopColor="#004A8F" />
            <stop offset="100%" stopColor="#FE7001" />
          </linearGradient>

          <linearGradient id="m-grad-right" x1="80" y1="40" x2="140" y2="130" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#002B58" />
            <stop offset="60%" stopColor="#001C3B" />
            <stop offset="100%" stopColor="#2CBEBF" />
          </linearGradient>

          <linearGradient id="m-grad-center" x1="60" y1="40" x2="100" y2="120" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#2CBEBF" />
            <stop offset="100%" stopColor="#002B58" />
          </linearGradient>
        </defs>

        {/* --- Circuit Node 1: Top Branch (Orange #FE7001) --- */}
        <path
          d="M 16 52 L 40 52"
          stroke="#FE7001"
          strokeWidth="6"
          strokeLinecap="round"
        />
        <circle cx="16" cy="52" r="9" stroke="#FE7001" strokeWidth="5" fill="none" />

        {/* --- Circuit Node 2: Middle Branch (Turquoise #2CBEBF) --- */}
        <path
          d="M 6 80 L 40 80"
          stroke="#2CBEBF"
          strokeWidth="6"
          strokeLinecap="round"
        />
        <circle cx="6" cy="80" r="9" stroke="#2CBEBF" strokeWidth="5" fill="none" />

        {/* --- Circuit Node 3: Bottom Branch (Navy #002B58) --- */}
        <path
          d="M 24 108 L 42 108"
          stroke={isDark ? '#2CBEBF' : '#002B58'}
          strokeWidth="6"
          strokeLinecap="round"
        />
        <circle
          cx="24"
          cy="108"
          r="9"
          stroke={isDark ? '#2CBEBF' : '#002B58'}
          strokeWidth="5"
          fill="none"
        />

        {/* --- Faceted Geometric 'M' Polygon Structure --- */}
        {/* Left Vertical Column Facet 1 (Top Left) */}
        <polygon points="42,30 76,30 58,74 42,74" fill="#2CBEBF" />
        
        {/* Left Column Facet 2 (Middle Left) */}
        <polygon points="42,74 58,74 74,104 42,104" fill="#004A8F" />
        
        {/* Left Column Facet 3 (Bottom Left Orange accent) */}
        <polygon points="42,104 74,104 60,130 42,130" fill="#FE7001" />

        {/* Inner Valley Facet Left */}
        <polygon points="76,30 100,74 88,118 58,74" fill="#002B58" />

        {/* Central V Valley Floor */}
        <polygon points="88,118 100,74 112,118" fill="#001C3B" />

        {/* Inner Valley Facet Right */}
        <polygon points="100,74 124,30 142,74 112,118" fill="#00356E" />

        {/* Right Vertical Column Facet 1 (Top Right) */}
        <polygon points="124,30 158,30 158,74 142,74" fill="#002B58" />

        {/* Right Column Facet 2 (Middle Right) */}
        <polygon points="142,74 158,74 158,104 126,104" fill="#001F42" />

        {/* Right Column Facet 3 (Bottom Right) */}
        <polygon points="126,104 158,104 158,130 140,130" fill="#001833" />

        {/* Center Bottom Point */}
        <polygon points="88,118 100,138 112,118" fill="#002B58" />

        {/* Circuit Trace inside the M Valley (Turquoise with node) */}
        <path
          d="M 68 84 L 88 118 L 132 54"
          stroke="#FFFFFF"
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="opacity-95"
        />
        <circle cx="68" cy="84" r="5" fill="#FFFFFF" />
        <circle cx="132" cy="54" r="5" fill="#FFFFFF" />
      </svg>

      {/* Brand Typography (Wordmark + Slogan) */}
      {variant !== 'symbol' && (
        <div className="flex flex-col justify-center leading-none">
          <div className="flex items-center gap-2">
            {/* Wordmark "MΛVITH" */}
            <span
              className={`font-black tracking-wider ${textClass}`}
              style={{
                color: textColor,
                fontFamily: "'Plus Jakarta Sans', sans-serif",
                letterSpacing: '0.04em',
              }}
            >
              M<span className="inline-block relative">Λ</span>VITH
            </span>
          </div>

          {/* Slogan "Tecnologia com propósito." */}
          {showSlogan && variant === 'full' && (
            <span
              className={`mt-1 font-medium tracking-tight whitespace-nowrap ${sloganClass}`}
              style={{
                color: sloganColor,
                fontFamily: "'Inter', sans-serif",
              }}
            >
              Tecnologia com propósito<span style={{ color: '#FE7001' }}>.</span>
            </span>
          )}
        </div>
      )}
    </div>
  );
};
