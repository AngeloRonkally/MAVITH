import React, { useState, useEffect, useRef } from 'react';
import { MavithLogo } from './MavithLogo';
import { Button } from './Button';
import {
  Menu,
  X,
  ArrowRight,
  MessageSquare,
  ChevronDown,
  Globe,
  Layers,
  Sparkles,
  Zap,
  BarChart3,
  ArrowUpRight,
} from 'lucide-react';

interface HeaderProps {
  activeItem?: string;
  onNavigate?: (item: string) => void;
  onCtaClick?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeItem = 'Início',
  onNavigate,
  onCtaClick,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [isSolutionsDropdownOpen, setIsSolutionsDropdownOpen] = useState(false);
  const [isMobileSolutionsOpen, setIsMobileSolutionsOpen] = useState(false);
  const dropdownTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const menuItems = [
    { label: 'Início', id: 'inicio' },
    { label: 'Soluções', id: 'solucoes', hasSubmenu: true },
    { label: 'Portfólio', id: 'portfolio' },
    { label: 'Como fazemos', id: 'como-fazemos' },
    { label: 'Sobre', id: 'sobre' },
    { label: 'Insights', id: 'insights' },
    { label: 'Contato', id: 'contato' },
  ];

  const solutionsList = [
    {
      slug: 'sites',
      title: 'Sites & Plataformas',
      desc: 'Presença digital com autoridade e alta conversão',
      icon: Globe,
      color: 'text-[#002B58]',
    },
    {
      slug: 'sistemas',
      title: 'Sistemas Sob Medida',
      desc: 'Substituição de planilhas e processos manuais',
      icon: Layers,
      color: 'text-[#2CBEBF]',
    },
    {
      slug: 'ia',
      title: 'Inteligência Artificial',
      desc: 'Agentes inteligentes que trabalham com sua equipe',
      icon: Sparkles,
      color: 'text-[#FE7001]',
    },
    {
      slug: 'automacao',
      title: 'Automação de Processos',
      desc: 'Eliminação de tarefas repetitivas e integrações',
      icon: Zap,
      color: 'text-[#FE7001]',
    },
    {
      slug: 'dashboards',
      title: 'Dashboards & BI',
      desc: 'Métricas e indicadores em tempo real para decisões',
      icon: BarChart3,
      color: 'text-[#002B58]',
    },
  ];

  // Scroll effect for subtle header elevation
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Lock scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [isMobileMenuOpen]);

  const handleItemClick = (label: string) => {
    setIsSolutionsDropdownOpen(false);
    setIsMobileMenuOpen(false);
    if (onNavigate) {
      onNavigate(label);
    }
  };

  const handleMouseEnterSolutions = () => {
    if (dropdownTimeoutRef.current) {
      clearTimeout(dropdownTimeoutRef.current);
    }
    setIsSolutionsDropdownOpen(true);
  };

  const handleMouseLeaveSolutions = () => {
    dropdownTimeoutRef.current = setTimeout(() => {
      setIsSolutionsDropdownOpen(false);
    }, 150);
  };

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-all duration-200 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-200/90 py-2.5'
          : 'bg-white border-b border-slate-200 py-3.5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo */}
        <div
          className="cursor-pointer"
          onClick={() => handleItemClick('Início')}
        >
          <MavithLogo variant="full" size="md" />
        </div>

        {/* Desktop Navigation Menu */}
        <nav
          className="hidden lg:flex items-center gap-1 xl:gap-2"
          aria-label="Navegação principal"
        >
          {menuItems.map((item) => {
            const isActive = activeItem.toLowerCase() === item.label.toLowerCase();

            if (item.hasSubmenu) {
              return (
                <div
                  key={item.id}
                  className="relative"
                  onMouseEnter={handleMouseEnterSolutions}
                  onMouseLeave={handleMouseLeaveSolutions}
                >
                  <button
                    type="button"
                    onClick={() => handleItemClick('Soluções')}
                    className={`relative px-3 py-2 text-sm font-semibold rounded-md transition-colors cursor-pointer select-none inline-flex items-center gap-1 ${
                      isActive
                        ? 'text-[#002B58] bg-[#EBF6FC]/60'
                        : 'text-slate-600 hover:text-[#002B58] hover:bg-slate-50'
                    }`}
                  >
                    <span>{item.label}</span>
                    <ChevronDown
                      className={`w-3.5 h-3.5 transition-transform duration-200 ${
                        isSolutionsDropdownOpen ? 'rotate-180 text-[#FE7001]' : 'text-slate-400'
                      }`}
                    />
                    {isActive && (
                      <span className="absolute bottom-0 left-3.5 right-3.5 h-0.5 bg-[#2CBEBF] rounded-full" />
                    )}
                  </button>

                  {/* Desktop Dropdown Flyout */}
                  {isSolutionsDropdownOpen && (
                    <div className="absolute top-full left-0 w-80 pt-2 z-50">
                      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 p-2.5 space-y-1">
                        <div className="p-2 border-b border-slate-100 flex items-center justify-between">
                          <span className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                            Frentes de Solução
                          </span>
                          <button
                            type="button"
                            onClick={() => handleItemClick('Soluções')}
                            className="text-[11px] font-bold text-[#FE7001] hover:underline flex items-center gap-0.5 cursor-pointer"
                          >
                            <span>Ver todas</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        </div>

                        {solutionsList.map((sol) => {
                          const Icon = sol.icon;
                          return (
                            <button
                              key={sol.slug}
                              type="button"
                              onClick={() => handleItemClick(`solucoes/${sol.slug}`)}
                              className="w-full p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left flex items-start gap-3 group cursor-pointer"
                            >
                              <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center shrink-0 mt-0.5 group-hover:bg-white group-hover:shadow-xs transition-all">
                                <Icon className={`w-4 h-4 ${sol.color}`} />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="text-xs font-bold text-[#002B58] group-hover:text-[#FE7001] transition-colors flex items-center justify-between">
                                  <span>{sol.title}</span>
                                  <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-[#FE7001]" />
                                </div>
                                <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                                  {sol.desc}
                                </p>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              );
            }

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleItemClick(item.label)}
                className={`relative px-3.5 py-2 text-sm font-semibold rounded-md transition-colors cursor-pointer select-none ${
                  isActive
                    ? 'text-[#002B58] bg-[#EBF6FC]/60'
                    : 'text-slate-600 hover:text-[#002B58] hover:bg-slate-50'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-3.5 right-3.5 h-0.5 bg-[#2CBEBF] rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Desktop CTA Action */}
        <div className="hidden lg:flex items-center gap-3">
          <Button
            variant="primary-orange"
            size="sm"
            onClick={onCtaClick}
            rightIcon={<ArrowRight className="w-4 h-4" />}
            className="shadow-sm"
          >
            Fale com a MAVITH
          </Button>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex lg:hidden items-center gap-2">
          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2.5 rounded-lg text-[#002B58] hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-[#2CBEBF]"
            aria-label={isMobileMenuOpen ? 'Fechar menu' : 'Abrir menu de navegação'}
            aria-expanded={isMobileMenuOpen}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 top-[65px] z-50 lg:hidden flex flex-col bg-white border-t border-slate-200">
          <div className="flex-1 overflow-y-auto px-6 py-6 flex flex-col gap-2">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 px-3">
              Navegação
            </div>

            {menuItems.map((item) => {
              const isActive = activeItem.toLowerCase() === item.label.toLowerCase();

              if (item.hasSubmenu) {
                return (
                  <div key={item.id} className="space-y-1">
                    <div className="flex items-center justify-between px-4 py-3.5 text-base font-semibold rounded-lg bg-slate-50 text-slate-800">
                      <button
                        type="button"
                        onClick={() => handleItemClick('Soluções')}
                        className="text-left font-bold text-[#002B58]"
                      >
                        {item.label}
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsMobileSolutionsOpen(!isMobileSolutionsOpen)}
                        className="p-1 text-slate-500"
                      >
                        <ChevronDown
                          className={`w-4 h-4 transition-transform ${
                            isMobileSolutionsOpen ? 'rotate-180' : ''
                          }`}
                        />
                      </button>
                    </div>

                    {isMobileSolutionsOpen && (
                      <div className="pl-4 pr-2 py-2 space-y-1 bg-slate-50/50 rounded-lg">
                        <button
                          type="button"
                          onClick={() => handleItemClick('Soluções')}
                          className="w-full text-left py-2 px-3 text-xs font-bold text-[#FE7001]"
                        >
                          → Ver todas as 5 soluções
                        </button>
                        {solutionsList.map((sol) => (
                          <button
                            key={sol.slug}
                            type="button"
                            onClick={() => handleItemClick(`solucoes/${sol.slug}`)}
                            className="w-full text-left py-2 px-3 text-xs font-medium text-slate-700 hover:text-[#002B58] rounded-md hover:bg-slate-100"
                          >
                            {sol.title}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                );
              }

              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleItemClick(item.label)}
                  className={`flex items-center justify-between px-4 py-3.5 text-base font-semibold rounded-lg text-left transition-colors ${
                    isActive
                      ? 'bg-[#EBF6FC] text-[#002B58] border-l-4 border-[#2CBEBF]'
                      : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <span>{item.label}</span>
                  {isActive && <div className="w-2 h-2 rounded-full bg-[#FE7001]" />}
                </button>
              );
            })}

            <div className="my-4 border-t border-slate-100" />

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/70 mb-4">
              <p className="text-xs font-medium text-slate-500 mb-1">
                Atendimento consultivo
              </p>
              <p className="text-sm font-bold text-[#002B58]">
                Soluções digitais com foco em pequenas empresas
              </p>
            </div>

            <Button
              variant="primary-orange"
              size="lg"
              fullWidth
              onClick={() => {
                setIsMobileMenuOpen(false);
                if (onCtaClick) onCtaClick();
              }}
              rightIcon={<MessageSquare className="w-5 h-5" />}
            >
              Fale com a MAVITH
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};
