import React, { ReactNode } from 'react';

interface DividerProps {
  label?: string;
  withNode?: boolean;
  className?: string;
}

export const Divider: React.FC<DividerProps> = ({
  label,
  withNode = false,
  className = '',
}) => {
  if (label) {
    return (
      <div className={`relative flex items-center my-6 ${className}`}>
        <div className="grow border-t border-slate-200" />
        <span className="shrink-0 mx-4 text-xs font-semibold uppercase tracking-wider text-slate-400">
          {label}
        </span>
        <div className="grow border-t border-slate-200" />
      </div>
    );
  }

  if (withNode) {
    return (
      <div className={`relative flex items-center my-8 ${className}`}>
        <div className="grow border-t border-slate-200" />
        <div className="shrink-0 mx-3 flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-[#FE7001]" />
          <div className="w-2 h-2 rounded-full bg-[#2CBEBF]" />
          <div className="w-1.5 h-1.5 rounded-full bg-[#002B58]" />
        </div>
        <div className="grow border-t border-slate-200" />
      </div>
    );
  }

  return <hr className={`border-t border-slate-200 my-6 ${className}`} />;
};

interface CTAProps {
  title: string;
  problemStatement?: string;
  description: string;
  primaryActionText: string;
  secondaryActionText?: string;
  onPrimaryClick?: () => void;
  onSecondaryClick?: () => void;
  className?: string;
  badge?: string;
}

import { Button } from './Button';

export const CTA: React.FC<CTAProps> = ({
  title,
  problemStatement,
  description,
  primaryActionText,
  secondaryActionText,
  onPrimaryClick,
  onSecondaryClick,
  className = '',
  badge = 'Diagnóstico Inicial',
}) => {
  return (
    <div
      className={`relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#002B58] via-[#001C3B] to-[#002447] text-white p-8 md:p-12 border border-[#2CBEBF]/30 shadow-xl ${className}`}
    >
      {/* Subtle circuit lines background */}
      <div className="absolute inset-0 bg-circuit-dark opacity-40 pointer-events-none" />

      {/* Decorative colored corner accents */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#2CBEBF]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#FE7001]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-3xl">
        {badge && (
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-[#2CBEBF]/20 text-[#2CBEBF] border border-[#2CBEBF]/40 mb-4">
            <span className="w-1.5 h-1.5 rounded-full bg-[#FE7001]" />
            {badge}
          </div>
        )}

        {problemStatement && (
          <p className="text-sm md:text-base font-semibold text-[#2CBEBF] mb-2 tracking-wide">
            {problemStatement}
          </p>
        )}

        <h3
          className="text-2xl md:text-4xl font-extrabold tracking-tight text-white leading-tight"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
          {title}
        </h3>

        <p className="mt-4 text-base md:text-lg text-slate-300 leading-relaxed max-w-2xl">
          {description}
        </p>

        <div className="mt-8 flex flex-wrap items-center gap-4">
          <Button
            variant="primary-orange"
            size="lg"
            onClick={onPrimaryClick}
            className="shadow-lg"
          >
            {primaryActionText}
          </Button>

          {secondaryActionText && (
            <Button
              variant="outline-white"
              size="lg"
              onClick={onSecondaryClick}
            >
              {secondaryActionText}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};
