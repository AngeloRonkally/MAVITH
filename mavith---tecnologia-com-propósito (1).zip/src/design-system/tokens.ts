/**
 * MAVITH Design Tokens - Fase 1: Fundação da Marca
 * Centralized design decisions for colors, typography, spacing, shadows, borders and transitions.
 */

export const MAVITH_TOKENS = {
  brand: {
    name: 'MAVITH',
    slogan: 'Tecnologia com propósito.',
    pillars: ['Inovação', 'Inteligência Analítica', 'Confiabilidade'],
    services: [
      { id: 'sites', label: 'Sites', description: 'Portais institucionais e páginas de alta conversão' },
      { id: 'sistemas', label: 'Sistemas', description: 'Software de gestão, plataformas web e integração em nuvem' },
      { id: 'agentes-ia', label: 'Agentes de IA', description: 'Automação inteligente e agentes cognitivos sob medida' },
      { id: 'dashboards', label: 'Dashboards', description: 'Business Intelligence e painéis analíticos para decisões' },
    ],
  },
  colors: {
    // Cores Principais
    primary: {
      deepBlue: '#002B58',    // Azul Profundo Oficial
      darkBlue: '#001C3B',    // Azul Escuro para contraste e footers
      surfaceBlue: '#002447', // Superfície para elevação em dark mode
      lightBlue: '#EBF6FC',   // Azul Claro para fundos sutis
      skyBlue: '#D4EDF9',     // Azul intermediário
    },
    accent: {
      turquoise: '#2CBEBF',      // Turquesa Oficial (Conexão e Inteligência)
      turquoiseLight: '#E2F8F8', // Turquesa Claro para badges e destaques
      turquoiseDark: '#169495',  // Turquesa Escuro para textos sobre fundos claros
      turquoiseMuted: '#9DE3E3', // Turquesa Suave para bordas
    },
    action: {
      orange: '#FE7001',      // Laranja Oficial (Ação e Destaque)
      orangeHover: '#E56300', // Laranja Escurecido para hover states
      orangeLight: '#FFF2E7', // Laranja Claro para alertas e badges
      orangeMuted: '#FFB274', // Laranja Suave para acentos
    },
    neutral: {
      white: '#FFFFFF',
      gray50: '#F8FAFC',
      gray100: '#F1F5F9',
      gray200: '#E2E8F0',
      gray300: '#CBD5E1',
      gray400: '#94A3B8',
      gray500: '#64748B',
      gray600: '#475569',
      gray700: '#334155',
      gray800: '#1E293B',
      gray900: '#0F172A',
    },
    status: {
      success: '#10B981',
      warning: '#F59E0B',
      error: '#EF4444',
      info: '#2CBEBF',
    },
  },
  typography: {
    fontFamilies: {
      sans: "'Plus Jakarta Sans', 'Inter', system-ui, sans-serif",
      display: "'Plus Jakarta Sans', 'Manrope', sans-serif",
      mono: "'JetBrains Mono', monospace",
    },
    scale: {
      display1: { size: '3.5rem', lineHeight: '1.1', weight: '800', letterSpacing: '-0.025em' }, // 56px
      h1: { size: '2.5rem', lineHeight: '1.2', weight: '700', letterSpacing: '-0.02em' },         // 40px
      h2: { size: '2rem', lineHeight: '1.25', weight: '700', letterSpacing: '-0.015em' },        // 32px
      h3: { size: '1.5rem', lineHeight: '1.35', weight: '600', letterSpacing: '-0.01em' },        // 24px
      h4: { size: '1.25rem', lineHeight: '1.4', weight: '600', letterSpacing: '-0.005em' },       // 20px
      bodyLarge: { size: '1.125rem', lineHeight: '1.6', weight: '400' },                          // 18px
      body: { size: '1rem', lineHeight: '1.6', weight: '400' },                                   // 16px
      small: { size: '0.875rem', lineHeight: '1.5', weight: '500' },                              // 14px
      caption: { size: '0.75rem', lineHeight: '1.4', weight: '500', letterSpacing: '0.04em' },   // 12px
      button: { size: '0.9375rem', lineHeight: '1', weight: '600', letterSpacing: '0.01em' },     // 15px
    },
  },
  spacing: {
    xs: '4px',
    sm: '8px',
    md: '16px',
    lg: '24px',
    xl: '32px',
    '2xl': '48px',
    '3xl': '64px',
    '4xl': '96px',
  },
  borderRadius: {
    none: '0px',
    sm: '4px',
    md: '8px',
    lg: '12px',
    xl: '16px',
    full: '9999px',
  },
  shadows: {
    subtle: '0 1px 2px 0 rgba(0, 43, 88, 0.05)',
    card: '0 2px 6px -1px rgba(0, 43, 88, 0.08), 0 1px 4px -1px rgba(0, 43, 88, 0.04)',
    hover: '0 10px 25px -5px rgba(0, 43, 88, 0.12), 0 8px 10px -6px rgba(0, 43, 88, 0.06)',
    modal: '0 20px 35px -10px rgba(0, 28, 59, 0.25)',
    action: '0 4px 14px 0 rgba(254, 112, 1, 0.35)',
  },
  transitions: {
    fast: '150ms cubic-bezier(0.4, 0, 0.2, 1)',
    normal: '250ms cubic-bezier(0.4, 0, 0.2, 1)',
    slow: '400ms cubic-bezier(0.4, 0, 0.2, 1)',
  },
  breakpoints: {
    sm: '640px',
    md: '768px',
    lg: '1024px',
    xl: '1280px',
    '2xl': '1536px',
  },
} as const;

export type MavithTokens = typeof MAVITH_TOKENS;
