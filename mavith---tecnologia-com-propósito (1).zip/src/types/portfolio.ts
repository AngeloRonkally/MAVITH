export type PortfolioCategory =
  | 'Todos'
  | 'Sites'
  | 'Sistemas'
  | 'IA'
  | 'Automação'
  | 'Dashboards';

export type DeviceType = 'desktop' | 'notebook' | 'tablet' | 'mobile';

export interface ProjectFeature {
  title: string;
  description: string;
  icon?: string;
}

export interface ProjectResult {
  metric: string;
  label: string;
  detail: string;
}

export interface PortfolioProject {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  category: Exclude<PortfolioCategory, 'Todos'>;
  segment: string;
  description: string;
  isDemo: boolean;
  featured: boolean;
  primaryDevice: DeviceType;
  
  // A Esteira Estratégica: Entender -> Analisar -> Projetar -> Construir -> Transformar
  problem: string;      // "O que estava acontecendo?"
  analysis: string;     // "O que precisava mudar?"
  objective: string;    // Qual era a meta de negócio?
  strategy: string;     // "Qual caminho foi definido?"
  solution: string;     // "O que foi construído?"
  
  features: ProjectFeature[];
  technologies: string[];
  results: ProjectResult[];
  
  // UI Mockup Data
  mockupData: {
    device: DeviceType;
    screenType: 'dashboard' | 'crm' | 'chat_ai' | 'b2b_portal' | 'institutional_site' | 'automation_flow';
    caption: string;
    highlights: string[];
  };

  gallery: {
    title: string;
    description: string;
    device: DeviceType;
    tag: string;
  }[];
}
