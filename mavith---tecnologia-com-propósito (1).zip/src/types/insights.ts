export type InsightCategory =
  | 'Tecnologia'
  | 'IA'
  | 'Automação'
  | 'Dados'
  | 'Negócios'
  | 'Transformação Digital';

export interface ArticleSection {
  title: string;
  paragraphs: string[];
  callout?: {
    type: 'warning' | 'tip' | 'quote';
    title?: string;
    text: string;
  };
  checklist?: {
    title: string;
    items: string[];
  };
  comparison?: {
    title: string;
    colLeft: string;
    colRight: string;
    rows: {
      aspect: string;
      left: string;
      right: string;
    }[];
  };
}

export interface InsightArticle {
  slug: string;
  title: string;
  subtitle: string;
  category: InsightCategory;
  date: string;
  isoDate: string;
  readTime: string;
  author: {
    name: string;
    role: string;
    bio: string;
  };
  coverBadge: string;
  introduction: string[];
  sections: ArticleSection[];
  keyTakeaways: string[];
  conclusion: string[];
  relatedArticleSlugs: string[];
  targetSolutionSlug?: 'sites' | 'sistemas' | 'ia' | 'automacao' | 'dashboards';
  seo: {
    metaTitle: string;
    metaDescription: string;
    keywords: string[];
  };
}
