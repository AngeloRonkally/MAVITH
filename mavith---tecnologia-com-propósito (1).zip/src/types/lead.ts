export type LeadProjectType =
  | 'Site'
  | 'Sistema'
  | 'IA'
  | 'Automação'
  | 'Dashboard'
  | 'Integração'
  | 'Outro';

export interface LeadPayload {
  id: string;
  name: string;
  company: string;
  whatsapp: string;
  email: string;
  projectType: LeadProjectType;
  message: string;
  lead_source: string;
  lead_campaign: string;
  lead_page: string;
  lead_service: string;
  lead_timestamp: string;
  status: 'novo' | 'em_analise' | 'contatado';
}

export type AnalyticsEventType =
  | 'cta_click'
  | 'whatsapp_click'
  | 'form_started'
  | 'form_submitted'
  | 'portfolio_viewed'
  | 'service_viewed'
  | 'article_viewed';

export interface AnalyticsEvent {
  id: string;
  event: AnalyticsEventType;
  params: Record<string, any>;
  timestamp: string;
  page: string;
}
