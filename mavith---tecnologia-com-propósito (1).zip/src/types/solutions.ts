export type SolutionSlug = 'sites' | 'sistemas' | 'ia' | 'automacao' | 'dashboards';

export interface SolutionItem {
  title: string;
  description: string;
  deliverables: string[];
  idealFor: string;
}

export interface PracticalExample {
  scenario: string;
  before: string;
  after: string;
  impact: string;
}

export interface SolutionBenefit {
  title: string;
  description: string;
  metricHighlight?: string;
}

export interface SolutionFaq {
  question: string;
  answer: string;
}

export interface SolutionData {
  id: string;
  slug: SolutionSlug;
  pillarNumber: string;
  title: string;
  headline: string;
  tagline: string;
  badge: string;
  accent: 'blue' | 'turquoise' | 'orange';
  
  // 1. Problema ("Qual problema isso resolve?")
  problemHeadline: string;
  problemDescription: string;
  symptoms: {
    title: string;
    description: string;
  }[];

  // 2. Como podemos ajudar & Para quem serve
  targetAudience: {
    segment: string;
    description: string;
  }[];
  approachPhilosophy: string;

  // 3. O que pode ser construído (Soluções)
  offerings: SolutionItem[];

  // 4. Exemplos práticos
  examples: PracticalExample[];

  // 5. Benefícios tangíveis
  benefits: SolutionBenefit[];

  // 6. Como funciona / Processo
  processSteps: {
    step: string;
    title: string;
    description: string;
  }[];

  // 7. Cases relacionados (slugs from portfolioData)
  relatedCaseSlugs: string[];

  // 8. FAQ
  faqs: SolutionFaq[];
}
