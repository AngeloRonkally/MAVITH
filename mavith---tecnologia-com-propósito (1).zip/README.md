# MAVITH — Tecnologia com propósito
### Fase 1: Fundação da Marca e Design System

Este projeto é uma aplicação web moderna desenvolvida com **React 19**, **TypeScript**, **Vite** e **Tailwind CSS**.

---

## ⚠️ Por que o `index.html` da raiz não abre diretamente com dois cliques?

Se você baixou o `.zip` e clicou duas vezes no arquivo `index.html` da raiz, seu navegador exibirá uma página em branco. 

Isso acontece porque:
1. **O projeto usa TypeScript (.tsx)**: O arquivo da raiz aponta para `<script type="module" src="/src/main.tsx">`. Os navegadores não executam TypeScript puro sem transpilação.
2. **Segurança do Navegador (CORS)**: Navegadores bloqueiam módulos ES (`type="module"`) quando abertos pelo protocolo local `file:///` sem um servidor HTTP local.

---

## 🚀 Como Rodar o Projeto no seu Computador

Você precisa ter o **Node.js** (versão 18 ou superior) instalado em seu computador.

### Passo 1: Extrair e abrir a pasta no terminal
Extraia o arquivo `.zip` e abra a pasta no terminal ou VS Code.

### Passo 2: Instalar as dependências
Execute o comando abaixo:
```bash
npm install
```

### Passo 3: Iniciar o servidor de desenvolvimento
Execute:
```bash
npm run dev
```

Pronto! O terminal informará o endereço local (por exemplo, `http://localhost:3000`). Basta abrir esse link no seu navegador para ver o site completo e interativo.

---

## 📦 Como Rodar a Versão Compilada (`dist/`)

Se você quiser rodar a versão de produção pré-compilada:

```bash
# 1. Gerar o build (se já não estiver gerado)
npm run build

# 2. Servir a pasta dist
npx serve dist
```

Ou no **VS Code**, clique com o botão direito em `dist/index.html` e selecione **"Open with Live Server"**.

---

## 🎨 Estrutura do Design System MAVITH (Fase 1)

- `/src/design-system/tokens.ts`: Tokens centralizados (Cores, Tipografia, Espaçamentos, Sombras).
- `/src/design-system/components/`:
  - `MavithLogo.tsx`: Logomarca geométrica oficial MAVITH com nós de circuito e variações Light/Dark.
  - `Button.tsx`: Sistema de botões (Primary Blue, Primary Orange, Secondary, Ghost).
  - `Card.tsx`: Cartões corporativos premium com acentos e elevações.
  - `Header.tsx`: Cabeçalho institucional responsivo com navegação e drawer mobile.
  - `Footer.tsx`: Rodapé institucional completo com links e dados da marca.
  - `Modal.tsx`: Diálogo acessível com backdrop blur e suporte a ESC.
  - `Input.tsx`: Controles de formulário semânticos e acessíveis.
  - `Badge.tsx`: Marcadores de status e categorias.
  - `Divider.tsx`: Divisores com nós de circuito integrados.
- `/src/components/`:
  - `StrategicNarrative.tsx`: Apresentação da metodologia *Problema no Centro*.
  - `BrandIdentityShowcase.tsx`: Demonstração da marca, paleta de cores e tipografia.
  - `ComponentLibraryShowcase.tsx`: Playground interativo de todos os componentes.
  - `TokensViewer.tsx`: Inspetor e exportador de tokens em JSON.
